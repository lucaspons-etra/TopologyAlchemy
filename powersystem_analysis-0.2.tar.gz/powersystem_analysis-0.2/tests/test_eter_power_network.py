import math
import random
from typing import Dict
from unittest.mock import patch

import pandas as pd
import pymongo
import pytest
import pytest_asyncio

import powersystem_analysis.domain as domain
import powersystem_analysis.base_power_network as pn
from powersystem_analysis import EterPowerNetwork, MongoConfig, compute_line_length


@pytest.fixture(scope="session")
def mongo_config():
    return MongoConfig(
        host="localhost",
        port=33598,
        user="user",
        password="pass",
        auth_mechanism="SCRAM-SHA-256",
    )


@pytest.fixture
def mock_random():
    with patch("random.random", return_value=0.5) as mock_random:
        yield mock_random


def get_load_data(loads) -> Dict[str, Dict]:
    types = ["load", "danglingLines", "generator"]
    ps = [random.randint(2, 60) for _ in loads]
    loads_pw_data = {}
    data = [
        {
            "_id": load["_id"],
            "type": types[random.randint(0, 2)],
            "p": p,
            "q": p * math.sin(random.random() / 4),
        }
        for [p, load] in zip(ps, loads)
    ]

    for item in data:
        loads_pw_data[item["_id"]] = item

    return loads_pw_data


fake_buses = [
    {"_id": "bus1", "nominalVoltage": 110},
    {"_id": "bus2", "nominalVoltage": 110},
    {"_id": "bus3", "nominalVoltage": 110},
    {"_id": "bus4", "nominalVoltage": 110},
]
fake_lines = [
    {
        "_id": "line1",
        "bus1": "bus1",
        "bus2": "bus2",
        "length": 1.0,
        "r": 1,
        "x": 1,
        "currentLimit": 1,
    },
    {
        "_id": "line2",
        "bus1": "bus2",
        "bus2": "bus3",
        "length": 1.0,
        "r": 1,
        "x": 1,
        "currentLimit": 1,
    },
    {
        "_id": "line3",
        "bus1": "bus3",
        "bus2": "bus4",
        "length": 1.0,
        "r": 1,
        "x": 1,
        "currentLimit": 1,
    },
]
fake_loads = [
    {"_id": "load1", "bus": "bus1"},
    {"_id": "load2", "bus": "bus3"},
    {"_id": "load3", "bus": "bus4"},
]
fake_loads_pq_data = get_load_data(fake_loads)
fake_switches = [
    {"_id": "switch1", "bus1": "bus1", "bus2": "bus2"},
    {"_id": "switch2", "bus1": "bus2", "bus2": "bus3"},
]
fake_trafos = [
    {
        "_id": "trafo1",
        "bus1": "bus1",
        "bus2": "bus2",
        "ratedApparentPower": 10,
        "ratedVoltage1": 110,
        "ratedVoltage2": 10,
        "x": 0.1,
        "r": 0.01,
    },
]
fake_trafos3w = [
    {
        "_id": "trafo3w1",
        "bus1": "bus1",
        "bus2": "bus2",
        "bus3": "bus3",
        "ratedU1": 110,
        "ratedU2": 20,
        "ratedU3": 10,
        "ratedS1": 10,
        "ratedS2": 5,
        "ratedS3": 2,
        "x1": 0.1,
        "x2": 0.05,
        "x3": 0.02,
        "r1": 0.01,
        "r2": 0.005,
        "r3": 0.002,
    },
]
fake_dangling_lines = [
    {"_id": "dline1", "bus": "bus0", "controllable": True},
    {"_id": "dline2", "bus": "bus0", "controllable": False},
    {"_id": "dline3", "bus": "bus1", "network": "bus1", "controllable": False},
]


def test_mongo_config_url():
    mongo_config = MongoConfig(
        host="localhost",
        port=33598,
        user="user",
        password="pass",
        auth_mechanism="SCRAM-SHA-256",
    )
    expected_url = "mongodb://user:pass@localhost:33598/?authSource=admin&authMechanism=SCRAM-SHA-256&connectTimeoutMS=10000&serverSelectionTimeoutMS=5000"
    assert mongo_config.url == expected_url


def test_compute_coordinates_list_length():
    coordinates = [(0.0, 0.0), (1.0, 1.0)]
    length = compute_line_length(coordinates)

    assert length > 0


def test_normal_case_with_float_length():
    line = {"length": 50.0}
    result = pn.get_line_length(line)

    assert result == 50.0


def test_case_with_no_length_field(mock_random):
    line = {}
    result = pn.get_line_length(line)

    assert result == 0.5 * 1000  # mocked random value


def test_case_with_non_float_length(mock_random):
    line = {"length": "50"}
    result = pn.get_line_length(line)

    assert result == 0.5 * 1000


def test_case_with_no_geometry_data_allowed():
    line = {"length": -10.0}
    result = pn.get_line_length(line, allowed_no_geometry_data=True)

    assert result > 0


def test_case_with_no_geometry_data_not_allowed():
    line = {"length": -10.0}
    with pytest.raises(domain.LineDefinitionError):
        pn.get_line_length(line)


@pytest_asyncio.fixture(scope="session")
async def client(mongo_config):
    # naive resource management because of fear to config being production
    assert mongo_config.port != 27017 and mongo_config.user != "root"
    async with pymongo.AsyncMongoClient(mongo_config.url) as client:
        for line in fake_buses:
            try:
                await client["test_db"]["eter_buses"].insert_one(line)
            except Exception as _:
                continue
        for line in fake_lines:
            try:
                await client["test_db"]["eter_lines"].insert_one(line)
            except Exception as _:
                continue
        for load in fake_loads:
            try:
                await client["test_db"]["eter_loads"].insert_one(load)
            except Exception as _:
                continue
        for switch in fake_switches:
            try:
                await client["test_db"]["eter_switches"].insert_one(switch)
            except Exception as _:
                continue
        for trafo in fake_trafos:
            try:
                await client["test_db"]["eter_transformers"].insert_one(trafo)
            except Exception as _:
                continue
        for trafo in fake_trafos3w:
            try:
                await client["test_db"]["eter_transformers"].insert_one(trafo)
            except Exception as _:
                continue
        for dl in fake_dangling_lines:
            try:
                await client["test_db"]["eter_danglingLines"].insert_one(dl)
            except Exception as _:
                continue
        yield client

        print("Closing resources")


@pytest.mark.asyncio
async def test_load_buses_with_mongo_config(mongo_config):
    pn = EterPowerNetwork("test_db", mongo_config=mongo_config)

    await pn.load_buses(query={})

    assert "bus1" in pn.bus_names
    assert len(pn.buses) == len(fake_buses)
    assert pn.buses["bus1"].mongo_data["_id"] == "bus1"


@pytest.mark.asyncio
async def test_load_buses(client):
    pn = EterPowerNetwork("test_db", mongo_client=client)

    await pn.load_buses(query={})

    assert "bus1" in pn.bus_names
    assert len(pn.buses) == len(fake_buses)
    assert pn.buses["bus1"].mongo_data["_id"] == "bus1"


@pytest.mark.asyncio
async def test_load_lines(client):
    pn = EterPowerNetwork("test_db", mongo_client=client)

    await pn.load_buses(query={})
    await pn.load_lines("NA2XS2Y 1x120 RM/25 6/10 kV", allowed_no_geometry_data=True)

    assert len(pn.lines) > 0
    assert len(pn.lines) == len(fake_lines)
    assert "line1" in pn.lines
    assert pn.pp_net.line.iloc[0].from_bus == 0
    assert pn.pp_net.line.iloc[1].from_bus == 1
    assert pn.pp_net.line.iloc[2].from_bus == 2


@pytest.mark.asyncio
async def test_load_loads(client):
    pn = EterPowerNetwork("test_db", mongo_client=client)

    await pn.load_buses(query={})
    await pn.load_lines("NA2XS2Y 1x120 RM/25 6/10 kV", allowed_no_geometry_data=True)
    await pn.load_loads(loads_data=fake_loads_pq_data, power_unit="KW")

    assert len(pn.loads) > 0
    assert len(pn.loads) == len(fake_loads)
    assert "load1" in pn.loads
    assert pn.pp_net.load.iloc[0].bus == 0
    assert pn.pp_net.load.iloc[1].bus == 2
    assert pn.pp_net.load.iloc[2].bus == 3


@pytest.mark.asyncio
async def test_load_switches(client):
    pn = EterPowerNetwork("test_db", mongo_client=client)

    await pn.load_buses(query={})
    await pn.load_switches()
    assert len(pn.switches) > 0
    assert len(pn.switches) == len(fake_switches)
    assert "switch1" in pn.switches
    assert pn.pp_net.switch.iloc[0].bus == 0
    assert pn.pp_net.switch.iloc[1].bus == 1


@pytest.mark.asyncio
async def test_load_trafos(client):
    pn = EterPowerNetwork("test_db", mongo_client=client)

    await pn.load_buses(query={})
    await pn.load_trafos()

    assert len(pn.trafos) > 0
    assert len(pn.trafos) == len(fake_trafos)
    assert "trafo1" in pn.trafos
    assert pn.pp_net.trafo.iloc[0].hv_bus == 0
    assert pn.pp_net.trafo.iloc[0].lv_bus == 1


@pytest.mark.asyncio
async def test_load_trafos3w(client):
    pn = EterPowerNetwork("test_db", mongo_client=client)

    await pn.load_buses(query={})
    await pn.load_trafos3w()

    assert len(pn.trafos3w) > 0
    assert len(pn.trafos3w) == len(fake_trafos3w)
    assert "trafo3w1" in pn.trafos3w
    assert pn.pp_net.trafo3w.iloc[0].hv_bus == 0
    assert pn.pp_net.trafo3w.iloc[0].mv_bus == 1
    assert pn.pp_net.trafo3w.iloc[0].lv_bus == 2


@pytest.mark.asyncio
async def test_load_dangling_lines(client):
    pn = EterPowerNetwork("test_db", mongo_client=client)

    await pn.load_buses(query={})
    await pn.load_dangling_lines(network="bus1")

    assert len(pn.dangling_lines) > 0
    assert len(pn.dangling_lines) < len(fake_dangling_lines)
    assert "dline3" in pn.dangling_lines
    assert pn.pp_net.ext_grid.iloc[0].bus == 0


@pytest.mark.asyncio
async def test_load_lines_wrong_id_raises_exception(client):
    pn = EterPowerNetwork("test_db", mongo_client=client)
    await pn.load_buses(query={})

    with patch("pandapower.create_line", return_value=1.1):
        with pytest.raises(domain.PandaPowerElementCreationError):
            await pn.load_lines(
                "NA2XS2Y 1x120 RM/25 6/10 kV", allowed_no_geometry_data=True
            )


@pytest.mark.asyncio
async def test_load_lines_no_std_wrong_id_raises_exception(client):
    pn = EterPowerNetwork("test_db", mongo_client=client)
    await pn.load_buses(query={})

    with patch("pandapower.create_line_from_parameters", return_value=1.1):
        with pytest.raises(domain.PandaPowerElementCreationError):
            await pn.load_lines(allowed_no_geometry_data=True)


@pytest.mark.asyncio
async def test_load_switches_wrong_id_raises_exception(client):
    pn = EterPowerNetwork("test_db", mongo_client=client)
    await pn.load_buses(query={})

    with patch("pandapower.create_switch", return_value=1.1):
        with pytest.raises(domain.PandaPowerElementCreationError) as ex:
            await pn.load_switches()
            assert "SWITCH" in str(ex.value)


@pytest.fixture
def sample_line_data():
    return pd.DataFrame(
        {
            "p_from_mw": [0.1],
            "q_from_mvar": [0.2],
            "p_to_mw": [0.1],
            "q_to_mvar": [0.2],
            "pl_mw": [0.01],
            "ql_mvar": [0.02],
            "i_from_ka": [0.001],
            "i_to_ka": [0.001],
            "i_ka": [0.001],
        }
    )


@pytest.fixture
def sample_bus_data():
    return pd.DataFrame({"p_mw": [0.1], "q_mvar": [0.2]})


@pytest.fixture
def sample_load_data():
    return pd.DataFrame({"p_mw": [0.1], "q_mvar": [0.2]})


@pytest.fixture
def sample_ext_grid_data():
    return pd.DataFrame({"p_mw": [0.1], "q_mvar": [0.2]})


@pytest.fixture
def sample_switch_data():
    return pd.DataFrame({"i_ka": [0.001]})


def test_line_results_mapper(sample_line_data):
    result = pn.mappers["line"](sample_line_data)

    assert result["p_from_kw"].iloc[0] == 100.0
    assert result["q_from_kvar"].iloc[0] == 200.0


def test_bus_results_mapper(sample_bus_data):
    result = pn.mappers["bus"](sample_bus_data)

    assert result["p_kw"].iloc[0] == 100.0
    assert result["q_kvar"].iloc[0] == 200.0


def test_load_results_mapper(sample_load_data):
    result = pn.mappers["load"](sample_load_data)

    assert result["p_kw"].iloc[0] == 100.0
    assert result["q_kvar"].iloc[0] == 200.0


def test_ext_grid_results_mapper(sample_ext_grid_data):
    result = pn.mappers["ext_grid"](sample_ext_grid_data)

    assert result["p_kw"].iloc[0] == 100.0
    assert result["q_kvar"].iloc[0] == 200.0


def test_switch_results_mapper(sample_switch_data):
    result = pn.mappers["switch"](sample_switch_data)

    assert result["i_a"].iloc[0] == 1.0
