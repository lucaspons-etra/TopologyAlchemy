from unittest.mock import MagicMock, patch

import numpy as np
import pandapower as pp
import pytest

from powersystem_analysis.helpers import (
    compute_line_length,
    get_line_length,
)
from powersystem_analysis.domain import (
    defaults,
    conversion_factor,
    Bus,
    ConvergenceError,
    LineDefinitionError,
    Measurement,
    PandaPowerElementCreationError,
)


class ConcretePowerNetwork:
    """Concrete implementation for testing abstract methods."""

    def __init__(self):
        import pandapower as pp
        self.net = pp.create_empty_network()
        self.buses = {}
        self.lines = {}
        self.switches = {}
        self.generators = {}
        self.trafos = {}
        self.trafos3w = {}
        self.dangling_lines = {}
        self.loads = {}
        self.frequency = 50
        self.n_measurements = 0

    @property
    def pp_net(self):
        return self.net

    @property
    def bus_names(self):
        return list(self.buses.keys())

    @property
    def is_empty(self):
        return (
            not self.buses
            and not self.lines
            and not self.switches
            and not self.generators
            and not self.trafos
            and not self.trafos3w
            and not self.dangling_lines
            and not self.loads
        )

    def clear(self):
        import pandapower as pp
        self.net = pp.create_empty_network()
        self.buses = {}
        self.lines = {}
        self.switches = {}
        self.generators = {}
        self.trafos = {}
        self.trafos3w = {}
        self.dangling_lines = {}
        self.loads = {}
        self.n_measurements = 0

    def add_measurement(self, measurement):
        import pandapower as pp
        result = pp.create_measurement(
            self.net,
            measurement.meas_type,
            measurement.element_type,
            measurement.value,
            measurement.std_dev,
            measurement.element,
            side=measurement.side,
        )
        if not isinstance(result, (int, np.integer)):
            raise PandaPowerElementCreationError("Measurement creation failed")
        self.n_measurements += 1

    def run(self):
        import pandapower as pp
        try:
            pp.runpp(self.net)
        except pp.LoadflowNotConverged:
            diagnosis = self.diagnosis()
            raise ConvergenceError(diagnosis)

    def diagnosis(self):
        import pandapower as pp
        return pp.diagnostic(self.net)

    def load_buses(self, buses: list[dict]):
        pass

    def load_lines(self, lines: list[dict], **kwargs):
        pass

    def load_loads(self, loads: list[dict]):
        pass

    def load_ext_grid(self, ext_grids: dict[str, tuple[int, dict]]):
        pass


class TestComputeLineLength:
    def test_compute_line_length_basic(self):
        coordinates = [(0.0, 0.0), (1.0, 1.0)]
        length = compute_line_length(coordinates)
        assert length > 0

    def test_compute_line_length_multiple_points(self):
        coordinates = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0)]
        length = compute_line_length(coordinates)
        assert length > 0

    def test_compute_line_length_custom_crs(self):
        coordinates = [(0.0, 0.0), (1.0, 1.0)]
        length = compute_line_length(coordinates, crs="EPSG:4326", to_crs="EPSG:3857")
        assert length > 0

    def test_compute_line_length_same_point(self):
        coordinates = [(0.0, 0.0), (0.0, 0.0)]
        length = compute_line_length(coordinates)
        assert length == 0.0


class TestGetLineLength:
    def test_get_line_length_valid_float(self):
        line = {"length": 50.0}
        result = get_line_length(line)
        assert result == 50.0

    @patch("random.random", return_value=0.5)
    def test_get_line_length_missing_length(self, mock_random):
        line = {}
        result = get_line_length(line)
        assert result == 500.0  # 0.5 * 1000

    @patch("random.random", return_value=0.5)
    def test_get_line_length_non_float_length(self, mock_random):
        line = {"length": "50"}
        result = get_line_length(line)
        assert result == 500.0  # 0.5 * 1000

    def test_get_line_length_negative_with_geometry(self):
        line = {"length": -10.0, "geometry": {"coordinates": [(0.0, 0.0), (1.0, 1.0)]}}
        result = get_line_length(line)
        assert result > 0

    def test_get_line_length_zero_with_allowed_no_geometry(self):
        line = {"length": 0.0}
        result = get_line_length(line, allowed_no_geometry_data=True)
        assert result > 0

    def test_get_line_length_zero_without_allowed_no_geometry(self):
        line = {"length": 0.0}
        with pytest.raises(LineDefinitionError):
            get_line_length(line)

    def test_get_line_length_negative_without_geometry_raises_error(self):
        line = {"length": -10.0}
        with pytest.raises(LineDefinitionError):
            get_line_length(line)


@pytest.fixture
def bus():
    return Measurement(
        meas_type="v",
        element_type="bus",
        value=1.0,
        std_dev=0.01,
        element=np.int64(0),
        side=None,
    )


class TestBasePowerNetwork:
    def test_init(self):
        network = ConcretePowerNetwork()
        assert network.net is not None
        assert network.buses == {}
        assert network.lines == {}
        assert network.switches == {}
        assert network.generators == {}
        assert network.trafos == {}
        assert network.trafos3w == {}
        assert network.dangling_lines == {}
        assert network.loads == {}
        assert network.frequency == 50
        assert network.n_measurements == 0

    def test_pp_net_property(self):
        network = ConcretePowerNetwork()
        assert network.pp_net is network.net

    def test_bus_names_empty(self):
        network = ConcretePowerNetwork()
        assert network.bus_names == []

    def test_bus_names_with_buses(self):
        network = ConcretePowerNetwork()
        network.buses = {"bus1": MagicMock(), "bus2": MagicMock()}
        assert network.bus_names == ["bus1", "bus2"]

    @patch("pandapower.create_empty_network")
    def test_clear(self, mock_create_empty):
        network = ConcretePowerNetwork()
        network.buses = {"bus1": []}
        network.lines = {"line1": []}
        assert not network.is_empty

        network.clear()
        assert network.is_empty

    @patch("pandapower.create_measurement")
    def test_add_measurement_success(self, mock_create_measurement):
        mock_create_measurement.return_value = np.int64(1)
        network = ConcretePowerNetwork()
        measurement = Measurement(
            meas_type="v", element_type="bus", value=1.0, std_dev=0.01, element=0
        )

        network.add_measurement(measurement)

        mock_create_measurement.assert_called_once()
        assert network.n_measurements == 1

    @patch("pandapower.create_measurement")
    def test_add_measurement_failure(self, mock_create_measurement):
        mock_create_measurement.return_value = 1.5  # Invalid return type
        network = ConcretePowerNetwork()
        measurement = Measurement(
            meas_type="v", element_type="bus", value=1.0, std_dev=0.01, element=0
        )

        with pytest.raises(PandaPowerElementCreationError):
            network.add_measurement(measurement)

    @patch("pandapower.runpp")
    def test_run_success(self, mock_runpp):
        network = ConcretePowerNetwork()

        network.run()

        mock_runpp.assert_called_once_with(network.net)

    @patch("pandapower.runpp")
    @patch.object(ConcretePowerNetwork, "diagnosis")
    def test_run_convergence_error(self, mock_diagnosis, mock_runpp):
        mock_runpp.side_effect = pp.LoadflowNotConverged("Test error")
        mock_diagnosis.return_value = {"error": "convergence"}
        network = ConcretePowerNetwork()

        with pytest.raises(ConvergenceError):
            network.run()

    @patch("pandapower.diagnostic")
    def test_diagnosis(self, mock_diagnostic):
        mock_diagnostic.return_value = {"status": "ok"}
        network = ConcretePowerNetwork()

        result = network.diagnosis()

        mock_diagnostic.assert_called_once_with(network.net)
        assert result == {"status": "ok"}


class TestBusNamedTuple:
    def test_bus_creation(self):
        bus = Bus(pp_id=1, mongo_data={"_id": "test_bus"})
        assert bus.pp_id == 1
        assert bus.mongo_data["_id"] == "test_bus"

    def test_bus_access(self):
        bus = Bus(pp_id=2, mongo_data={"voltage": 110})
        assert bus[0] == 2
        assert bus[1]["voltage"] == 110


class TestConstants:
    def test_conversion_factor(self):
        assert conversion_factor["W"] == 1_000_000
        assert conversion_factor["KW"] == 1_000
        assert conversion_factor["MW"] == 1

    def test_defaults(self):
        assert "ext_grid" in defaults
        assert "bus" in defaults
        assert "line" in defaults
        assert defaults["ext_grid"]["vm_gpu"] == 1.02
