import pytest

import numpy as np
import pandas as pd
import pandapower as pp

from powersystem_analysis import PowerNetwork
from powersystem_analysis.domain import Bus


class TestPowerNetwork:

    @pytest.fixture
    def power_network(self):
        return PowerNetwork()

    @pytest.fixture
    def sample_bus_data(self):
        return [
            {
                "name": "Bus1",
                "vn_kv": 20.0,
                "type": "b",
                "zone": "zone1",
                "max_vm_pu": 1.1,
                "min_vm_pu": 0.9,
            },
            {
                "name": "Bus2",
                "vn_kv": 20.0,
                "type": "b",
                "zone": "zone1",
                "max_vm_pu": 1.1,
                "min_vm_pu": 0.9,
            },
        ]

    @pytest.fixture
    def sample_line_data(self):
        return [
            {
                "name": "Line1",
                "bus1_name": "Bus1",
                "bus2_name": "Bus2",
                "length_km": 10.0,
                "r_ohm_per_km": 0.1,
                "x_ohm_per_km": 0.08,
                "c_nf_per_km": 240.0,
                "g_us_per_km": 0.0,
                "max_i_ka": 0.4,
                "max_loading_percent": 100.0,
                "type": "cs",
            }
        ]

    @pytest.fixture
    def sample_load_data(self):
        return [
            {
                "name": "Load1",
                "bus_name": "Bus1",
                "p_mw": 5.0,
                "q_mvar": 2.0,
                "const_z_percent": 0.0,
                "const_i_percent": 0.0,
                "sn_mva": np.nan,
                "scaling": 1.0,
                "in_service": True,
                "type": "wye",
            }
        ]

    @pytest.fixture
    def sample_gen_data(self):
        return [
            {
                "name": "Gen1",
                "bus_name": "Bus2",
                "p_mw": 10.0,
                "vm_pu": 1.0,
                "sn_mva": np.nan,
                "min_q_mvar": -5.0,
                "max_q_mvar": 5.0,
                "scaling": 1.0,
                "slack": False,
                "in_service": True,
                "type": "wye",
                "controllable": True,
            }
        ]

    @pytest.fixture
    def sample_ext_grid_data(self):
        return [
            {
                "bus_name": "Bus1",
                "vm_pu": 1.02,
                "va_degree": 0.0,
                "slack": True,
                "in_service": True,
            }
        ]

    def test_init(self, power_network):
        assert isinstance(power_network, PowerNetwork)
        assert power_network.frequency == 50
        assert power_network.is_empty
        assert len(power_network.buses) == 0

    def test_load_buses(self, power_network, sample_bus_data):
        power_network.load_buses(sample_bus_data)

        assert len(power_network.buses) == 2
        assert "Bus1" in power_network.buses
        assert "Bus2" in power_network.buses

        bus1 = power_network.buses["Bus1"]
        assert isinstance(bus1, Bus)
        assert isinstance(bus1.pp_id, (int, np.integer))
        assert bus1.mongo_data == sample_bus_data[0]

        assert len(power_network.pp_net.bus) == 2
        assert power_network.pp_net.bus.loc[bus1.pp_id, "name"] == "Bus1"
        assert power_network.pp_net.bus.loc[bus1.pp_id, "vn_kv"] == 20.0

        assert not power_network.pp_net.bus.empty

    def test_load_lines(self, power_network, sample_bus_data, sample_line_data):
        if power_network.pp_net.bus.empty:
            power_network.load_buses(sample_bus_data)

        power_network.load_lines(sample_line_data)

        assert len(power_network.lines) == 1
        assert "Line1" in power_network.lines

        line_id, line_data = power_network.lines["Line1"]
        assert isinstance(line_id, (int, np.integer))
        assert line_data == sample_line_data[0]

        assert len(power_network.pp_net.line) == 1
        assert power_network.pp_net.line.loc[line_id, "name"] == "Line1"
        assert power_network.pp_net.line.loc[line_id, "length_km"] == 10.0

        assert not power_network.pp_net.bus.empty
        assert not power_network.pp_net.line.empty

    def test_load_lines_missing_buses(self, power_network, sample_line_data):
        with pytest.raises(KeyError):
            power_network.load_lines(sample_line_data)

    def test_load_loads(self, power_network, sample_bus_data, sample_load_data):
        if power_network.pp_net.bus.empty:
            power_network.load_buses(sample_bus_data)

        power_network.load_loads(sample_load_data)

        assert len(power_network.loads) == 1
        assert "Load1" in power_network.loads

        load_id, load_data = power_network.loads["Load1"]
        assert isinstance(load_id, (int, np.integer))
        assert load_data == sample_load_data[0]

        assert len(power_network.pp_net.load) == 1
        assert power_network.pp_net.load.loc[load_id, "name"] == "Load1"
        assert power_network.pp_net.load.loc[load_id, "p_mw"] == 5.0

    def test_load_loads_missing_bus(self, power_network, sample_load_data):
        with pytest.raises(KeyError):
            power_network.load_loads(sample_load_data)

    def test_load_gens(self, power_network, sample_bus_data, sample_gen_data):
        if power_network.pp_net.bus.empty:
            power_network.load_buses(sample_bus_data)

        power_network.load_gens(sample_gen_data)

        assert len(power_network.generators) == 1
        assert "Gen1" in power_network.generators

        gen_id, gen_data = power_network.generators["Gen1"]
        assert isinstance(gen_id, (int, np.integer))
        assert gen_data == sample_gen_data[0]

        assert len(power_network.pp_net.gen) == 1
        assert power_network.pp_net.gen.loc[gen_id, "name"] == "Gen1"
        assert power_network.pp_net.gen.loc[gen_id, "p_mw"] == 10.0

    def test_load_ext_grid(self, power_network, sample_bus_data, sample_ext_grid_data):
        if power_network.pp_net.bus.empty:
            power_network.load_buses(sample_bus_data)

        power_network.load_ext_grid(sample_ext_grid_data)

        assert len(power_network.ext_grids) == 1
        assert "Bus1" in power_network.ext_grids

        ext_grid_id, ext_grid_data = power_network.ext_grids["Bus1"]
        assert isinstance(ext_grid_id, (int, np.integer))
        assert ext_grid_data == sample_ext_grid_data[0]

        assert len(power_network.pp_net.ext_grid) == 1
        assert power_network.pp_net.ext_grid.loc[ext_grid_id, "vm_pu"] == 1.02

    def test_clone(
        self,
        power_network,
        sample_bus_data,
        sample_line_data,
        sample_load_data,
        sample_ext_grid_data,
    ):
        if power_network.pp_net.bus.empty:
            power_network.load_buses(sample_bus_data)

        if power_network.pp_net.ext_grid.empty:
            power_network.load_ext_grid(sample_ext_grid_data)

        if power_network.pp_net.load.empty:
            power_network.load_loads(sample_load_data)

        if power_network.pp_net.line.empty:
            power_network.load_lines(sample_line_data)

        cloned_net = power_network.clone()

        assert isinstance(cloned_net, PowerNetwork)
        assert len(cloned_net.buses) == len(power_network.buses)
        assert len(cloned_net.lines) == len(power_network.lines)
        assert len(cloned_net.loads) == len(power_network.loads)
        assert len(cloned_net.ext_grids) == len(power_network.ext_grids)

        assert len(cloned_net.pp_net.bus) == len(power_network.pp_net.bus)
        assert len(cloned_net.pp_net.line) == len(power_network.pp_net.line)
        assert len(cloned_net.pp_net.load) == len(power_network.pp_net.load)
        assert len(cloned_net.pp_net.ext_grid) == len(power_network.pp_net.ext_grid)

    def test_remove_subnet(self, power_network, sample_bus_data, sample_ext_grid_data):
        if power_network.pp_net.bus.empty:
            power_network.load_buses(sample_bus_data)

        if power_network.pp_net.ext_grid.empty:
            power_network.load_ext_grid(sample_ext_grid_data)

        bus1_id = power_network.buses["Bus1"].pp_id
        bus2_id = power_network.buses["Bus2"].pp_id

        power_network.remove_subnet([bus2_id])

        assert "Bus2" not in power_network.buses
        assert "Bus1" in power_network.buses

        assert bus2_id not in power_network.pp_net.bus.index
        assert bus1_id in power_network.pp_net.bus.index

    def test_remove_bus_and_connect(
        self, power_network, sample_bus_data, sample_line_data, sample_ext_grid_data
    ):
        bus3_data = {
            "name": "Bus3",
            "vn_kv": 20.0,
            "type": "b",
            "zone": "zone1",
            "max_vm_pu": 1.1,
            "min_vm_pu": 0.9,
        }
        all_buses = sample_bus_data + [bus3_data]

        line2_data = {
            "name": "Line2",
            "bus1_name": "Bus2",
            "bus2_name": "Bus3",
            "length_km": 5.0,
            "r_ohm_per_km": 0.1,
            "x_ohm_per_km": 0.08,
            "c_nf_per_km": 240.0,
            "g_us_per_km": 0.0,
            "max_i_ka": 0.4,
            "max_loading_percent": 100.0,
            "type": "cs",
        }
        all_lines = sample_line_data + [line2_data]

        power_network.load_buses(all_buses)
        power_network.load_ext_grid(sample_ext_grid_data)
        power_network.load_lines(all_lines)

        bus1_id = power_network.buses["Bus1"].pp_id
        bus2_id = power_network.buses["Bus2"].pp_id
        bus3_id = power_network.buses["Bus3"].pp_id

        power_network.remove_bus_and_connect(
            buses_to_remove=[bus2_id],
            from_bus=bus1_id,
            to_bus=bus3_id,
            new_line_name="NewLine",
        )

        assert "Bus2" not in power_network.buses
        assert bus2_id not in power_network.pp_net.bus.index

        assert "NewLine" in power_network.lines
        new_line_id, _ = power_network.lines["NewLine"]
        assert new_line_id in power_network.pp_net.line.index

    def test_n_minus_1_analysis_missing_maxs(self, power_network):
        maxs = {"vmax": 1.1, "vmin": 0.9}  # Missing max_ll
        ids = [0]

        with pytest.raises(AssertionError):
            power_network.n_minus_1_analysis(elements=[("line", ids)], maxs=maxs)

    def test_from_pandapower_net(
        self,
        sample_bus_data,
        sample_gen_data,
        sample_line_data,
        sample_load_data,
        sample_ext_grid_data,
    ):
        pp_net = pp.create_empty_network()

        bus1_id = pp.create_bus(
            pp_net,
            **{k: v for k, v in sample_bus_data[0].items()},
        )
        bus2_id = pp.create_bus(
            pp_net,
            **{k: v for k, v in sample_bus_data[1].items()},
        )

        pp.create_ext_grid(
            pp_net,
            bus=bus1_id,
            **{k: v for k, v in sample_ext_grid_data[0].items() if k != "bus"},
        )

        pp.create_gen(
            pp_net,
            bus=bus2_id,
            **{k: v for k, v in sample_gen_data[0].items() if k != "name"},
            name=sample_gen_data[0]["name"],
        )

        pp.create_line_from_parameters(
            pp_net,
            from_bus=bus1_id,
            to_bus=bus2_id,
            **{k: v for k, v in sample_line_data[0].items()},
        )

        pp.create_load(
            pp_net,
            bus=bus1_id,
            **{k: v for k, v in sample_load_data[0].items()},
        )

        net = PowerNetwork.from_pandapower_net(pp_net)

        assert isinstance(net, PowerNetwork)
        assert len(net.buses) == 2
        assert len(net.generators) == 1
        assert len(net.lines) == 1
        assert len(net.loads) == 1
        assert len(net.ext_grids) == 1

    def test_from_pandapower_net_empty_network(self):
        pp_net = pp.create_empty_network()

        net = PowerNetwork.from_pandapower_net(pp_net)

        assert isinstance(net, PowerNetwork)
        assert len(net.pp_net.bus) == 0
        assert len(net.pp_net.gen) == 0
        assert len(net.pp_net.line) == 0
        assert len(net.pp_net.load) == 0
        assert len(net.pp_net.ext_grid) == 0
        assert net.is_empty

    def test_from_pandapower_net_with_geometry(self):
        pp_net = pp.create_empty_network()

        bus1_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus1", type="b", zone="zone1")
        bus2_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus2", type="b", zone="zone1")

        line_id = pp.create_line_from_parameters(
            pp_net,
            from_bus=bus1_id,
            to_bus=bus2_id,
            bus1_name="Bus1",
            bus2_name="Bus2",
            name="Line1",
            length_km=10.0,
            r_ohm_per_km=0.1,
            x_ohm_per_km=0.08,
            c_nf_per_km=240.0,
            g_us_per_km=0.0,
            max_i_ka=0.4,
            type="cs",
        )

        pp_net.bus["geo"] = pd.Series([None, None], index=[bus1_id, bus2_id])
        pp_net.line["geo"] = pd.Series([None], index=[line_id])

        net = PowerNetwork.from_pandapower_net(pp_net)

        assert isinstance(net, PowerNetwork)
        assert len(net.buses) == 2
        assert len(net.lines) == 1

        assert hasattr(net.pp_net.bus, "geo")
        assert hasattr(net.pp_net.line, "geo")

    def test_from_pandapower_net_only_buses(self):
        pp_net = pp.create_empty_network()

        bus1_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus1", type="b", zone="zone1")
        bus2_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus2", type="b", zone="zone1")

        net = PowerNetwork.from_pandapower_net(pp_net)

        assert isinstance(net, PowerNetwork)
        assert len(net.buses) == 2
        assert len(net.generators) == 0
        assert len(net.lines) == 0
        assert len(net.loads) == 0
        assert len(net.ext_grids) == 0

        assert "Bus1" in net.buses
        assert "Bus2" in net.buses
        assert net.buses["Bus1"].pp_id == bus1_id
        assert net.buses["Bus2"].pp_id == bus2_id

    def test_from_pandapower_net_complex_network(self):
        pp_net = pp.create_empty_network()

        bus1_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus1", type="b", zone="zone1")
        bus2_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus2", type="b", zone="zone1")
        bus3_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus3", type="b", zone="zone1")
        pp.create_ext_grid(
            pp_net, bus=bus1_id, vm_pu=1.02, va_degree=0.0, bus_name="Bus1"
        )

        pp.create_gen(
            pp_net,
            bus=bus2_id,
            p_mw=5.0,
            vm_pu=1.0,
            name="Gen1",
            bus_name="Bus2",
            controllable=False,
        )
        pp.create_gen(
            pp_net,
            bus=bus3_id,
            p_mw=3.0,
            vm_pu=1.0,
            name="Gen2",
            bus_name="Bus3",
            controllable=False,
        )

        pp.create_line_from_parameters(
            pp_net,
            from_bus=bus1_id,
            to_bus=bus2_id,
            bus1_name="Bus1",
            bus2_name="Bus2",
            name="Line1",
            length_km=10.0,
            r_ohm_per_km=0.1,
            x_ohm_per_km=0.08,
            c_nf_per_km=240.0,
            g_us_per_km=0.0,
            max_i_ka=0.4,
            type="cs",
        )
        pp.create_line_from_parameters(
            pp_net,
            from_bus=bus2_id,
            to_bus=bus3_id,
            bus1_name="Bus2",
            bus2_name="Bus3",
            name="Line2",
            length_km=5.0,
            r_ohm_per_km=0.1,
            x_ohm_per_km=0.08,
            c_nf_per_km=240.0,
            g_us_per_km=0.0,
            max_i_ka=0.4,
            type="cs",
        )

        pp.create_load(
            pp_net, bus=bus2_id, p_mw=2.0, q_mvar=1, name="Load1", bus_name="Bus2"
        )
        pp.create_load(
            pp_net, bus=bus3_id, p_mw=1.5, q_mvar=0, name="Load2", bus_name="Bus3"
        )

        net = PowerNetwork.from_pandapower_net(pp_net)

        assert isinstance(net, PowerNetwork)
        assert len(net.buses) == 3
        assert len(net.generators) == 2
        assert len(net.lines) == 2
        assert len(net.loads) == 2
        assert len(net.ext_grids) == 1

        assert "Bus1" in net.buses
        assert "Bus2" in net.buses
        assert "Bus3" in net.buses
        assert "Gen1" in net.generators
        assert "Gen2" in net.generators
        assert "Line1" in net.lines
        assert "Line2" in net.lines
        assert "Load1" in net.loads
        assert "Load2" in net.loads
        assert "Bus1" in net.ext_grids  # External grid is keyed by bus name

        net.run()

        bus_results = net.results("bus", as_dataframe=True)
        assert len(bus_results) == 3

        gen_results = net.results("gen", as_dataframe=True)
        assert len(gen_results) == 2

        line_results = net.results("line", as_dataframe=True)
        assert len(line_results) == 2

        load_results = net.results("load", as_dataframe=True)
        assert len(load_results) == 2

    def test_from_pandapower_net_with_missing_names(self):
        pp_net = pp.create_empty_network()

        bus1_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus1", type="b", zone="zone1")
        bus2_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus2", type="b", zone="zone1")
        pp.create_line_from_parameters(
            pp_net,
            from_bus=bus1_id,
            to_bus=bus2_id,
            bus1_name="Bus1",
            bus2_name="Bus2",
            name="Line1",
            length_km=10.0,
            r_ohm_per_km=0.1,
            x_ohm_per_km=0.08,
            c_nf_per_km=240.0,
            g_us_per_km=0.0,
            max_i_ka=0.4,
            type="cs",
        )

        pp.create_load(
            pp_net, bus=bus1_id, p_mw=2.0, q_mvar=1, name="Load1", bus_name="Bus1"
        )

        net = PowerNetwork.from_pandapower_net(pp_net)

        assert isinstance(net, PowerNetwork)
        assert len(net.buses) == 2
        assert len(net.lines) == 1
        assert len(net.loads) == 1

    def test_from_pandapower_net_preserves_network_state(self):
        pp_net = pp.create_empty_network()

        bus1_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus1", type="b", zone="zone1")
        bus2_id = pp.create_bus(pp_net, vn_kv=20.0, name="Bus2", type="b", zone="zone1")

        pp.create_ext_grid(
            pp_net, bus=bus1_id, vm_pu=1.02, va_degree=0.0, bus_name="Bus1"
        )
        pp.create_load(
            pp_net, bus=bus2_id, p_mw=2.0, q_mvar=1.0, name="Load1", bus_name="Bus2"
        )
        pp.create_line_from_parameters(
            pp_net,
            from_bus=bus1_id,
            to_bus=bus2_id,
            name="Line1",
            bus1_name="Bus1",
            bus2_name="Bus2",
            length_km=10.0,
            r_ohm_per_km=0.1,
            x_ohm_per_km=0.08,
            c_nf_per_km=240.0,
            g_us_per_km=0.0,
            max_i_ka=0.4,
            type="cs",
        )

        pp.runpp(pp_net)
        original_vm_pu = pp_net.res_bus.vm_pu.copy()

        net = PowerNetwork.from_pandapower_net(pp_net)

        net.run()

        new_vm_pu = net.pp_net.res_bus.vm_pu
        np.testing.assert_allclose(original_vm_pu.values, new_vm_pu.values, rtol=1e-6)

    def test_from_pandapower_net_round_trip(self):
        net1 = PowerNetwork()

        buses = [
            {"name": "Bus1", "vn_kv": 20.0, "type": "b", "zone": "zone1"},
            {"name": "Bus2", "vn_kv": 20.0, "type": "b", "zone": "zone1"},
        ]
        net1.load_buses(buses)

        ext_grids = [{"bus_name": "Bus1", "vm_pu": 1.02, "va_degree": 0.0}]
        net1.load_ext_grid(ext_grids)

        loads = [{"name": "Load1", "bus_name": "Bus2", "p_mw": 2.0, "q_mvar": 1.0}]
        net1.load_loads(loads)

        lines = [
            {
                "name": "Line1",
                "bus1_name": "Bus1",
                "bus2_name": "Bus2",
                "length_km": 10.0,
                "r_ohm_per_km": 0.1,
                "x_ohm_per_km": 0.08,
                "c_nf_per_km": 240.0,
                "g_us_per_km": 0.0,
                "max_i_ka": 0.4,
                "type": "cs",
            }
        ]
        net1.load_lines(lines)

        net2 = PowerNetwork.from_pandapower_net(net1.pp_net)

        assert len(net2.buses) == len(net1.buses)
        assert len(net2.lines) == len(net1.lines)
        assert len(net2.loads) == len(net1.loads)
        assert len(net2.ext_grids) == len(net1.ext_grids)

        net1.run()
        net2.run()

        np.testing.assert_allclose(
            net1.pp_net.res_bus.vm_pu.values,
            net2.pp_net.res_bus.vm_pu.values,
            rtol=1e-6,
        )

    def test_change_loads_basic(self, power_network):
        buses = [
            {"name": "bus1", "vn_kv": 20.0},
            {"name": "bus2", "vn_kv": 0.4},
        ]
        loads = [
            {"name": "load1", "bus_name": "bus1", "p_mw": 1.0, "q_mvar": 0.5},
            {"name": "load2", "bus_name": "bus2", "p_mw": 2.0, "q_mvar": 1.0},
        ]
        power_network.load_buses(buses)
        power_network.load_loads(loads)

        df = power_network.pp_net.load

        assert df.loc[df["name"] == "load1", "p_mw"].iloc[0] == 1.0
        assert df.loc[df["name"] == "load1", "q_mvar"].iloc[0] == 0.5
        assert df.loc[df["name"] == "load2", "p_mw"].iloc[0] == 2.0
        assert df.loc[df["name"] == "load2", "q_mvar"].iloc[0] == 1.0

        new_loads = [
            {"name": "load1", "bus_name": "bus1", "p_mw": 3.0, "q_mvar": 1.5},
            {"name": "load2", "bus_name": "bus2", "p_mw": 4.0, "q_mvar": 2.0},
        ]
        power_network.change_loads(new_loads)

        assert df.loc[df["name"] == "load1", "p_mw"].iloc[0] == 3.0
        assert df.loc[df["name"] == "load1", "q_mvar"].iloc[0] == 1.5
        assert df.loc[df["name"] == "load2", "p_mw"].iloc[0] == 4.0
        assert df.loc[df["name"] == "load2", "q_mvar"].iloc[0] == 2.0


class TestPowerNetworkIntegration:
    """Integration tests for PowerNetwork with real pandapower operations."""

    def test_full_network_creation_and_analysis(self):
        net = PowerNetwork()

        buses = [
            {
                "name": "Bus1",
                "vn_kv": 20.0,
                "type": "b",
                "zone": "zone1",
                "max_vm_pu": 1.1,
                "min_vm_pu": 0.9,
            },
            {
                "name": "Bus2",
                "vn_kv": 20.0,
                "type": "b",
                "zone": "zone1",
                "max_vm_pu": 1.1,
                "min_vm_pu": 0.9,
            },
        ]
        net.load_buses(buses)

        ext_grids = [{"bus_name": "Bus1", "vm_pu": 1.02, "va_degree": 0.0}]
        net.load_ext_grid(ext_grids)

        loads = [{"name": "Load1", "bus_name": "Bus2", "p_mw": 1.0, "q_mvar": 0.5}]
        net.load_loads(loads)

        lines = [
            {
                "name": "Line1",
                "bus1_name": "Bus1",
                "bus2_name": "Bus2",
                "length_km": 1.0,
                "r_ohm_per_km": 0.1,
                "x_ohm_per_km": 0.08,
                "c_nf_per_km": 240.0,
                "g_us_per_km": 0.0,
                "max_i_ka": 0.4,
                "max_loading_percent": 100.0,
                "type": "cs",
            }
        ]
        net.load_lines(lines)

        assert len(net.buses) == 2
        assert len(net.ext_grids) == 1
        assert len(net.loads) == 1
        assert len(net.lines) == 1

        net.run()

        bus_results = net.results("bus", as_dataframe=True)
        assert len(bus_results) == 2
        assert "vm_pu" in bus_results.columns  # type: ignore

        line_results = net.results("line", as_dataframe=True)
        assert len(line_results) == 1
        assert "loading_percent" in line_results.columns  # type: ignore

        all_results = net.results_all(as_dataframe=True)
        assert "buses" in all_results
        assert "lines" in all_results
        assert "loads" in all_results
        assert "transformers" in all_results

        import tempfile

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
            net.export(tmp.name, format="json")

    def test_network_with_generators(self):
        net = PowerNetwork()

        buses = [
            {
                "name": "Bus1",
                "vn_kv": 20.0,
                "type": "b",
                "zone": "zone1",
                "max_vm_pu": 1.1,
                "min_vm_pu": 0.9,
            },
            {
                "name": "Bus2",
                "vn_kv": 20.0,
                "type": "b",
                "zone": "zone1",
                "max_vm_pu": 1.1,
                "min_vm_pu": 0.9,
            },
        ]
        net.load_buses(buses)

        ext_grids = [{"bus_name": "Bus1", "vm_pu": 1.02, "va_degree": 0.0}]
        net.load_ext_grid(ext_grids)

        gens = [
            {
                "name": "Gen1",
                "bus_name": "Bus2",
                "p_mw": 5.0,
                "vm_pu": 1.0,
                "min_q_mvar": -2.0,
                "max_q_mvar": 2.0,
                "scaling": 1.0,
                "slack": False,
                "in_service": True,
                "controllable": True,
            }
        ]
        net.load_gens(gens)

        loads = [{"name": "Load1", "bus_name": "Bus2", "p_mw": 3.0, "q_mvar": 1.0}]
        net.load_loads(loads)

        lines = [
            {
                "name": "Line1",
                "bus1_name": "Bus1",
                "bus2_name": "Bus2",
                "length_km": 1.0,
                "r_ohm_per_km": 0.1,
                "x_ohm_per_km": 0.08,
                "c_nf_per_km": 240.0,
                "g_us_per_km": 0.0,
                "max_i_ka": 0.4,
                "max_loading_percent": 100.0,
                "type": "cs",
            }
        ]
        net.load_lines(lines)

        net.run()

        gen_results = net.results("gen", as_dataframe=True)
        assert len(gen_results) == 1
        assert "p_mw" in gen_results.columns  # type: ignore

        diagnosis = net.diagnosis()
        assert isinstance(diagnosis, dict)

    def test_empty_network_properties(self):
        net = PowerNetwork()

        assert net.is_empty
        assert net.n_measurements == 0
        assert net.bus_names == []
        assert net.pp_net is net.net

        net.clear()
        assert net.is_empty
