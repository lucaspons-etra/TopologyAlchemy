# Power System Analysis

Power System Analysis package. It can be installed with

```bash
pip install git+ssh://git@gitlabnew.depid.local/energia/powersystem-analysis.git
```

Used in PowerFlow-Service.  

Based in [PandaPower](https://www.pandapower.org/) package.

# PandaPower PowerFlow
## Introduction
Pandapower can export to _json_[^1] with `pp.to_json(net, "net.json")`. The generated json has the pandapower standard types and results data, even if computation wasn't done. We don't neede those to generate network from json, so:
  * we can create json with the elements needed
  * we can call all the methods (like `create_load`, `create_bus`, etc.) using the graph created from mongo data

Other way used in the examples is using csv, loading it through panda, iterating over rows and creting dataframes.

## Steps
  1. parsing from mongo to graph using python dict or networkx (first option should be the first to try)
  2. network creation:
    2.1 creating json and loding with `from_json`
    2.2 calling `pp` methods

nominalVoltage
## Elements creation
### Bus
`create_bus`.We must pass _name_ and _vn_kv_.

| Mongo    | PandaPower |
| -------- | ---------- |
| nominalVoltage | vn_kv      |
| _id      | name       |

Previously the value of _vn_kv_ was `measurements.voltage.value`.

No coordinates for buses in mongo, they can be logical (needed because of the topology) but not physical elements.

### External connection.
`create_ext_grid`. For external connection point, a _danglingLine_ in our mongo model. An external grid must have a _bus_. To get that _bus_, we can use _voltageLevels_ attribute in _eter_substations_, an array with string identifiers, and _voltageLevel_ in _eter_buses_. It should ideally have only one bus, if not is not coherent with the way pandapower defines the external grid.

With mongo

```javascript
db.eter_substations.aggregate([
    { $match: { _id: "CR_DEPURADORA" } },
    {
        $lookup: {
            from: "eter_buses",
            let: { levels: "$voltageLevels" },
            pipeline: [
                { $match: { $expr: { $in: ["$voltageLevel", "$$levels"] } } }
            ],
            as: "bus_connected_to_substation"
        }
    }
])
```

| Mongo | PandaPower |
| ----- | ---------- |
| _id   | name       |



### Load
`create_load(net, bus, p_mw)`. Load is positive. For negative load we must use generator.
     - by default, model of constant active & reactive power consumption
     - const_z_percent / const_i_percent: to define voltage and/or impedance dependent loads


### Switch
It uses two buses, one upstream and one downstream. The later can be in _pandapower_ a line, a transformer, a transformer3w and other bus. By default we use `bus -> switch -> bus` model, so we must use `et="b"` to define the model[^2].


### Transformer
Many defined in standard library, cannot use any of these because far from our trafos. We must create using `create_transformer_from_parameters` instead of using `create_transformer`. Also our collection carries both regular trafos and 3w trafos, so we may use `create_transformer3w_from_parameters` depending on the data in the collection.



## PowerNetwork Class

The `PowerNetwork` class is a wrapper around PandaPower networks that provides high-level methods for creating, manipulating, and analyzing power systems. ~It extends the `BasePowerNetwork` class and provides convenient methods for loading network elements from dictionary representations.~ It does not extend any other class because it is hard to reuse the code for different kind of networks (static/dynamic analysis, or opf/estimation/n-1/simple powerflow, etc.), so the code was inside it is now directly in `PowerNetwork`.

### Key Features

#### Network Creation
The class provides methods to load different network elements:
- `load_buses()`: Creates buses from dictionary data
- `load_lines()`: Creates transmission lines with parameters
- `load_loads()`: Creates electrical loads
- `load_gens()`: Creates generators
- `load_ext_grid()`: Creates external grid connections

#### Network Manipulation
- `clone()`: Creates a complete copy of the network
- `remove_subnet()`: Removes a subnet defined by a list of buses
- `remove_bus_and_connect()`: Removes buses and creates a new connection line
- `from_pandapower_net()`: Creates a PowerNetwork instance from an existing PandaPower network

#### Contingency Analysis (N-1 Analysis)

The class includes a comprehensive N-1 contingency analysis feature through the `n_minus_1_analysis()` method. This analysis simulates the outage of individual network elements to assess system reliability and identify critical components.

##### Usage
```python
results = network.n_minus_1_analysis(
    elements=[
        ("line", [1, 2, 3]),      # Test lines with IDs 1, 2, 3
        ("transformer", [10, 11])  # Test transformers with IDs 10, 11
    ],
    maxs={
        "vmax": 1.1,      # Maximum voltage (p.u.)
        "vmin": 0.9,      # Minimum voltage (p.u.)
        "max_ll": 100.0   # Maximum line loading (%)
    }
)
```

##### Analysis Process
1. **Element Outage Simulation**: Each specified element is taken out of service individually
2. **Power Flow Calculation**: Power flow is run for each contingency scenario
3. **Violation Detection**: The system checks for:
   - Voltage violations (above `vmax` or below `vmin`)
   - Line/transformer loading violations (above `max_ll`)
4. **Critical Element Identification**: Elements whose outage causes violations are flagged as critical

##### Results
The method returns a list of results containing:
- **Critical elements**: List of element IDs that cause violations when out of service
- **Scenario results**: For each contingency, includes the modified network state
- **Failed scenarios**: Elements that caused simulation failures with error details

This feature is essential for:
- **Reliability assessment**: Identifying single points of failure
- **System planning**: Understanding which elements are most critical
- **Maintenance scheduling**: Prioritizing critical equipment maintenance
- **Grid reinforcement**: Identifying where additional redundancy is needed



# ANDES Dynamic Analysis

This package provides a high-level interface for performing **dynamic analysis** of power systems using [ANDES](https://docs.andes.app/en/latest/) (Advanced Networked Dynamic Energy Simulator). The workflow integrates [pandapower](https://www.pandapower.org/) for static network modeling and ANDES for time-domain simulation of dynamic events.

### Overview

- **Network modeling**: Build your network in pandapower or from MongoDB, then convert to ANDES format.
- **Dynamic elements**: Add static and dynamic generators (e.g., PV, GENCLS, REGCA1), lines, buses, and toggles (events).
- **Simulation**: Run power flow and time-domain simulation (TDS) with ultra-conservative or user-defined parameters.
- **Results**: Extract and visualize time series results for any element.

### Key Components

- **`DynamicAnalysis`** (`src/powersystem_analysis/dynamic/analysis.py`):  
  Main class for building, configuring, and running dynamic simulations.
- **`convert_pandapower_to_andes`** (`src/powersystem_analysis/dynamic/pp_to_andes.py`):  
  Converts a pandapower network to ANDES JSON format, preserving dynamic generator info.
- **Plotting utilities** (`src/powersystem_analysis/dynamic/plot.py`):  
  Functions for visualizing network topology and generator types using matplotlib or plotly.

### Typical Workflow

1. **Create or load a pandapower network**  
    You can build a network from scratch, load from MongoDB, or use an existing pandapower net.

2. **Convert to ANDES format**  
    Use `convert_pandapower_to_andes()` to generate an ANDES-compatible JSON.

3. **Build a DynamicAnalysis object**  
    Use the async factory method `DynamicAnalysis.create_dynamic_analysis()` to add buses, lines, static and dynamic generators, and toggles (events).

    ```python
    dyn = await DynamicAnalysis.create_dynamic_analysis(
         query=query,  # MongoDB query required for network topology
         mongo_config=mongo_config,
         new_buses=[...],
         new_lines=[...],
         pvs=[...],  # Static PV generators
         genclss=[(pv_dict, gencls_dict)],  # Synchronous generators
         gen_regca1s=[(pv_dict, regca1_dict)],  # Renewable (grid-following) generators
         toggles=[...],  # Events (e.g., line trips)
    )
    ```

4. **Run dynamic simulation**  
    Call `dyn.run_tds()` to run power flow and time-domain simulation. Results are saved as CSV and JSON.

    ```python
    dyn.run_tds()
    ```


5. **Extract and visualize results**  
   Use the `DynamicResults` class to access time series data for any element, or use the plotting utilities for network visualization.

   ```python
   # Get compacted results (time, variables, matrix)
   results = dyn.results

   # Get results for specific elements
   d_results = DynamicResults(dyn_model_key)
   element_keys = d_results.element_results(names=[
       'Anell_CT-1030_B2_CT-1030_B2',
       'new bus',
       'Added GENCLS 0',
       'REGCA1 2'
   ])['values'].keys()
   print(element_keys) 

   # Plot network topology
   dyn.plot(plot_type="matplotlib")
   ```

### Retrieving Results by Model Key

When you run a dynamic simulation, a unique key (e.g., `dyn_model_key`) is generated for the model and its results. You can use this key to retrieve results later without rerunning the simulation:

```python
# Retrieve results for a previously run model
d_results = DynamicResults(dyn_model_key)
element_data = d_results.element_results(names=['GENCLS 0'])
```

This allows you to efficiently access and analyze results from previous runs.

### Dynamic Model Support

- **Static Generators (PV)**: Added with `add_static_generators()`
- **Synchronous Generators (GENCLS)**: Added as tuples `(PV, GENCLS)` with `add_dynamic_classic_generator()`
- **Renewable Generators (REGCA1)**: Added as tuples `(PV, REGCA1)` with `add_photovoltaic_generator()`
- **Toggles**: Define events (e.g., line switching) for dynamic simulation

### Example

```python
# Example: Build and run a dynamic analysis
dyn = await DynamicAnalysis.create_dynamic_analysis(
     query=query,
     mongo_config=mongo_config,
     new_buses=[...],
     new_lines=[...],
     pvs=[...],
     genclss=[(pv_dict, gencls_dict)],
     gen_regca1s=[(pv_dict, regca1_dict)],
     toggles=[...]
)
dyn.run_tds()
results = dyn.results
```

### Visualization

- **Matplotlib**: `dyn.plot(plot_type="matplotlib")`
- **Plotly**: `dyn.plot(plot_type="plotly")`

Both options show buses, lines, generator types (slack, PV, GENCLS, REGCA1, etc.), and loads.



# Tasks
  1. Instead of passing `id` to functions, we can use data from element dict and using pandapower searching features to get the id.
  2. ~~Wrapping everything around a PowerNetwork class.~~ ✓ Completed

# Addendum
## Queries
### Join for getting elements associates to list of buses
```javascript
db.getCollection("eter_buses").aggregate([
    { $match: { $or: [ { network: "anell_CT-0880_B2" }, { _id: "anell_CT-0880_B2" } ] } },
    {
        $lookup: {
            from: 'eter_loads',
            localField: '_id',
            foreignField: 'bus',
            as: 'networkLoads',
        }
    },
    { $match: { networkLoads: { $ne: [] } } },
    { $project: { load: { $first: "$networkLoads" } } },
    { $replaceRoot: { newRoot: "$load" } }
])
```

# References

- [ANDES Documentation](https://docs.andes.app/en/latest/)
- [Pandapower Documentation](https://www.pandapower.org/)
- [Contingency Analysis without pp functions](https://dwightreid.com/site/power-system-contingency-analysis-with-python-pandapower/)
- [Modelado Práctico de Red](https://modeladopractico.readthedocs.io/es/latest/index.html)

# Footnotes

[^1]: SQL, excel and pickle are other options too.
[^2]: Only one switch at the moment of writing this, but also chat with Lucas makes me think this, maybe it could be different.


# Pandapower

## Powerflow
PV generators must set its bus voltage. If not, network cannot converge. The [simple network](https://github.com/e2nIEE/pandapower/blob/master/tutorials/create_simple.ipynb) used in the simplest powerflow computation in the package documentation is a good test for that. Documentation is wrong. It says this

```
OPTIONAL:
vm_pu (float, default 0) - The voltage set point of the generator.
```


but if value is not explicit passed, it is set to `1.0`, even if `p_mw` is `0.0`. Thi is the real code that mismatches de docs:

```python
def create_gen(
    net: pandapowerNet,
    bus: Int,
    p_mw: float,
    vm_pu: float = 1.0,
    sn_mva: float = nan,
    # ...
```

If we try with `0.0`, computation does not converge. We must in that case to not add the generator. This was done before octobre 2025, but requirements change and now this project is used also for the topology alchemy project, so we cannot avoid adding generators to network if their powers are not known or `0.0` as we did previously.

To avoid both issues, when `p_mw` is `0.0`, `in_service` will be `False`. Another option would be adding as `sgen` instead of `gen`, but the most common kind of generator is the PV model so until we have clear a gen is PQ, will go with the former.

## Network creation performance
For big networks, creating them is quite high. We should not try to improve our code, it is a pandapower issues. For the network defined by the query `{"system": "CREV2GIS", "network": "Crev2Gis"}` we have:

```
This pandapower network includes the following parameter tables:
   - bus (3402 elements)
   - load (33 elements)
   - sgen (2 elements)
   - switch (975 elements)
   - ext_grid (198 elements)
   - line (2285 elements)
   - trafo (230 elements)
```

If we trace the time expended on each step of the `network.create_network(...)` method, we get:

```
[create_network] load_buses took 4.773 seconds
[create_network] load_loads took 0.154 seconds
[create_network] load_usage_points took 0.074 seconds
[create_network]     load_lines QUERY AND MAPPING took 0.290 seconds
[create_network]     load_lines POWER_NETWORK.load_lines dict comprehension took 5.972 seconds
[create_network]     load_lines POWER_NETWORK.load_lines pp create_line_from_parameters 5.958 seconds
[create_network]     load_lines POWER_NETWORK.load_lines took 5.972 seconds
[create_network] load_lines took 6.262 seconds
[create_network] load_switches took 1.796 seconds
[create_network] load_trafos took 1.259 seconds
[create_network] load_trafos3w took 0.107 seconds
[create_network] load_dangling_lines took 0.506 seconds
```

For the total time expended in the most expensive step, `load_lines`, which is `6.262 seconds`, `5.972` are expended in the `pp.create_line_from_parameters`, the `95 %` of the time.  


