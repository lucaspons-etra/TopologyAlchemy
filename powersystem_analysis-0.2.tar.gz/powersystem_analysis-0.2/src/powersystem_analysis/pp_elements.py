from typing import Callable
import pandas as pd


def line_results_mapper(df: pd.DataFrame):
    df["p_from_mw"] = df["p_from_mw"] * 1_000
    df["q_from_mvar"] = df["q_from_mvar"] * 1_000
    df["p_to_mw"] = df["p_to_mw"] * 1_000
    df["q_to_mvar"] = df["q_to_mvar"] * 1_000
    df["pl_mw"] = df["pl_mw"] * 1_000
    df["ql_mvar"] = df["ql_mvar"] * 1_000
    df["i_from_ka"] = df["i_from_ka"] * 1_000
    df["i_to_ka"] = df["i_to_ka"] * 1_000
    df["i_ka"] = df["i_ka"] * 1_000

    return df.rename(
        columns={
            "p_from_mw": "p_from_kw",
            "q_from_mvar": "q_from_kvar",
            "p_to_mw": "p_to_kw",
            "q_to_mvar": "q_to_kvar",
            "pl_mw": "pl_kw",
            "ql_mvar": "ql_kvar",
            "i_from_ka": "i_from_a",
            "i_to_ka": "i_to_a",
            "i_ka": "i_a",
        },
        inplace=False,
    )


def bus_results_mapper(df: pd.DataFrame):
    df["p_mw"] = df["p_mw"] * 1_000
    df["q_mvar"] = df["q_mvar"] * 1_000

    return df.rename(
        columns={"p_mw": "p_kw", "q_mvar": "q_kvar"},
        inplace=False,
    )


def load_results_mapper(df: pd.DataFrame):
    df["p_mw"] = df["p_mw"] * 1_000
    df["q_mvar"] = df["q_mvar"] * 1_000

    return df.rename(
        columns={"p_mw": "p_kw", "q_mvar": "q_kvar"},
        inplace=False,
    )


def gen_results_mapper(df: pd.DataFrame):
    df["p_mw"] = df["p_mw"] * 1_000
    df["q_mvar"] = df["q_mvar"] * 1_000

    return df.rename(
        columns={"p_mw": "p_kw", "q_mvar": "q_kvar"},
        inplace=False,
    )


def ext_grid_results_mapper(df: pd.DataFrame):
    df["p_mw"] = df["p_mw"] * 1_000
    df["q_mvar"] = df["q_mvar"] * 1_000

    return df.rename(
        columns={"p_mw": "p_kw", "q_mvar": "q_kvar"},
        inplace=False,
    )


def switch_results_mapper(df: pd.DataFrame):
    df["i_ka"] = df["i_ka"] * 1_000

    return df.rename(
        columns={"i_ka": "i_a"},
        inplace=False,
    )


def trafo_results_mapper(df: pd.DataFrame):
    df["p_hv_mw"] = df["p_hv_mw"] * 1_000
    df["q_hv_mvar"] = df["q_hv_mvar"] * 1_000
    df["p_lv_mw"] = df["p_lv_mw"] * 1_000
    df["q_lv_mvar"] = df["q_lv_mvar"] * 1_000
    df["pl_mw"] = df["pl_mw"] * 1_000
    df["ql_mvar"] = df["ql_mvar"] * 1_000
    df["i_hv_ka"] = df["i_hv_ka"] * 1_000
    df["i_lv_ka"] = df["i_lv_ka"] * 1_000

    return df.rename(
        columns={
            "p_hv_mw": "p_hv_kw",
            "q_hv_mvar": "q_hv_kvar",
            "p_lv_mw": "p_lv_kw",
            "q_lv_mvar": "q_lv_kvar",
            "pl_mw": "pl_kw",
            "ql_mvar": "ql_kvar",
            "i_hv_ka": "i_hv_a",
            "i_lv_ka": "i_lv_a",
        },
        inplace=False,
    )


mappers: dict[str, Callable[[pd.DataFrame], pd.DataFrame]] = {
    "line": line_results_mapper,
    "bus": bus_results_mapper,
    "ext_grid": ext_grid_results_mapper,
    "load": load_results_mapper,
    "gen": gen_results_mapper,
    "sgen": gen_results_mapper,
    "switch": switch_results_mapper,
    "trafo": trafo_results_mapper,
}
