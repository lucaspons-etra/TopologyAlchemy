import io
from typing import Callable, Optional
import requests
import aiohttp
import json
from .eter_power_network import EterPowerNetwork

class EterPowerNetworkUrl(EterPowerNetwork):
    citric_base_url: str

    def __init__(self, citric_uri: str, citric_user_id: str, citric_auth_token: str):
        super().__init__(citric_uri=citric_uri, citric_user_id=citric_user_id, citric_auth_token=citric_auth_token)
        self.citric_base_url = citric_uri.rstrip('/')
    
    def _get_headers(self) -> dict:
        headers = {}
        if self.citric_user_id:
            headers["X-User-ID"] = self.citric_user_id
        if self.citric_auth_token:
            headers["X-Auth-Token"] = self.citric_auth_token

        return headers

    async def create_network_from_citric(self, system:str, network_id: str):
        """
        Creates a pandapower network by fetching data from the CITRIC REST API.
        1. Calls the CITRIC API endpoint to get a file identifier for the network.
        2. Downloads the file using the identifier.
        3. Imports the file into pandapower and sets the network.
        """
        if not self.citric_base_url:
            raise RuntimeError("CITRIC REST client is not configured.")

        # Prepare headers with credentials if provided
        headers = self._get_headers()
        headers["Content-Type"] = "application/json"
        headers["accept"] = "application/json"

        async with aiohttp.ClientSession() as session:
            # 1. Call CITRIC API to get file identifier
            endpoint1 = f"{self.citric_base_url}/eter/systems/{system}/field/networks"
            async with session.get(endpoint1, headers=headers) as resp1:
                resp1.raise_for_status()
                resp1_data = await resp1.json()
                # print (resp1_data.get("data"))
                networks = [e for e in resp1_data.get("data").get("networks") if e.get("networkId") == network_id]
                if not networks or len(networks) == 0:
                    raise ValueError(f"No network found with ID {network_id} from CITRIC API.")

                remote_path = networks[0].get("ppNetwork")
                if not remote_path:
                    raise ValueError("No file_id returned from CITRIC API.")

            # 2. Download the file using the file identifier
            endpoint2 = f"{self.citric_base_url}/getFile/{remote_path}"
            async with session.get(endpoint2, headers=headers) as resp2:
                resp2.raise_for_status()
                resp2_text = await resp2.text()

                # 3. Import the file into pandapower
                self.power_network.net = self.power_network.from_pandapower_json(io.StringIO(resp2_text))
                #self.power_network.update_internal_data_structures()

            #self.power_network.load_buses(buses=self.get_elements("buses", query={"system": system, "network": network_id}))

    async def load_loads(self, loads_data: dict, power_unit: str = 'MW'):
        self.power_network.change_loads(loads_data=loads_data, power_unit=power_unit)