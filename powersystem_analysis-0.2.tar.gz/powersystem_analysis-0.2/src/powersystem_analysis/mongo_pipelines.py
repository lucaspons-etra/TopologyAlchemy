def buses_upl_aggregation(bus_ids: list[str]) -> list[dict[str, dict]]:
    return [
        {
            "$match": {
                "bus": {"$in": bus_ids}
            }
        },
        # Traer usagePoints asociados a cada ubicación
        {
            "$lookup": {
                "from": "eter_usagePoints",
                "localField": "_id",
                "foreignField": "usagePointLocation",
                "as": "usagePoints",
            }
        },
        # Eliminar ubicaciones sin usagePoints
        {"$match": {"usagePoints": {"$ne": []}}},
        # Traer meters asociados a cada usagePoint
        {
            "$lookup": {
                "from": "eter_meters",
                "localField": "usagePoints._id",
                "foreignField": "usagePoint",
                "as": "allMeters",
            }
        },
        # Asociar cada usagePoint con su meter correspondiente
        {
            "$addFields": {
                "usagePoints": {
                    "$map": {
                        "input": "$usagePoints",
                        "as": "up",
                        "in": {
                            "$mergeObjects": [
                                "$$up",
                                {
                                    "meter": {
                                        "$arrayElemAt": [
                                            {
                                                "$filter": {
                                                    "input": "$allMeters",
                                                    "as": "m",
                                                    "cond": {
                                                        "$eq": [
                                                            "$$m.usagePoint",
                                                            "$$up._id",
                                                        ]
                                                    },
                                                }
                                            },
                                            0,
                                        ]
                                    }
                                },
                            ]
                        },
                    }
                }
            }
        },
        # Filtrar solo si al menos un usagePoint tiene meter
        {"$match": {"usagePoints.meter": {"$ne": None}}},
        # Limpiar datos temporales
        {"$project": {"allMeters": 0}},
    ]


def network_upl_aggregation(system: str, network: str) -> list[dict[str, dict]]:
    """
    MongoDB aggregation pipeline to get the network/bus usage points
    and their meters.
    The pipeline consists of the following steps:
    1. Match the bus and system.
    2. Lookup the usagePointLocations for these buses.
    3. Filter the usagePointLocations that are not empty.
    4. Lookup the usagePoints that reference locations in bus/network.
    5. Lookup all meters that reference these usagePoints.
    6. Nest the data properly: meters inside usagePoints inside locations.
    7. Remove the temporary arrays.
    Args:
        system (str): The system name to filter by.
        network (str): The network/bus name to filter by.
    Returns:
        List[Dict]: The aggregation pipeline stages.
    """
    return [
        # 1. Filter
        {"$match": {"system": system, "network": network}},
        # 2. Lookup usagePointLocations for these buses
        {
            "$lookup": {
                "from": "eter_usagePointLocations",
                "localField": "_id",
                "foreignField": "bus",
                "as": "networkUsagePointLocations",
            }
        },
        # 3. Filter
        {"$match": {"networkUsagePointLocations": {"$ne": []}}},
        # Deleting unneeded fields
        {
            "$project": {
                "_id": 1,
                "system": 1,
                "network": 1,
                "networkUsagePointLocations": 1,
                "mRID": 1,
                "geometry": 1,
            }
        },
        # 4. Lookup usagePoints that reference locations in bus/network
        {
            "$lookup": {
                "from": "eter_usagePoints",
                "localField": "networkUsagePointLocations._id",
                "foreignField": "usagePointLocation",
                "as": "networkUsagePoints",
                "pipeline": [
                    {
                        "$project": {
                            "_id": 1,
                            "usagePointLocation": 1,
                            "system": 1,
                            "network": 1,
                            "mRID": 1,
                        }
                    }
                ],
            }
        },
        # 5. Lookup all meters that reference these usagePoints
        {
            "$lookup": {
                "from": "eter_meters",
                "localField": "networkUsagePoints._id",
                "foreignField": "usagePoint",
                "as": "networkMeters",
                "pipeline": [
                    {
                        "$project": {
                            "_id": 1,
                            "usagePoint": 1,
                            "system": 1,
                            "network": 1,
                            "mRID": 1,
                        }
                    }
                ],
            }
        },
        # 6. Nest the data properly: meters inside usagePoints inside locations
        {
            "$addFields": {
                "networkUsagePointLocations": {
                    "$map": {
                        "input": "$networkUsagePointLocations",
                        "as": "location",
                        "in": {
                            "$mergeObjects": [
                                "$$location",
                                {
                                    "usagePoints": {
                                        "$map": {
                                            "input": {
                                                "$filter": {
                                                    "input": "$networkUsagePoints",
                                                    "as": "up",
                                                    "cond": {
                                                        "$eq": [
                                                            "$$up.usagePointLocation",
                                                            "$$location._id",
                                                        ]
                                                    },
                                                }
                                            },
                                            "as": "usagePoint",
                                            "in": {
                                                "$mergeObjects": [
                                                    "$$usagePoint",
                                                    {
                                                        "meter": {
                                                            "$arrayElemAt": [
                                                                {
                                                                    "$filter": {
                                                                        "input": "$networkMeters",
                                                                        "as": "m",
                                                                        "cond": {
                                                                            "$eq": [
                                                                                "$$m.usagePoint",
                                                                                "$$usagePoint._id",
                                                                            ]
                                                                        },
                                                                    }
                                                                },
                                                                0,
                                                            ]
                                                        }
                                                    },
                                                ]
                                            },
                                        }
                                    }
                                },
                            ]
                        },
                    }
                }
            }
        },
        # 7. Remove the temporary arrays
        {"$project": {"networkUsagePoints": 0, "networkMeters": 0}},
        {"$match": {"networkUsagePointLocations.usagePoints.meter": {"$ne": None}}},
    ]
