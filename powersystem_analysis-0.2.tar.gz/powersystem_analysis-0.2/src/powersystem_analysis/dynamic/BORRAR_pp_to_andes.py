"""Aquí lo intento añadiendo elementos al modelo.

Tras probar creo que mejor modificando el json del modelo y luego cargarlo,
pero es importante dejar esto como opción/referencia."""

import andes


class PowerFlowTransformer:
    def __init__(self, net):
        self.pp_net = net
        self.andes_net = andes.System()
        self.elements = {}
        self.toggle = {}
        self.create_default_area()
        self.create_buses()
        self.create_lines()
        self.create_loads()
        self.create_generators()
        self.create_slack()

    def create_default_area(self):
        _ = self.andes_net.add("Area", param_dict={"idx": 1, "u": 1.0, "name": "AREA1"})
        self.elements["Area"] = self.andes_net.Area.as_df().to_dict(orient="records")

    def create_toggles(self, toggles: list[dict]):
        for idx, toggle in enumerate(toggles, start=1):
            _ = self.andes_net.add(
                "Toggle", param_dict={"idx": idx} | toggle
            )

        self.elements["Toggle"] = self.andes_net.Toggle.as_df().to_dict(
            orient="records"
        )

    def create_slack(self):
        for ext in self.pp_net.ext_grid.itertuples():
            bus_vn = self.pp_net.bus.loc[ext.bus, "vn_kv"]

            slack_dict = {
                "idx": str(ext.Index),
                "u": 1,  # Connection status.
                "name": ext.name,
                "bus": str(ext.bus),
                "Vn": bus_vn,  # Voltage at the bus in kV.
                "v0": ext.vm_pu,  # Voltage magnitude at the bus in p.u.
            }
            _ = self.andes_net.add("Slack", param_dict=slack_dict)

        self.elements["Slack"] = self.andes_net.Slack.as_df().to_dict(orient="records")

    def create_buses(self):
        default = {"area": 1, "zone": 1, "owner": 1}
        for pp_bus in self.pp_net.bus.itertuples():
            pp_bus_andes_dict = {
                "idx": str(pp_bus.Index),
                "Vn": pp_bus.vn_kv,
                "name": pp_bus.name,
            }
            _ = self.andes_net.add("Bus", param_dict=default | pp_bus_andes_dict)

        self.elements["Bus"] = self.andes_net.Bus.as_df().to_dict(orient="records")

    def create_lines(
        self,
    ):
        for line in self.pp_net.line.itertuples():
            bus_1 = line.from_bus
            bus_2 = line.to_bus
            bus_vn1 = self.pp_net.bus.loc[bus_1, "vn_kv"]
            bus_vn2 = self.pp_net.bus.loc[bus_2, "vn_kv"]

            # ssa_line['Zb'] = ssa_line["Vb"]**2 / ssa_line["Sn"]
            # ssa_line['Yb'] = ssa_line["Sn"] / ssa_line["Vb"]**2
            # ssa_line['R'] = ssa_line["r"] * ssa_line['Zb']  # ohm
            # ssa_line['X'] = ssa_line["x"] * ssa_line['Zb']  # ohm
            # ssa_line['C'] = ssa_line["b"] / ssa_line['Zb'] / omega * 1e9  # nF
            # ssa_line['G'] = ssa_line["g"] * ssa_line['Yb'] * 1e6  # mS

            line_andes_dict = {
                "idx": line.name.replace(" ", "_"),
                # "u": 1.0,
                # Must be `object` so affect too to `bus` index.
                "bus1": str(bus_1),
                # Must be `object` so affect too to `bus` index.
                "bus2": str(bus_2),
                "Vn1": bus_vn1,
                "Vn2": bus_vn2,
                "name": line.name,
                "r": line.length_km * line.r_ohm_per_km,
                "x": line.length_km * line.x_ohm_per_km,
                "g": line.length_km * line.g_us_per_km,
            }
            _ = self.andes_net.add("Line", param_dict=line_andes_dict)

        # Trafos are Lines in Andes
        for trafo in self.pp_net.trafo.itertuples():
            trafo_andes_dict = {
                "idx": trafo.name.replace(" ", "_"),
                "Sn": trafo.sn_mva,
                "Vn1": trafo.vn_hv_kv,
                "Vn2": trafo.vn_lv_kv,
                # Must be `object` so affect too to `bus` index.
                "bus1": str(trafo.hv_bus),
                # Must be `object` so affect too to `bus` index.
                "bus2": str(trafo.lv_bus),
                "name": trafo.name,
                "r": 0,
                "x": trafo.vkr_percent,
                "g": 0,
                "tap": (100 - trafo.tap_step_percent)
                / 100,  # 0.99677,  # default value i dont know how to create from pandapower
            }
            _ = self.andes_net.add("Line", param_dict=trafo_andes_dict)
        
        self.elements["Line"] = self.andes_net.Line.as_df().to_dict(
            orient="records"
        )

    def create_loads(self):
        default = {"owner": 1}
        for load in self.pp_net.load.itertuples():
            bus_vn = self.pp_net.bus.loc[load.bus, "vn_kv"]

            gen_andes_dict = {
                "idx": str(load.Index),
                # "u": 1,
                "name": load.name,
                "bus": str(load.bus),
                "p0": load.p_mw,
                "q0": load.q_mvar,
                "Vn": bus_vn,  # Voltage at the bus in kV.
            }
            _ = self.andes_net.add("PQ", param_dict=default | gen_andes_dict)

        self.elements["PQ"] = self.andes_net.PQ.as_df().to_dict(orient="records")

    def create_generators(self):
        for gen in self.pp_net.gen.itertuples():
            gen_andes_dict = {
                "idx": str(gen.Index),
                "u": 1,  # Connection status.
                "name": gen.name,
                "Sn": gen.sn_mva,
                "Vn": gen.vm_pu,
                "bus": str(gen.bus),
                "p0": gen.p_mw,
                "qmax": gen.max_q_mvar,
                "qmin": gen.min_q_mvar,
            }
            _ = self.andes_net.add("PV", param_dict=gen_andes_dict)

    def to_json(self, filename: str):
        """
        Save the Andes network to a JSON file.

        Args:
            filename (str): The name of the file to save the network to.
        """
        import json

        with open(filename, "w") as f:
            json.dump(self.elements, f, indent=4)
