#!/usr/bin/env python3
"""
Pandapower to ANDES JSON converter.
This module provides functionality to convert pandapower networks to ANDES JSON format.
"""

import json
from typing import Any, Dict, List, Optional
import logging

import numpy as np
import pandapower as pp
import pandas as pd


class PandaPowerToAndesConverter:
    """
    Converts pandapower networks to ANDES JSON format with transparent dynamic model support.

    This converter automatically detects and preserves dynamic generator information
    if present in the pandapower network. Dynamic models (like GENCLS) are only
    included if the pandapower network contains the corresponding dynamic parameters
    stored in extra columns with 'andes_' prefix.

    The ANDES JSON format has the following main components:
    - Bus: Network buses with voltage levels and coordinates
    - Line: Transmission lines connecting buses
    - PQ: Constant power loads
    - PV: Voltage-controlled generators
    - Slack: Slack/reference buses (from ext_grid)
    - GENCLS: Classical synchronous generators (if dynamic info present)
    - TG2: Turbine Governor Type 2 controllers (if controller info present)
    - Area: Network areas
    - TG2: Turbine governors (optional)
    - Toggler: Control elements (optional)
    """

    def __init__(self, pp_net: pp.pandapowerNet):
        """
        Initialize converter with pandapower network.

        Parameters:
        -----------
        pp_net : pp.pandapowerNet
            The pandapower network to convert
        """
        self.pp_net = pp_net
        self.andes_data = {}

    def convert_buses(self) -> List[Dict[str, Any]]:
        """
        Convert pandapower buses to ANDES Bus format.

        Returns:
        --------
        List[Dict]: List of ANDES Bus objects
        """
        buses = []

        for idx, bus in self.pp_net.bus.iterrows():
            # Get coordinates from geodata if available
            xcoord, ycoord = 0, 0
            if (
                hasattr(self.pp_net, "bus_geodata")
                and idx in self.pp_net.bus_geodata.index
            ):
                xcoord = float(self.pp_net.bus_geodata.loc[idx, "x"])
                ycoord = float(self.pp_net.bus_geodata.loc[idx, "y"])

            bus_data = {
                "idx": int(idx),
                "u": 1.0 if bus.get("in_service", True) else 0.0,
                "name": bus.get("name", f"Bus {idx}"),
                "Vn": float(bus["vn_kv"]),  # Nominal voltage in kV
                "vmax": float(bus.get("max_vm_pu", 1.1)),
                "vmin": float(bus.get("min_vm_pu", 0.9)),
                "v0": 1.0,  # Initial voltage magnitude
                "a0": 0.0,  # Initial voltage angle
                "xcoord": xcoord,
                "ycoord": ycoord,
                "area": 1,  # Default area since zone doesn't exist in pandapower
                "zone": None,
                "owner": None,
            }
            buses.append(bus_data)

        return buses

    def convert_lines(self) -> List[Dict[str, Any]]:
        """
        Convert pandapower lines to ANDES Line format.

        Returns:
        --------
        List[Dict]: List of ANDES Line objects
        """
        lines = []

        for idx, line in self.pp_net.line.iterrows():
            # Get bus voltages for Vn1 and Vn2
            bus1_vn = self.pp_net.bus.loc[line["from_bus"], "vn_kv"]
            bus2_vn = self.pp_net.bus.loc[line["to_bus"], "vn_kv"]

            line_r_x_b = {
                "r": float(line["r_ohm_per_km"] * line["length_km"]),
                "x": float(line["x_ohm_per_km"] * line["length_km"]),
                "b": float(
                    line["c_nf_per_km"] * line["length_km"] * 1e-9 * 2 * np.pi * 50
                ),
            }
            if "andes_r" in line:
                line_r_x_b["r"] = float(line["andes_r"])
                line_r_x_b["x"] = float(line["andes_x"])
                line_r_x_b["b"] = float(line["andes_b"])

            line_data = {
                "idx": int(idx),
                "u": 1.0 if line.get("in_service", True) else 0.0,
                "name": line.get("name", f"Line {idx}"),
                "bus1": int(line["from_bus"]),
                "bus2": int(line["to_bus"]),
                "Sn": 100.0,
                "fn": 60.0,
                "Vn1": float(bus1_vn),
                "Vn2": float(bus2_vn),
                "b1": 0.0,
                "g1": 0.0,
                "b2": 0.0,
                "g2": 0.0,
                "trans": 0.0,  # No transformer
                "tap": 1.0,  # No tap for lines
                "phi": 0.0,  # No phase shift for lines
                "owner": None,
                "xcoord": None,
                "ycoord": None,
            } | line_r_x_b
            lines.append(line_data)

        return lines

    def convert_loads(self) -> List[Dict[str, Any]]:
        """
        Convert pandapower loads to ANDES PQ format.

        Returns:
        --------
        List[Dict]: List of ANDES PQ (load) objects
        """
        loads = []

        for idx, load in self.pp_net.load.iterrows():
            load_data = {
                "idx": int(idx),
                "u": 1.0 if load.get("in_service", True) else 0.0,
                "name": load.get("name", f"Load {idx}"),
                "bus": int(load["bus"]),
                "Vn": float(self.pp_net.bus.loc[load["bus"], "vn_kv"]),
                "p0": float(load["p_mw"] / 100.0),
                "q0": float(load["q_mvar"] / 100.0),
                "vmax": 1.1,
                "vmin": 0.9,
                "owner": None,
            }
            loads.append(load_data)

        return loads

    def convert_generators(self) -> List[Dict[str, Any]]:
        """
        Convert pandapower generators to ANDES PV format.

        Note: Generators with slack=True are handled in convert_ext_grid()
        and go to the Slack section, not PV section.

        Returns:
        --------
        List[Dict]: List of ANDES PV (generator) objects
        """
        generators = []

        for idx, gen in self.pp_net.gen.iterrows():
            # Skip generators that are slack generators (they go to Slack section)
            if gen.get("slack", False):
                continue

            # Skip generators that are GENCLS (they go to GENCLS section)
            if gen.get("andes_model_type") == "GENCLS":
                continue

            gen_data = {
                "idx": gen["idx_in_andes"]
                if "idx_in_andes" in gen
                else len(generators),
                "u": 1.0 if gen.get("in_service", True) else 0.0,
                "name": gen.get("name", f"Gen {idx}"),
                "bus": int(gen["bus"]),
                "Sn": float(gen.get("sn_mva", 100.0)),
                "Vn": float(self.pp_net.bus.loc[gen["bus"], "vn_kv"]),
                "p0": float(gen["p_mw"] / 100.0),
                "pmax": float(gen.get("max_p_mw", gen["p_mw"]) / 100.0),
                "pmin": float(gen.get("min_p_mw", 0) / 100.0),
                "qmax": float(gen.get("max_q_mvar", 50) / 100.0),
                "qmin": float(gen.get("min_q_mvar", -50) / 100.0),
                "v0": float(gen["vm_pu"]),
                "vmax": 1.4,
                "vmin": 0.6,
                "ra": 0.01,
                "xs": 0.3,
            }
            generators.append(gen_data)

        return generators

    def convert_ext_grid(self, num_pvs: int) -> List[Dict[str, Any]]:
        """
        Convert pandapower slack generators to ANDES Slack format.

        In pandapower, slack generators are identified by the 'slack' field in the gen table.
        For each generator with slack=True, we create a corresponding ANDES Slack generator
        that references the bus where that generator is connected.

        Returns:
        --------
        List[Dict]: List of ANDES Slack objects
        """
        slack_generators = []

        # Find slacks, that are gen with slack==True in pandapower
        if (
            hasattr(self.pp_net, "gen")
            and len(self.pp_net.gen) > 0
            and "slack" in self.pp_net.gen.columns
        ):
            slack_gens = self.pp_net.gen[self.pp_net.gen["slack"]]

            for idx, (gen_idx, gen) in enumerate(slack_gens.iterrows()):
                slack_data = {
                    "idx": int(idx) + num_pvs,
                    "u": 1.0 if gen.get("in_service", True) else 0.0,
                    "name": gen.get("name", f"Slack {gen_idx}"),
                    "Sn": float(gen.get("sn_mva", 100.0)),
                    "Vn": float(self.pp_net.bus.loc[gen["bus"], "vn_kv"]),
                    "bus": int(gen["bus"]),
                    "p0": float(gen.get("p_mw", 0) / 100.0),
                    "q0": 0.0,
                    "pmax": float(gen.get("max_p_mw", 999) / 100.0),
                    "pmin": float(gen.get("min_p_mw", -999) / 100.0),
                    "qmax": float(gen.get("max_q_mvar", 999) / 100.0),
                    "qmin": float(gen.get("min_q_mvar", -999) / 100.0),
                    "v0": float(gen.get("vm_pu", 1.0)),
                    "vmax": 1.4,
                    "vmin": 0.6,
                    "ra": 0.01,
                    "xs": 0.3,
                    "a0": 0.0,
                }
                slack_generators.append(slack_data)

        # Also handle ext_grid as potential slack buses (alternative approach)
        if hasattr(self.pp_net, "ext_grid") and len(self.pp_net.ext_grid) > 0:
            for idx, ext_grid in self.pp_net.ext_grid.iterrows():
                # Check if this bus already has a slack generator from gen.slack field
                bus_already_slack = False
                if hasattr(self.pp_net, "gen") and "slack" in self.pp_net.gen.columns:
                    slack_gens_on_bus = self.pp_net.gen[
                        (self.pp_net.gen["bus"] == ext_grid["bus"])
                        & (self.pp_net.gen["slack"])
                    ]
                    bus_already_slack = len(slack_gens_on_bus) > 0

                if not bus_already_slack:
                    slack_data = {
                        "idx": len(slack_generators),
                        "u": 1.0 if ext_grid.get("in_service", True) else 0.0,
                        "name": ext_grid.get("name", f"Slack {ext_grid['bus']}"),
                        "bus": int(ext_grid["bus"]),
                        "Sn": 100.0,
                        "Vn": float(self.pp_net.bus.loc[ext_grid["bus"], "vn_kv"]),
                        "v0": float(ext_grid["vm_pu"]),
                        "a0": float(np.radians(ext_grid.get("va_degree", 0))),
                        "p0": 0.0,
                        "q0": 0.0,
                        "pmax": 999.0,
                        "pmin": -999.0,
                        "qmax": 999.0,
                        "qmin": -999.0,
                        "owner": None,
                    }
                    slack_generators.append(slack_data)

        return slack_generators

    def convert_areas(self) -> List[Dict[str, Any]]:
        """
        Create a default ANDES Area since pandapower doesn't have zones.

        Returns:
        --------
        List[Dict]: List of ANDES Area objects
        """
        areas = []

        # Create a single default area since pandapower doesn't have zone concept
        area_data = {"idx": 1, "u": 1.0, "name": "Area 1"}
        areas.append(area_data)

        return areas

    def convert_gencls(self) -> List[Dict[str, Any]]:
        """
        Convert pandapower generators with GENCLS dynamic info to ANDES GENCLS format.

        This method extracts GENCLS generators from pandapower networks that have
        dynamic information stored in extra columns (created by enhanced_andes_to_pandapower).

        Returns:
        --------
        List[Dict]: List of ANDES GENCLS objects
        """
        gencls_generators = []
        gencls_idx = 0

        # Check if we have dynamic info columns
        if "andes_model_type" not in self.pp_net.gen.columns:
            return gencls_generators

        for _, gen in self.pp_net.gen.iterrows():
            if gen.get("andes_model_type") == "GENCLS":
                gencls_data = {
                    "idx": gencls_idx,
                    "u": 1.0 if gen.get("in_service", True) else 0.0,
                    "name": gen.get("name", None),
                    "bus": int(gen["bus"]),
                    "gen": int(gen.get("andes_gen", gencls_idx)),
                    "coi": gen.get("andes_coi", None),
                    "coi2": gen.get("andes_coi2", None),
                    "Sn": float(gen.get("andes_Sn", 100.0)),
                    "Vn": float(
                        gen.get("andes_Vn", self.pp_net.bus.loc[gen["bus"], "vn_kv"])
                    ),
                    "fn": float(gen.get("andes_fn", 60.0)),
                    "D": float(gen.get("andes_D", 0.0)),
                    "M": float(gen.get("andes_M", 5.0)),
                    "ra": float(gen.get("andes_ra", 0.0)),
                    "xl": float(gen.get("andes_xl", 0.0)),
                    "xd1": float(gen.get("andes_xd1", 1.7)),
                    "kp": float(gen.get("andes_kp", 0.0)),
                    "kw": float(gen.get("andes_kw", 0.0)),
                    "S10": float(gen.get("andes_S10", 0.15)),
                    "S12": float(gen.get("andes_S12", 0.7)),
                    "gammap": float(gen.get("andes_gammap", 1.0)),
                    "gammaq": float(gen.get("andes_gammaq", 1.0)),
                }
                gencls_generators.append(gencls_data)
                gencls_idx += 1

        return gencls_generators

    def convert_tg2(self) -> List[Dict[str, Any]]:
        """
        Convert pandapower generators with TG2 data to ANDES TG2 format.

        TG2 (Turbine Governor Type 2) controllers need the following parameters:
        - syn: Index of the associated GENCLS generator (mandatory)
        - R: Speed regulation gain (default: 0.05 p.u.)
        - pmax: Maximum power output (default: 999.0 p.u.)
        - pmin: Minimum power output (default: 0.0 p.u.)
        - dbl: Deadband lower limit (default: -0.0001 p.u.)
        - dbu: Deadband upper limit (default: 0.0001 p.u.)
        - dbc: Deadband neutral value (default: 0.0 p.u.)
        - T1: Transient gain time (default: 0.2 s)
        - T2: Governor time constant (default: 10.0 s)
        - Tn: Turbine power rating (default: 0.0, uses Sn if not provided)
        - wref0: Base speed reference (default: 1.0 p.u.)

        Returns:
        --------
        List[Dict]: TG2 controllers in ANDES format
        """
        tg2_controllers = []
        tg2_idx = 0

        # Check if we have TG2 data columns
        if "gen" not in self.pp_net or len(self.pp_net.gen) == 0:
            return tg2_controllers

        gen_df = self.pp_net.gen

        # Check for presence of TG2 columns
        tg2_columns = [col for col in gen_df.columns if col.startswith("andes_tg2_")]
        if not tg2_columns:
            return tg2_controllers

        # Find generators with TG2 data (any non-null TG2 parameter indicates TG2 presence)
        tg2_mask = pd.Series(False, index=gen_df.index)
        for col in tg2_columns:
            tg2_mask |= gen_df[col].notna()

        tg2_gens = gen_df[tg2_mask]
        if len(tg2_gens) == 0:
            return tg2_controllers

        for gen_idx, gen in tg2_gens.iterrows():
            # Find the corresponding GENCLS generator index by matching andes_idx
            syn_idx = None

            # Look for GENCLS generators in the same pandapower network
            if "andes_model_type" in self.pp_net.gen.columns:
                # Find GENCLS generators
                gencls_mask = self.pp_net.gen["andes_model_type"] == "GENCLS"
                gencls_gens = self.pp_net.gen[gencls_mask]

                # Find the GENCLS generator that corresponds to this TG2 generator
                # Check if this generator has GENCLS data
                if gen.get("andes_model_type") == "GENCLS" and "andes_idx" in gen:
                    # This generator itself is a GENCLS, use its andes_idx
                    gencls_andes_idx = gen.get("andes_idx")

                    # Find the sequential index of this GENCLS in our converted list
                    gencls_list = self.convert_gencls()
                    for seq_idx, gencls_data in enumerate(gencls_list):
                        if gencls_data.get("idx") == gencls_andes_idx:
                            syn_idx = seq_idx
                            break
                else:
                    # Look for a GENCLS on the same bus
                    bus_gencls = gencls_gens[gencls_gens["bus"] == gen["bus"]]
                    if len(bus_gencls) > 0:
                        gencls_andes_idx = bus_gencls.iloc[0].get("andes_idx")

                        # Find the sequential index of this GENCLS in our converted list
                        gencls_list = self.convert_gencls()
                        for seq_idx, gencls_data in enumerate(gencls_list):
                            if gencls_data.get("idx") == gencls_andes_idx:
                                syn_idx = seq_idx
                                break

            if syn_idx is None:
                logging.info(
                    f"Could not find GENCLS generator for TG2 on bus {gen['bus']}. Skipping TG2."
                )
                continue

            tg2_data = {
                "idx": tg2_idx,
                "u": int(gen.get("andes_tg2_u", 1)),
                "name": f"TG2 {tg2_idx + 1}",
                "syn": syn_idx,  # Link to GENCLS generator
                "R": self._get_gen_param_value(gen, "andes_tg2_R", 0.05),
                "pmax": self._get_gen_param_value(gen, "andes_tg2_pmax", 999.0),
                "pmin": self._get_gen_param_value(gen, "andes_tg2_pmin", 0.0),
                "dbl": self._get_gen_param_value(gen, "andes_tg2_dbl", -0.0001),
                "dbu": self._get_gen_param_value(gen, "andes_tg2_dbu", 0.0001),
                "dbc": self._get_gen_param_value(gen, "andes_tg2_dbc", 0.0),
                "T1": self._get_gen_param_value(gen, "andes_tg2_T1", 0.2),
                "T2": self._get_gen_param_value(gen, "andes_tg2_T2", 10.0),
                "Tn": self._get_gen_param_value(gen, "andes_tg2_Tn", 0.0),
                "wref0": self._get_gen_param_value(gen, "andes_tg2_wref0", 1.0),
            }

            tg2_controllers.append(tg2_data)
            tg2_idx += 1

        return tg2_controllers

    def convert_to_andes(self) -> Dict[str, Any]:
        """
        Convert the entire pandapower network to ANDES JSON format.

        Returns:
        --------
        Dict: Complete ANDES JSON structure
        """
        logging.info("Converting pandapower network to ANDES format...")

        pvs = self.convert_generators()

        # Convert all components
        self.andes_data = {
            "Bus": self.convert_buses(),
            "Line": self.convert_lines(),
            "PQ": self.convert_loads(),
            "PV": pvs,
            "Slack": self.convert_ext_grid(len(pvs)),
            "Area": self.convert_areas(),
            "GENCLS": self.convert_gencls(),
            "TG2": self.convert_tg2(),
        }

        # Add empty sections for optional components
        self.andes_data["Toggler"] = []

        logging.info("Conversion complete!")
        logging.debug(f"  Buses: {len(self.andes_data['Bus'])}")
        logging.debug(f"  Lines: {len(self.andes_data['Line'])}")
        logging.debug(f"  Loads: {len(self.andes_data['PQ'])}")
        logging.debug(f"  Generators: {len(self.andes_data['PV'])}")
        logging.debug(f"  Slack buses: {len(self.andes_data['Slack'])}")
        logging.debug(f"  GENCLS generators: {len(self.andes_data['GENCLS'])}")
        logging.debug(f"  TG2 controllers: {len(self.andes_data['TG2'])}")
        logging.debug(f"  Areas: {len(self.andes_data['Area'])}")

        return self.andes_data

    def save_to_file(self, filename: str):
        """
        Save the ANDES JSON data to a file.

        Parameters:
        -----------
        filename : str
            Output filename for the JSON file
        """
        if not self.andes_data:
            self.convert_to_andes()

        with open(filename, "w") as f:
            json.dump(self.andes_data, f, indent=2)

        logging.info(f"ANDES JSON saved to: {filename}")

    def _get_gen_param_value(self, gen_row, param_name: str, default_value):
        """
        Extract parameter value from pandapower generator row with default fallback.

        Parameters:
        -----------
        gen_row : pandas.Series
            The generator row from pandapower network
        param_name : str
            Name of the parameter column
        default_value : Any
            Default value if parameter is missing or None

        Returns:
        --------
        Any: Parameter value or default
        """
        value = gen_row.get(param_name, default_value)
        return default_value if (value is None or pd.isna(value)) else value


def convert_pandapower_to_andes(
    pp_net: pp.pandapowerNet,
    output_file: Optional[str] = None,
    togglers: list[dict] = [],
) -> dict[str, Any]:
    """
    Convert pandapower network to ANDES format.

    This function automatically detects and preserves dynamic generator information
    if present in the pandapower network (stored in extra columns with 'andes_' prefix).

    Parameters:
    -----------
    pp_net : pp.pandapowerNet
        The pandapower network to convert
    output_file : str, optional
        If provided, save the result to this file

    Returns:
    --------
    dict: ANDES JSON structure
    """
    converter = PandaPowerToAndesConverter(pp_net)
    andes_data = converter.convert_to_andes()
    if len(togglers) > 0:
        andes_data["Toggler"] = togglers

    if output_file:
        converter.save_to_file(output_file)

    return andes_data


def _get_andes_parameter_value(andes_system, model_name, param_name, index):
    """
    Extract parameter value from ANDES system, preferring .vin over .v.

    Parameters
    ----------
    andes_system : andes.System
        ANDES system object
    model_name : str
        Name of the model (e.g., 'GENCLS')
    param_name : str
        Name of the parameter
    index : int
        Index of the element

    Returns
    -------
    float or str or int
        Parameter value

    Raises
    ------
    AttributeError
        If the model or parameter doesn't exist
    IndexError
        If the index is out of range
    """
    if not hasattr(andes_system, model_name):
        raise AttributeError(f"ANDES system does not have model '{model_name}'")

    model = getattr(andes_system, model_name)

    if not hasattr(model, param_name):
        raise AttributeError(
            f"ANDES model '{model_name}' does not have parameter '{param_name}'"
        )

    param = getattr(model, param_name)

    # Prefer .vin (input) over .v (computed)
    if hasattr(param, "vin"):
        return param.vin[index]
    elif hasattr(param, "v"):
        return param.v[index]
    else:
        raise AttributeError(
            f"Parameter '{param_name}' in model '{model_name}' has neither .vin nor .v attributes"
        )


def _convert_gencls_to_pandapower(andes_system):
    """
    Convert ANDES GENCLS generators to pandapower generator format.

    Parameters:
    -----------
    andes_system : andes.System
        The ANDES system containing GENCLS generators

    Returns:
    --------
    List[Dict]
        List of generator dictionaries ready for pandapower

    Raises
    ------
    AttributeError
        If required GENCLS parameters are missing
    """
    gencls_generators = []

    for i in range(andes_system.GENCLS.n):
        # Required parameters - raise error if missing
        bus_idx = _get_andes_parameter_value(andes_system, "GENCLS", "bus", i)
        sn_mva = _get_andes_parameter_value(andes_system, "GENCLS", "Sn", i)
        p_pu = _get_andes_parameter_value(andes_system, "GENCLS", "p0", i)
        vm_pu = _get_andes_parameter_value(andes_system, "GENCLS", "Vn", i)
        u_val = _get_andes_parameter_value(andes_system, "GENCLS", "u", i)

        # Convert values
        p_mw = p_pu * sn_mva
        in_service = bool(u_val)

        # Optional parameters - use try/except for graceful handling
        try:
            name = _get_andes_parameter_value(andes_system, "GENCLS", "name", i)
        except AttributeError:
            name = f"GENCLS_{i}"

        gencls_gen = {
            "bus": int(bus_idx),
            "p_mw": float(p_mw),
            "vm_pu": float(vm_pu),
            "name": name,
            "max_p_mw": float(p_mw * 1.2),  # Default limits
            "min_p_mw": float(p_mw * 0.1),
            "max_q_mvar": float(sn_mva * 0.5),
            "min_q_mvar": float(-sn_mva * 0.5),
            "in_service": in_service,
            "sn_mva": float(sn_mva),
        }

        gencls_generators.append(gencls_gen)

    return gencls_generators


def _convert_tg2_to_pandapower(andes_system):
    """
    Convert ANDES TG2 controllers to pandapower generator format.

    Parameters:
    -----------
    andes_system : andes.System
        The ANDES system containing TG2 controllers

    Returns:
    --------
    List[Dict]
        List of TG2 parameter dictionaries for pandapower generators

    Raises
    ------
    AttributeError
        If required TG2 parameters are missing
    """
    tg2_data = []

    if not hasattr(andes_system, "TG2") or andes_system.TG2.n == 0:
        return tg2_data

    for i in range(andes_system.TG2.n):
        # Required parameters - raise error if missing
        syn_idx = _get_andes_parameter_value(andes_system, "TG2", "syn", i)
        u_val = _get_andes_parameter_value(andes_system, "TG2", "u", i)
        tg2_params = {
            "syn_idx": int(syn_idx),  # Which GENCLS this TG2 controls
            "andes_tg2_u": int(u_val),
            "andes_tg2_R": float(
                _get_andes_parameter_value(andes_system, "TG2", "R", i)
            ),
            "andes_tg2_pmax": float(
                _get_andes_parameter_value(andes_system, "TG2", "pmax", i)
            ),
            "andes_tg2_pmin": float(
                _get_andes_parameter_value(andes_system, "TG2", "pmin", i)
            ),
            "andes_tg2_dbl": float(
                _get_andes_parameter_value(andes_system, "TG2", "dbl", i)
            ),
            "andes_tg2_dbu": float(
                _get_andes_parameter_value(andes_system, "TG2", "dbu", i)
            ),
            "andes_tg2_dbc": float(
                _get_andes_parameter_value(andes_system, "TG2", "dbc", i)
            ),
            "andes_tg2_T1": float(
                _get_andes_parameter_value(andes_system, "TG2", "T1", i)
            ),
            "andes_tg2_T2": float(
                _get_andes_parameter_value(andes_system, "TG2", "T2", i)
            ),
        }

        # Optional parameters - use try/except for graceful handling
        try:
            tg2_params["andes_tg2_Tn"] = float(
                _get_andes_parameter_value(andes_system, "TG2", "Tn", i)
            )
        except AttributeError:
            tg2_params["andes_tg2_Tn"] = 0.0

        try:
            tg2_params["andes_tg2_wref0"] = float(
                _get_andes_parameter_value(andes_system, "TG2", "wref0", i)
            )
        except AttributeError:
            tg2_params["andes_tg2_wref0"] = 1.0

        tg2_data.append(tg2_params)

    return tg2_data


def enhanced_andes_to_pandapower(pp_net, andes_system, preserve_dynamic_info=True):
    """
    Enhance pandapower network with preserved dynamic generator information from ANDES.

    This function enhances an existing pandapower network by:
    1. Taking the existing pandapower network as base
    2. Adding GENCLS (and other SynGen models) as additional generators
    3. Storing dynamic parameters in extra dataframe columns

    Parameters:
    -----------
    pp_net : pp.pandapowerNet
        The pandapower network to enhance
    andes_system : andes.System
        The ANDES system containing dynamic generator information
    preserve_dynamic_info : bool
        If True, adds dynamic generator info to extra columns

    Returns:
    --------
    pp.pandapowerNet
        Enhanced pandapower network with dynamic info preserved
    """
    # Work with a copy to avoid modifying the original
    enhanced_pp_net = pp_net.deepcopy()

    if not preserve_dynamic_info:
        return enhanced_pp_net

    # Renaming columns to avoid conflicts
    for slack in range(andes_system.Slack.n):
        name = andes_system.Slack.name.v[slack]
        slack_idx = andes_system.Slack.idx.v[slack]
        enhanced_pp_net.gen.loc[slack_idx & enhanced_pp_net.gen.slack, "name"] = name

    # Esto ha de ir antes de meter los GENCLS
    for pv in range(andes_system.PV.n):
        name = andes_system.PV.name.v[pv]
        enhanced_pp_net.gen.loc[
            enhanced_pp_net.gen["name"] == andes_system.PV.bus.v[pv], "idx_in_andes"
        ] = enhanced_pp_net.gen.loc[
            enhanced_pp_net.gen["name"] == andes_system.PV.bus.v[pv], "name"
        ]
        enhanced_pp_net.gen.loc[
            enhanced_pp_net.gen["name"] == andes_system.PV.bus.v[pv], "name"
        ] = name

    # Add GENCLS generators to the pandapower network
    if hasattr(andes_system, "GENCLS") and andes_system.GENCLS.n > 0:
        gencls_generators = _convert_gencls_to_pandapower(andes_system)

        # Add to existing generators or create new ones
        for gencls_gen in gencls_generators:
            # In 5bus there is no name in json son andes creates numerical.
            # We dont want that, so we set the name to other name
            name = gencls_gen["name"]
            try:
                name = int(name)
                name = f"GENCLS_{name}"
            except ValueError:
                pass

            pp.create_gen(
                enhanced_pp_net,
                bus=gencls_gen["bus"],
                p_mw=gencls_gen["p_mw"],
                vm_pu=gencls_gen["vm_pu"],
                name=name,
                max_p_mw=gencls_gen["max_p_mw"],
                min_p_mw=gencls_gen["min_p_mw"],
                max_q_mvar=gencls_gen["max_q_mvar"],
                min_q_mvar=gencls_gen["min_q_mvar"],
                in_service=gencls_gen["in_service"],
            )

        # Add dynamic parameters as extra columns
        _add_gencls_dynamic_columns(enhanced_pp_net, andes_system)

    # Add other SynGen models (GENROU, PLBVFU1, etc.) if needed
    # Similar pattern can be applied

    # Substitution of r, x, b values with those from ANDES
    for line in range(andes_system.Line.n):
        andes_line_name = andes_system.Line.name.v[line]
        enhanced_pp_net.line.loc[
            enhanced_pp_net.line["name"] == andes_line_name, "andes_r"
        ] = andes_system.Line.r.vin[line]
        enhanced_pp_net.line.loc[
            enhanced_pp_net.line["name"] == andes_line_name, "andes_x"
        ] = andes_system.Line.x.vin[line]
        enhanced_pp_net.line.loc[
            enhanced_pp_net.line["name"] == andes_line_name, "andes_b"
        ] = andes_system.Line.b.vin[line]

    return enhanced_pp_net


def _add_gencls_dynamic_columns(pp_net, andes_system):
    """
    Add GENCLS dynamic parameters as extra columns to pandapower generators.

    Parameters:
    -----------
    pp_net : pp.pandapowerNet
        The pandapower network to modify
    andes_system : andes.System
        The ANDES system containing GENCLS data
    """
    # Initialize dynamic parameter columns for GENCLS
    dynamic_params = [
        "andes_model_type",  # 'GENCLS', 'GENROU', etc.
        "andes_idx",  # Original ANDES index
        "andes_gen",  # Generator index
        "andes_coi",  # Center of inertia
        "andes_coi2",  # Second center of inertia
        "andes_Sn",  # Nominal apparent power
        "andes_Vn",  # Nominal voltage
        "andes_fn",  # Nominal frequency
        "andes_D",  # Damping coefficient
        "andes_M",  # Inertia constant
        "andes_ra",  # Armature resistance
        "andes_xl",  # Leakage reactance
        "andes_xd1",  # d-axis transient reactance
        "andes_kp",  # Active power coefficient
        "andes_kw",  # Frequency coefficient
        "andes_S10",  # Saturation factor S(1.0)
        "andes_S12",  # Saturation factor S(1.2)
        "andes_gammap",  # Active power participation factor
        "andes_gammaq",  # Reactive power participation factor
        # TG2 parameters
        "andes_tg2_u",
        "andes_tg2_R",
        "andes_tg2_pmax",
        "andes_tg2_pmin",
        "andes_tg2_dbl",
        "andes_tg2_dbu",
        "andes_tg2_dbc",
        "andes_tg2_T1",
        "andes_tg2_T2",
        "andes_tg2_Tn",
        "andes_tg2_wref0",
    ]

    # Add columns with default values
    for param in dynamic_params:
        pp_net.gen[param] = None

    # Find generators that correspond to GENCLS
    gen_count = len(pp_net.gen)
    gencls_start_idx = gen_count - andes_system.GENCLS.n

    # Fill dynamic parameters for GENCLS generators
    for i in range(andes_system.GENCLS.n):
        gen_idx = gencls_start_idx + i

        if gen_idx < len(pp_net.gen):
            pp_net.gen.loc[gen_idx, "andes_model_type"] = "GENCLS"
            pp_net.gen.loc[gen_idx, "andes_idx"] = int(
                _get_andes_parameter_value(andes_system, "GENCLS", "idx", i)
            )

            # Add all GENCLS dynamic parameters - use try/except for optional ones
            param_mapping = [
                ("gen", "andes_gen", int),
                ("coi", "andes_coi", float),
                ("coi2", "andes_coi2", float),
                ("Sn", "andes_Sn", float),
                ("Vn", "andes_Vn", float),
                ("fn", "andes_fn", float),
                ("D", "andes_D", float),
                ("M", "andes_M", float),
                ("ra", "andes_ra", float),
                ("xl", "andes_xl", float),
                ("xd1", "andes_xd1", float),
                ("kp", "andes_kp", float),
                ("kw", "andes_kw", float),
                ("S10", "andes_S10", float),
                ("S12", "andes_S12", float),
                ("gammap", "andes_gammap", float),
                ("gammaq", "andes_gammaq", float),
            ]

            for andes_param, pp_column, type_converter in param_mapping:
                try:
                    value = _get_andes_parameter_value(
                        andes_system, "GENCLS", andes_param, i
                    )
                    pp_net.gen.loc[gen_idx, pp_column] = (
                        None if value is None else type_converter(value)
                    )
                except AttributeError:
                    # Parameter doesn't exist - leave as None (default)
                    pass

    # Add TG2 parameters if present
    if hasattr(andes_system, "TG2") and andes_system.TG2.n > 0:
        tg2_data = _convert_tg2_to_pandapower(andes_system)

        for tg2_params in tg2_data:
            # Find the corresponding GENCLS generator index
            syn_idx = tg2_params["syn_idx"]

            # Find the GENCLS generator that corresponds to this TG2 by andes_idx
            gencls_mask = (pp_net.gen.get("andes_idx") == syn_idx) & (
                pp_net.gen.get("andes_model_type") == "GENCLS"
            )
            matching_gens = pp_net.gen[gencls_mask]
            gencls_gen = matching_gens.iloc[0] if len(matching_gens) > 0 else None

            if gencls_gen is not None:
                # Add TG2 parameters as new columns to the GENCLS generator row
                gen_idx = gencls_gen.name
                for param_name, param_value in tg2_params.items():
                    if param_name != "syn_idx":  # Skip the syn_idx field
                        pp_net.gen.loc[gen_idx, param_name] = param_value


def add_andes_togglers(andes_ss, togglers: list[dict]):
    for idx, toggle in enumerate(togglers, start=1):
        _ = andes_ss.add("Toggle", param_dict={"idx": idx} | toggle)
