import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Generator, Literal, TypedDict

import andes
import numpy as np
import pandapower as pp
import pandas as pd
from pymongo import AsyncMongoClient

from powersystem_analysis.domain import MongoConfig
from powersystem_analysis.eter_power_network import EterPowerNetwork

from .domain import (
    MODEL_DEFAULTS,
    FileDoesNotExists,
    Idx,
    Model,
    PFlowUnestableError,
    TDSComputationError,
)
from .plot import plot_basic_network_topology, plot_plotly_network_topology
from .pp_to_andes import convert_pandapower_to_andes

PlotType = Literal["matplotlib", "plotly"]
AndesElement = Literal["Line", "Bus", "GENCLS", "REGCA1", "GENROU", "Slack", "PV"]
Extension = Literal["json", "csv", "npz", "lst"]
AndesModels: list[AndesElement] = ["Bus", "GENCLS", "REGCA1", "Slack", "PV"]


def get_model_name(
    ts: None | int = None, ext: Extension = "json", is_output=False
) -> Path:
    if ts is None:
        from datetime import datetime

        ts = int(datetime.now().timestamp())

    suffix = "_out" if is_output else ""

    return Path("/tmp") / f"andes_model_{ts}{suffix}.{ext}"


def get_element_names(
    model: AndesElement, indexes: list[str]
) -> Generator[str, None, None]:
    """Names inside `dae` timeseries from model indexes

    The logic behind this has been reverse-engineered.
    Three rules we got so far:
    1. if idx is a number-like str or str, name inside `dae.ts`
       is the model `{Var} {Model Name} {idx}`
        e.g. GENCLS with idx 45 -> GENCLS 45
    2. If model is other kind of str, two subrules
        2.1 if idx contains model name, it is deleted
            e.g. GENCLS with idx GENCLS_45 -> GENCLS 45
        2.2 if idx does not contain model name, is added
            e.g. GENCLS with idx ASDRF_45 -> GENCLS ASDRF 45

    In all cases, no `_` remains in final name
    """
    for index in indexes:
        try:
            yield f"{model} {int(index)}"
        except Exception:
            if index.find(model) > -1:
                yield index.replace("_", " ")
            else:
                yield f"{model} {index.replace('_', ' ')}"


def get_measurements(ss, model) -> list:
    return list(getattr(ss, model).states.keys()) + list(
        getattr(ss, model).algebs.keys()
    )


class ExportQuery(TypedDict):
    elements: AndesElement
    name: None | str


class DynamicAnalysis:
    def __init__(self, network: pp.pandapowerNet, base_power: float = 100.0):
        now = int(datetime.now().timestamp())
        tmp_file = get_model_name(now)
        convert_pandapower_to_andes(network, output_file=str(tmp_file))
        self.__ss: andes.System = andes.load(
            str(tmp_file), setup=False, default_config=True
        )  # type: ignore
        self.__ss.config.mva = base_power  # type: ignore
        self.__base_power = base_power
        self.__ts_key = now
        self.__dyn_results: None | DynamicResults = None
        self.__results_dict = {}

    @property
    def ss(self) -> andes.System:
        return self.__ss

    @property
    def base_power(self) -> float:
        return self.__base_power

    @property
    def results(self) -> None | dict:
        if self.__dyn_results is None:
            return None

        return self.__results_dict

    def plot(
        self,
        plot_type: PlotType = "matplotlib",
        figsize=(18, 8),
        aspect_ratio=2.0,
        debug=False,
        show_line_names=False,
    ):
        match plot_type:
            case "matplotlib":
                return plot_basic_network_topology(
                    self.ss,
                    figsize=figsize,
                    aspect_ratio=aspect_ratio,
                    debug=debug,
                    show_line_names=show_line_names,
                )
            case "plotly":
                return plot_plotly_network_topology(
                    self.ss,
                    debug=debug,
                    show_line_names=show_line_names,
                )

    def add_buses(self, buses: list[dict]) -> list[Idx]:
        """
        Add multiple buses to the dynamic analysis system.

        :param buses: List of dictionaries containing parameters for each bus.

        :return: List of indices of the added buses.
        """
        return [self.add_bus(BUS=bus) for bus in buses]

    def add_bus(self, *, BUS: dict) -> Idx:
        """
        Add a bus to the dynamic analysis system.

        :param name: The name of the bus.
        :param BUS: Dictionary containing parameters for the bus.

        :return: The index of the added bus.
        """
        return self.__add(model="Bus", param_dict=BUS)

    def add_lines(self, lines: list[dict]) -> list[Idx]:
        """
        Add multiple lines to the dynamic analysis system.

        :param lines: List of dictionaries containing parameters for each line.

        :return: List of indices of the added lines.
        """
        return [self.add_line(LINE=line) for line in lines]

    def add_line(self, *, LINE: dict) -> Idx:
        """Add a line to the dynamic analysis system.

        :param LINE: Dictionary containing parameters for the line.

        :return: The index of the added line.
        """

        assert "bus1_name" in LINE and "bus2_name" in LINE
        buses = self.__ss.Bus  # type: ignore
        bus1_name_idx = buses.name.v.index(LINE["bus1_name"])
        bus1_idx = buses.idx.v[bus1_name_idx]
        bus2_name_idx = buses.name.v.index(LINE["bus2_name"])
        bus2_idx = buses.idx.v[bus2_name_idx]

        return self.__add(
            model="Line", param_dict={"bus1": bus1_idx, "bus2": bus2_idx, **LINE}
        )

    def add_static_generators(self, pvs: list[dict]) -> list[Idx]:
        """
        Add multiple static photovoltaic generators to the analysis system.

        :param pvs: List of dictionaries containing parameters for each PV generator.

        :return: List of indices of the added PV generators.
        """
        return [self.add_static_generator(param_dict=PV) for PV in pvs]

    def add_static_generator(self, *, param_dict: dict) -> Idx:
        assert "bus_name" in param_dict
        bus_name = param_dict["bus_name"]
        buses = self.__ss.Bus  # type: ignore
        bus_name_idx = buses.name.v.index(bus_name)
        bus_idx = buses.idx.v[bus_name_idx]

        return self.__add(model="PV", param_dict=param_dict | {"bus": bus_idx})

    ## Dynamic models
    def add_dynamic_classic_generator(self, *, PV: dict, GENCLS: dict):
        """
        Add a dynamic classic generator to the analysis system. It uses GENCLS model
        for TDS.
        We must add first a static model (PV), and later substitute by
        a dynamic one (GENCLS).

        :param      PV: PV dictionary containing parameters for the static model.
        :param  GENCLS: GENCLS dictionary containing parameters for the dynamic model.

        :theory:
            CURENT/Andes PV model: https://docs.andes.app/en/latest/groupdoc/StaticGen.html#pv
            CURENT/Andes GENCLS:   https://docs.andes.app/en/latest/groupdoc/SynGen.html#gencls
        """
        assert "name" in PV
        pv_name = PV["name"]
        pv = self.__ss.PV  # type: ignore

        if pv_name and pv_name not in pv.name.v:
            pv_idx = self.add_static_generator(param_dict=PV)
        else:
            pv_idx = pv.idx.v[pv.name.v.index(pv_name)]

        pv_name_idx = pv.name.v.index(pv_name)  # index in name's array
        bus_idx = pv.bus.v[pv_name_idx]

        gencls_idx = self.__add(
            model="GENCLS",
            param_dict=GENCLS | {"gen": pv_idx, "bus": bus_idx},
        )

        return pv_idx, bus_idx, gencls_idx

    def add_photovoltaic_generator(self, *, PV: dict, REGCA1: dict) -> tuple[Idx, Idx]:
        """
        Add a photovoltaic generator to the dynamic analysis system. It uses REGCA1 model
        for the TDS.
        We must add first a static model (PV), and later substitute by
        a dynamic one (REGCA1).

        :param bus_idx: The bus index where the photovoltaic generator is connected.
        :param      PV: PV dictionary containing parameters for the static model.
        :param  REGCA1: REGCA1 dictionary containing parameters for the dynamic model.

        :example:
        PV : Power/Voltage controlled static generator
            e.g.:
            { "idx":  "1", "u": 1.0, "name": "PV 1",
              "Sn": 0.05, "Vn": 0.242, "bus": 7, "busr": None,
              "p0": 0.05, "q0": 0.0, "pmax": 0.05, "pmin": 0.0,
              "qmax": 0.02, "qmin": -0.02, "v0": 1.0, "vmax": 1.05,
              "vmin": 0.95, "ra": 0.02, "xs": 0.05 }
        REGCA1 : Dynamic model for photovoltaic generator
            e.g.:
            { "idx": 2, "u": 1.0, "name": "REGCA1 2", "bus": 20,
              "gen": "9", "Sn": 0.1, "Tg": 0.5, "Rrpwr": 10.0, "Brkpt": 0.9,
              "Zerox": 0.4, "Lvplsw": 1.0, "Lvpl1": 1.0, "Volim": 1.1,
              "Lvpnt1": 1.0, "Lvpnt0": 0.5, 'Iolim': -0.1, "Tfltr": 0.2,
              "Khv": 0.5, "Iqrmax": 1.0, "Iqrmin": -1.0, "Accel": 0.0,
              "gammap": 1.0, "gammaq": 1.0, },

        :theory:
            CURENT/Andes PV model:     https://docs.andes.app/en/latest/groupdoc/StaticGen.html#pv
            CURENT/Andes REGCA1 model: https://docs.andes.app/en/latest/groupdoc/RenGen.html#regca1
            Powerworld REGC_A model:   https://www.powerworld.com/WebHelp/Content/TransientModels_HTML/Machine%20Model%20REGC_A.htm
        """
        assert "name" in PV

        pv_name = PV["name"]
        pv = self.__ss.PV  # type: ignore

        if pv_name not in pv.name.v:
            pv_idx = self.add_static_generator(param_dict=PV)
        else:
            pv_idx = pv.idx.v[pv.name.v.index(pv_name)]

        pv_name_idx = pv.name.v.index(pv_name)  # index in name's array
        bus_idx = pv.bus.v[pv_name_idx]

        regca1_idx = self.__add(
            model="REGCA1",
            param_dict=REGCA1 | {"gen": pv_idx, "bus": bus_idx},
        )

        return pv_idx, regca1_idx

    def add_toggle(self, *, TOGGLE: dict) -> Idx:
        df = self.__ss.Line.as_df()  # type: ignore
        line_idx = df[df["name"] == TOGGLE["line_name"]]["idx"].values[0]

        return self.__add(model="Toggle", param_dict=TOGGLE | {"dev": line_idx})

    def __add(self, *, model: Model, param_dict: dict) -> Idx:
        """
        Internal method to add a model to dynamic analysis system.

        :param model: The model type to add (e.g., "REGCA1", "Line").
           Limited to models in CURENT/Andes: https://docs.andes.app/en/stable/modelref.html
        :param param_dict: Dictionary containing parameters for the model.
        :return: The index of the added model.
        """
        if model not in MODEL_DEFAULTS:
            raise ValueError(f"Model {model} is not supported.")

        return self.ss.add(
            model,
            param_dict=MODEL_DEFAULTS[model] | {"Sn": self.__base_power} | param_dict,
        )  # type: ignore

    ## Simulation
    def run_tds(self) -> None | int:
        """Run both powerflow and TDS"""
        tds, pflow = self.__ss.TDS, self.__ss.PFlow  # type: ignore

        self.ss.prepare()
        self.ss.setup()

        # Run power flow, needed before TDS.
        # Andes allows to run directly or in two steps.
        _ = pflow.run(default_config=True)
        computation_key = None

        if pflow.converged:
            # Very conservative TDS settings, defined by Copilot.
            tds.config.tf = 15.0
            tds.config.tstep = 0.002  # Very small time step
            tds.config.max_iter = 50  # Many iterations
            tds.config.tol = 1e-6  # Tight tolerance

            logging.info("\nRunning TDS with ultra-conservative parameters...")
            try:
                _ = tds.run(default_config=True)
                logging.info(f"✓ TDS Completed: {tds.converged}")
                computation_key = self.export_results()
                self.__dyn_results = DynamicResults(computation_key)
                df = self.__dyn_results.df
                self.__results_dict = {
                    "time": df.index.to_list(),
                    "values": self.__change_result_names(df.to_dict()),
                }
                _ = self.export_json()
            except Exception as e:
                logging.info(f"✗ TDS Failed: {e}")
                raise TDSComputationError(e)
        else:
            logging.info("✗ Power Flow failed, did not converge")
            raise PFlowUnestableError()

        return computation_key

    def export_results(self):
        """Model saves npz by default, that with lst made the same
        work than this csv, but they cannot be saved into `tmp`."""
        csv_path = get_model_name(self.__ts_key, "csv")
        # TODO: it could be exported from `ss.dae.df`.
        # We save all results and other request will extract only those we want.
        # We need to set up the plt to have the data loaded.
        tds = self.__ss.TDS  # type: ignore
        tds.plt
        tds.load_plotter()
        tds.plt.export_csv(csv_path)

        return self.__ts_key

    def export_json(self):
        json_output_path = get_model_name(self.__ts_key, ext="json", is_output=True)

        with open(json_output_path, "w") as file:
            json.dump(self.__results_dict, file, indent=4)

    # def get_element_results(
    #     self, *, model: AndesElement, indexes: list[str], **kwargs
    # ) -> list[dict] | dict[str, pd.DataFrame]:
    #     if kwargs.get("as_dict", False):
    #         return DynamicResults.get_elements_results_as_dict(
    #             model=model,
    #             indexes=indexes,
    #             df=self.__ss.dae.ts.df,
    #             to_list=kwargs.get("to_list", True),
    #         )

    #     return DynamicResults.get_element_results_as_df(
    #         model=model,
    #         indexes=indexes,
    #         df=self.__ss.dae.ts.df,
    #     )

    def __change_result_names(self, results: dict) -> dict:
        """Name adaption to original topology names.

        Andes changes the names in results with a mix of idx and model
        element name. The exported results use those names. Now we
        iterate over the full results dict and change the names to
        pandapower names (those actually defined in the mongo topology)
        so the results are actually useful."""
        new_results = {}
        for model in AndesModels:
            for measurement in get_measurements(self.ss, model):
                idxs = getattr(self.ss, model).idx.v
                names = getattr(self.ss, model).name.v
                for idx, name in zip(idxs, names):
                    col_name = f"{measurement} {next(get_element_names(model=model, indexes=[idx]))}"
                    new_results.setdefault(name, {})[measurement] = list(
                        results[col_name].values()
                    )

        return new_results

    @classmethod
    async def create_dynamic_analysis(
        cls,
        query: dict,
        *,
        mongo_config: None | MongoConfig = None,
        mongo_client: None | AsyncMongoClient = None,
        ups: None | dict = None,
        loads: None | dict = None,
        generators: None | dict = None,
        new_buses: list[dict] = [],
        new_lines: list[dict] = [],
        pvs: list[dict] = [],
        genclss: list[tuple[dict, dict]] = [],
        gen_regca1s: list[tuple[dict, dict]] = [],
        toggles: list[dict] = [],
        power_unit: Literal["W", "KW", "MW"] = "KW",
    ) -> "DynamicAnalysis":
        """
        Create and initialize a DynamicAnalysis object from MongoDB and user-supplied data.

        This is a high-level entry point for building a dynamic simulation case, including
        network topology, static and dynamic generators, and toggles for events.

        For every dynamic generator we need a tuple with the static one it will substitute
        during the dynamic phase analysis.

        Parameters
        ----------
        query : dict
            MongoDB query to select the base network (buses, lines, etc.).
        mongo_config : MongoConfig, optional
            MongoDB configuration object. Required if mongo_client is not provided.
        mongo_client : AsyncMongoClient, optional
            Existing MongoDB client. If not provided, one will be created from mongo_config.
        ups : dict, optional
            Usage point data (loads/generation) to add to the network.
        loads : dict, optional
            Additional loads to add to the network.
        generators : dict, optional
            Additional generators to add to the network.
        new_buses : list of dict, optional
            List of bus definitions to add to the network.
        new_lines : list of dict, optional
            List of line definitions to add to the network.
        pvs : list of dict, optional. PV -> Power & Voltage fixed
            List of static PV generator definitions.
        genclss : list of tuple(dict, dict), optional
            List of (PV, GENCLS) tuples for classic synchronous generators.
        gen_regca1s : list of tuple(dict, dict), optional
            List of (PV, REGCA1) tuples for renewable (grid-following) generators.
        toggles : list of dict, optional
            List of toggle event definitions (e.g., line trips).
        power_unit : Literal["W", "KW", "MW"], default "KW"
            Power unit for network creation.

        Returns
        -------
        DynamicAnalysis
            Initialized DynamicAnalysis object with all elements added.

        Notes
        -----
        - Dynamic elements (genclss, gen_regca1s) must be tuples of (static, dynamic) definitions.
        - This function builds the network, adds all elements, and returns the ready-to-use analysis object.
        - Use `run_tds()` on the returned object to perform time-domain simulation.

        Example
        -------
        >>> dyn = await DynamicAnalysis.create_dynamic_analysis(
        ...     query=query,
        ...     mongo_config=mongo_config,
        ...     new_buses=[...],
        ...     new_lines=[...],
        ...     pvs=[...],
        ...     genclss=[(pv_dict, gencls_dict)],
        ...     gen_regca1s=[(pv_dict, regca1_dict)],
        ...     toggles=[...]
        ... )
        >>> dyn.run_tds()
        """
        assert mongo_config is not None or mongo_client is not None
        client = (
            mongo_client
            if mongo_client is not None
            else AsyncMongoClient(mongo_config.url)  # type: ignore
        )
        network = EterPowerNetwork(mongo_client=client)
        await network.create_network(
            bus_query=query,
            loads=loads,
            generators=generators,
            usage_point_data=ups,
            allowed_no_geometry_data=True,
            power_unit=power_unit,
        )
        dyn = DynamicAnalysis(network=network.pp_net, base_power=0.1)
        _ = dyn.add_buses(new_buses)
        _ = dyn.add_lines(new_lines)
        _ = dyn.add_static_generators(pvs)

        for pv, gencls in genclss:
            _ = dyn.add_dynamic_classic_generator(PV=pv, GENCLS=gencls)

        for pv, gen_regca1 in gen_regca1s:
            _ = dyn.add_photovoltaic_generator(PV=pv, REGCA1=gen_regca1)

        for toggle in toggles:
            _ = dyn.add_toggle(TOGGLE=toggle)

        return dyn


class DynamicResults:
    def __init__(self, ts):
        self.__csv_path: Path = get_model_name(ts, "csv")
        self.__json_path: Path = get_model_name(ts, "json", is_output=True)

    @property
    def df(self):
        if not self.__csv_path.exists():
            raise FileDoesNotExists(self.__csv_path)

        return pd.read_csv(self.__csv_path, index_col="Time [s]")

    def compacted_results(self):
        """Results with index, var names and values in different entries

        This way the size of the result is reduced. The original way, with
        each column being a dict with entires time and value the result, is
        quite heavy to be send through network."""
        df = self.df

        return {
            "time": df.index.to_list(),
            "variables": list(df.columns),
            "matrix": df.to_numpy().T.tolist(),
        }

    def element_results(self, *, names: list):
        if not self.__json_path.exists():
            raise FileDoesNotExists(self.__json_path)

        with open(self.__json_path, "r") as file:
            loaded_data = json.load(file)

            return {
                **loaded_data,
                "values": {k: loaded_data["values"][k] for k in names},
            }

    # def get_element_results(
    #     self, *, model: AndesElement, indexes: list[str], **kwargs
    # ) -> list[dict] | dict[str, pd.DataFrame]:
    #     if kwargs.get("as_dict", False):
    #         return DynamicResults.get_elements_results_as_dict(
    #             model=model,
    #             indexes=indexes,
    #             df=self.df,
    #             to_list=kwargs.get("to_list", True),
    #         )

    #     return DynamicResults.get_element_results_as_df(
    #         model=model,
    #         indexes=indexes,
    #         df=self.df,
    #     )

    # Because design change this 2 class methods maybe
    # don't need to be static anymore so they could be
    # instance methods.
    # @classmethod
    # def get_element_results_as_df(
    #     cls, *, model: AndesElement, indexes: list[str], df: pd.DataFrame
    # ) -> dict[str, pd.DataFrame]:
    #     columns = get_element_names(model=model, indexes=indexes)
    #     response = {}
    #     for index, col in zip(indexes, columns):
    #         response[index] = df.loc[:, df.columns.str.contains(col)]

    #     return response

    # @classmethod
    # def get_elements_results_as_dict(
    #     cls, *, model: AndesElement, indexes: list[str], df: pd.DataFrame, to_list=True
    # ) -> list[dict]:
    #     """
    #     Get time-domain simulation results as a list of dictionaries.

    #     This method extracts simulation results for specified Andes elements and indexes,
    #     returning a list of dictionaries with time series data for each element.

    #     Parameters
    #     ----------
    #     model : AndesElement
    #         The Andes element type to retrieve results for (e.g., "Line", "GENCLS").
    #     indexes : list of str
    #         List of element indexes in Andes for which to retrieve results.
    #     to_list : bool, optional
    #         If True (default), results are returned as Python lists (not numpy arrays).

    #     Returns
    #     -------
    #     list of dict
    #         Each dictionary contains:
    #             - "index": Index of the Andes element
    #             - "time": List of TDS time values (seconds)
    #             - "variables": List of variable names for the element
    #             - "matrix": List of lists, each inner list is a variable time series

    #     Notes
    #     -----
    #     - If `to_list` is False, time and matrix are returned as numpy arrays.
    #     - This is a convenience wrapper for extracting results in a portable format.

    #     Example
    #     -------
    #     >>> results = DynamicResults.get_elements_results_as_dict(
    #     ...     model="GENCLS",
    #     ...     indexes=["1", "2"],
    #     ...     df=tds_df,
    #     ...     to_list=True
    #     ... )
    #     >>> print(results[0]["variables"])
    #     ['GENCLS 1 omega', 'GENCLS 1 Pe', ...]
    #     """
    #     values = DynamicResults.get_element_results_as_df(
    #         model=model, indexes=indexes, df=df
    #     )

    #     if to_list:
    #         return [
    #             {
    #                 "index": k,
    #                 "time": v.index.to_list(),
    #                 "variables": list(v.columns),
    #                 "matrix": v.to_numpy().T.tolist(),
    #             }
    #             for k, v in values.items()
    #         ]

    #     return [
    #         {
    #             "index": k,
    #             "time": v.index,
    #             "variables": v.columns,
    #             "matrix": v.to_numpy().T,
    #         }
    #         for k, v in values.items()
    #     ]


# class DynamicResults_DEPRECATED:
#     def __init__(self, ts):
#         # Problem with this, we cannot specify where these files
#         # are going to be created, they are saved at same place
#         # the file is calling the `run` function.
#         self.__npz_path = get_model_name(ts, "npz", is_output=True)
#         self.__lst_path = get_model_name(ts, "lst", is_output=True)

#     def load_npz(self):
#         with np.load(self.__npz_path) as data:
#             return data["data"]

#     def load_lst(self):
#         with open(self.__lst_path, "r") as file:
#             lines = file.readlines()

#         return [line.strip().split(",")[1].strip() for line in lines]

#     @property
#     def df(self) -> pd.DataFrame:
#         npz, lst = self.load_npz(), self.load_lst()
#         index_column = npz[:, 0]
#         data_matrix = npz[:, 1:]

#         return pd.DataFrame(
#             data_matrix,
#             columns=lst[1:],  # type: ignore
#             index=index_column,
#         )
