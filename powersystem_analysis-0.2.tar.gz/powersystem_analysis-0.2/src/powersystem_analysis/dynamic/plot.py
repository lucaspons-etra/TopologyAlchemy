#!/usr/bin/env python3
"""
Network plotting script for ANDES power system cases.
This script demonstrates various ways to visualize power system networks.
"""

import andes
import matplotlib.pyplot as plt
import networkx as nx
import plotly.graph_objects as go


def create_graph_from_andes(ss: andes.System) -> nx.Graph:
    G = nx.Graph()

    # for i, bus_idx in enumerate(ss.Bus.idx.v):
    #     bus_name = ss.Bus.name.v[i] if ss.Bus.name.v[i] else f"Bus_{bus_idx}"
    #     G.add_node(
    #         bus_idx,
    #         name=bus_name,
    #         voltage=ss.Bus.Vn.v[i],
    #         area=ss.Bus.area.v[i],
    #         has_generator=False,
    #         generator_type=None,
    #         generator_capacity=0.0,
    #         node_type="bus",
    #     )
    for i in range(ss.Line.n):
        bus1 = ss.Line.bus1.v[i]
        bus2 = ss.Line.bus2.v[i]
        line_name = ss.Line.name.v[i] if ss.Line.name.v[i] else f"Line_{i}"
        is_transformer = ss.Line.tap.v[i] != 1.0 or ss.Line.phi.v[i] != 0.0

        G.add_edge(
            bus1,
            bus2,
            name=line_name,
            impedance=complex(ss.Line.r.v[i], ss.Line.x.v[i]),
            transformer=is_transformer,
            edge_type="line",
        )

    # Adding complex elements.
    # element_counter = 0
    generator_nodes = []
    load_nodes = []
    slack_buses = set()
    pv_buses = set()
    gencls_buses = set()
    genrou_buses = set()
    plbvfu1_buses = set()

    # Check for Slack generators (reference buses)
    if hasattr(ss, "Slack") and ss.Slack.n > 0:
        for i in range(ss.Slack.n):
            bus_idx = ss.Slack.bus.v[i]
            slack_buses.add(bus_idx)

            gen_node_id = (
                ss.Slack.name.v[i] if hasattr(ss.Slack, "name") else f"Slack_{i}"
            )
            generator_nodes.append(gen_node_id)

            # Add generator node
            G.add_node(
                gen_node_id,
                node_type="slack_generator",
                capacity=ss.Slack.Sn.v[i] if hasattr(ss.Slack, "Sn") else 0.0,
                bus_connection=bus_idx,
            )

            # Connect generator to bus with dashed line
            G.add_edge(
                gen_node_id,
                bus_idx,
                edge_type="generator_connection",
                connection_type="slack",
            )

    # Check for PV generators (voltage-controlled generators)
    if hasattr(ss, "PV") and ss.PV.n > 0:
        for i in range(ss.PV.n):
            bus_idx = ss.PV.bus.v[i]
            pv_buses.add(bus_idx)

            # Create separate generator node
            gen_node_id = ss.PV.name.v[i] if hasattr(ss.PV, "name") else f"PV_{i}"
            # element_counter += 1
            generator_nodes.append(gen_node_id)

            # Add generator node
            G.add_node(
                gen_node_id,
                name=gen_node_id,
                node_type="pv_generator",
                capacity=ss.PV.Sn.v[i] if hasattr(ss.PV, "Sn") else 0.0,
                bus_connection=bus_idx,
            )

            # Connect generator to bus with dashed line
            G.add_edge(
                gen_node_id,
                bus_idx,
                edge_type="generator_connection",
                connection_type="pv",
            )

    # Check for GENCLS generators (Classical synchronous generators)
    if hasattr(ss, "GENCLS") and ss.GENCLS.n > 0:
        for i in range(ss.GENCLS.n):
            bus_idx = ss.GENCLS.bus.v[i]
            gencls_buses.add(bus_idx)

            # Create separate generator node
            gen_node_id = (
                ss.GENCLS.name.v[i] if hasattr(ss.GENCLS, "name") else f"GENCLS_{i}"
            )
            # element_counter += 1
            generator_nodes.append(gen_node_id)

            # Add generator node
            G.add_node(
                gen_node_id,
                name=gen_node_id,
                node_type="gencls_generator",
                capacity=ss.GENCLS.Sn.v[i] if hasattr(ss.GENCLS, "Sn") else 0.0,
                bus_connection=bus_idx,
            )

            # Connect generator to bus with dashed line
            G.add_edge(
                gen_node_id,
                bus_idx,
                edge_type="generator_connection",
                connection_type="gencls",
            )

    if hasattr(ss, "GENROU") and ss.GENROU.n > 0:
        for i in range(ss.GENROU.n):
            bus_idx = ss.GENROU.bus.v[i]
            genrou_buses.add(bus_idx)

            # Create separate generator node
            gen_node_id = (
                ss.GENROU.name.v[i] if hasattr(ss.GENROU, "name") else f"GENROU_{i}"
            )
            # element_counter += 1
            generator_nodes.append(gen_node_id)

            # Add generator node
            G.add_node(
                gen_node_id,
                name=gen_node_id,
                node_type="genrou_generator",
                capacity=ss.GENROU.Sn.v[i] if hasattr(ss.GENROU, "Sn") else 0.0,
                bus_connection=bus_idx,
            )

            # Connect generator to bus with dashed line
            G.add_edge(
                gen_node_id,
                bus_idx,
                edge_type="generator_connection",
                connection_type="genrou",
            )

    if hasattr(ss, "REGCA1") and ss.REGCA1.n > 0:
        for i in range(ss.REGCA1.n):
            bus_idx = ss.REGCA1.bus.v[i]
            genrou_buses.add(bus_idx)

            gen_node_id = (
                ss.REGCA1.name.v[i] if hasattr(ss.REGCA1, "name") else f"REGCA1_{i}"
            )
            generator_nodes.append(gen_node_id)

            G.add_node(
                gen_node_id,
                name=gen_node_id,
                node_type="regca1_generator",
                capacity=ss.REGCA1.Sn.v[i] if hasattr(ss.REGCA1, "Sn") else 0.0,
                bus_connection=bus_idx,
            )

            G.add_edge(
                gen_node_id,
                bus_idx,
                edge_type="generator_connection",
                connection_type="regca1",
            )

    # Check for PLBVFU1 generators (Power plant model)
    if hasattr(ss, "PLBVFU1") and ss.PLBVFU1.n > 0:
        for i in range(ss.PLBVFU1.n):
            bus_idx = ss.PLBVFU1.bus.v[i]
            plbvfu1_buses.add(bus_idx)

            # Create separate generator node
            gen_node_id = (
                ss.PLBVFU1.name.v[i] if hasattr(ss.PLBVFU1, "name") else f"PLBVFU1_{i}"
            )
            # element_counter += 1
            generator_nodes.append(gen_node_id)

            # Add generator node
            G.add_node(
                gen_node_id,
                name=gen_node_id,
                node_type="plbvfu1_generator",
                capacity=ss.PLBVFU1.Sn.v[i] if hasattr(ss.PLBVFU1, "Sn") else 0.0,
                bus_connection=bus_idx,
            )

            # Connect generator to bus with dashed line
            G.add_edge(
                gen_node_id,
                bus_idx,
                edge_type="generator_connection",
                connection_type="plbvfu1",
            )

    # Check for loads (PQ buses)
    if hasattr(ss, "PQ") and ss.PQ.n > 0:
        for i in range(ss.PQ.n):
            bus_idx = ss.PQ.bus.v[i]

            # Create separate load node
            load_node_id = ss.PQ.name.v[i] if hasattr(ss.PQ, "name") else f"Load_{i}"
            # element_counter += 1
            load_nodes.append(load_node_id)

            # Add load node
            G.add_node(
                load_node_id,
                name=load_node_id,
                node_type="load",
                power_p=ss.PQ.P0.v[i] if hasattr(ss.PQ, "P0") else 0.0,
                power_q=ss.PQ.Q0.v[i] if hasattr(ss.PQ, "Q0") else 0.0,
                bus_connection=bus_idx,
            )

            # Connect load to bus with dashed line
            G.add_edge(
                load_node_id,
                bus_idx,
                edge_type="load_connection",
                connection_type="load",
            )

    return G

def plot_basic_network_topology(
    ss, figsize=(14, 10), aspect_ratio=None, ax=None, debug=True, show_line_names=True
):
    """Create a basic network topology plot using NetworkX with generator visualization.

    Parameters:
    -----------
    ss : andes.System
        The ANDES power system object
    figsize : tuple, optional
        Figure size as (width, height) in inches. Default is (14, 10)
    aspect_ratio : float, optional
        Aspect ratio (width/height) for the plot. If provided, overrides figsize height
    ax : matplotlib.axes.Axes, optional
        Pre-existing axes to plot on. If None, creates new figure and axes
    debug : bool, optional
        Whether to print debug information. Default is True
    show_line_names : bool, optional
        Whether to display line names on the plot. Default is False

    Returns:
    --------
    tuple
        (G, pos, ax) where G is the NetworkX graph, pos is the layout positions,
        and ax is the matplotlib axes object
    """
    G = create_graph_from_andes(ss)
    # Generate layout
    pos = nx.kamada_kawai_layout(G)

    # Separate nodes by type
    regular_buses = []
    slack_gen_nodes = []
    pv_gen_nodes = []
    gencls_gen_nodes = []
    regca1_gen_nodes = []
    genrou_gen_nodes = []
    plbvfu1_gen_nodes = []
    load_nodes_list = []

    for node in G.nodes():
        node_type = G.nodes[node].get("node_type", "bus")

        if node_type == "bus":
            regular_buses.append(node)
        elif node_type == "slack_generator":
            slack_gen_nodes.append(node)
        elif node_type == "pv_generator":
            pv_gen_nodes.append(node)
        elif node_type == "gencls_generator":
            gencls_gen_nodes.append(node)
        elif node_type == "regca1_generator":
            regca1_gen_nodes.append(node)
        elif node_type == "genrou_generator":
            genrou_gen_nodes.append(node)
        elif node_type == "plbvfu1_generator":
            plbvfu1_gen_nodes.append(node)
        elif node_type == "load":
            load_nodes_list.append(node)


    # Create or use provided axes
    if ax is None:
        # Calculate figure size based on aspect ratio if provided
        if aspect_ratio is not None:
            width = figsize[0]
            height = width / aspect_ratio
            figsize = (width, height)

        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.get_figure()

    # Draw different types of nodes with different styles
    # Regular buses
    if regular_buses:
        nx.draw_networkx_nodes(
            G,
            pos,
            nodelist=regular_buses,
            node_color="lightblue",
            node_size=400,
            alpha=0.8,
            node_shape="o",
            ax=ax,
        )

    # Slack generators - red squares
    if slack_gen_nodes:
        nx.draw_networkx_nodes(
            G,
            pos,
            nodelist=slack_gen_nodes,
            node_color="red",
            node_size=800,
            alpha=0.9,
            node_shape="s",  # Square shape
            edgecolors="darkred",
            linewidths=2,
            ax=ax,
        )

    # PV generators - green triangles
    if pv_gen_nodes:
        nx.draw_networkx_nodes(
            G,
            pos,
            nodelist=pv_gen_nodes,
            node_color="green",
            node_size=700,
            alpha=0.9,
            node_shape="^",  # Triangle shape
            edgecolors="darkgreen",
            linewidths=2,
            ax=ax,
        )

    # GENCLS generators - orange diamonds
    if gencls_gen_nodes:
        nx.draw_networkx_nodes(
            G,
            pos,
            nodelist=gencls_gen_nodes,
            node_color="orange",
            node_size=600,
            alpha=0.9,
            node_shape="D",  # Diamond shape
            edgecolors="darkorange",
            linewidths=2,
            ax=ax,
        )

    # REGCA1 generators - orange diamonds
    if regca1_gen_nodes:
        nx.draw_networkx_nodes(
            G,
            pos,
            nodelist=regca1_gen_nodes,
            node_color="orange",
            node_size=600,
            alpha=0.9,
            node_shape="o",  # Diamond shape
            edgecolors="darkorange",
            linewidths=2,
            ax=ax,
        )

    # GENROU generators - purple hexagons
    if genrou_gen_nodes:
        nx.draw_networkx_nodes(
            G,
            pos,
            nodelist=genrou_gen_nodes,
            node_color="purple",
            node_size=650,
            alpha=0.9,
            node_shape="h",  # Hexagon shape
            edgecolors="darkviolet",
            linewidths=2,
            ax=ax,
        )

    # PLBVFU1 generators - brown pentagons
    if plbvfu1_gen_nodes:
        nx.draw_networkx_nodes(
            G,
            pos,
            nodelist=plbvfu1_gen_nodes,
            node_color="brown",
            node_size=650,
            alpha=0.9,
            node_shape="p",  # Pentagon shape
            edgecolors="saddlebrown",
            linewidths=2,
            ax=ax,
        )

    # Load nodes - blue circles
    if load_nodes_list:
        nx.draw_networkx_nodes(
            G,
            pos,
            nodelist=load_nodes_list,
            node_color="skyblue",
            node_size=500,
            alpha=0.9,
            node_shape="o",  # Circle shape
            edgecolors="darkblue",
            linewidths=2,
            ax=ax,
        )

    # Draw lines and transformers
    regular_edges = [
        (u, v)
        for u, v, d in G.edges(data=True)
        if d.get("edge_type") == "line" and not d.get("transformer", False)
    ]
    transformer_edges = [
        (u, v)
        for u, v, d in G.edges(data=True)
        if d.get("edge_type") == "line" and d.get("transformer", False)
    ]
    generator_connection_edges = [
        (u, v)
        for u, v, d in G.edges(data=True)
        if d.get("edge_type") == "generator_connection"
    ]
    load_connection_edges = [
        (u, v)
        for u, v, d in G.edges(data=True)
        if d.get("edge_type") == "load_connection"
    ]

    # Draw transmission lines
    nx.draw_networkx_edges(
        G, pos, edgelist=regular_edges, edge_color="black", width=2, alpha=0.7, ax=ax
    )

    # Draw transformers
    nx.draw_networkx_edges(
        G,
        pos,
        edgelist=transformer_edges,
        edge_color="red",
        width=2.5,
        alpha=0.8,
        style="dashed",
        ax=ax,
    )

    # Draw generator connections with dashed lines
    nx.draw_networkx_edges(
        G,
        pos,
        edgelist=generator_connection_edges,
        edge_color="darkgreen",
        width=1.5,
        alpha=0.6,
        style="dashed",
        ax=ax,
    )

    # Draw load connections with dashed lines
    nx.draw_networkx_edges(
        G,
        pos,
        edgelist=load_connection_edges,
        edge_color="blue",
        width=1.5,
        alpha=0.6,
        style="dashed",
        ax=ax,
    )

    # Add line names if requested
    if show_line_names:
        # Create labels for lines (transmission lines and transformers only)
        line_labels = {}
        for u, v, d in G.edges(data=True):
            if d.get("edge_type") == "line":
                line_name = d.get("name", f"Line_{u}_{v}")
                line_labels[(u, v)] = line_name

        # Draw line labels
        if line_labels:
            # Calculate positions for edge labels (midpoints)
            edge_pos = {}
            for (u, v), label in line_labels.items():
                edge_pos[(u, v)] = (
                    (pos[u][0] + pos[v][0]) / 2,
                    (pos[u][1] + pos[v][1]) / 2,
                )

            # Draw the edge labels
            for (u, v), label_pos in edge_pos.items():
                ax.text(
                    label_pos[0],
                    label_pos[1],
                    line_labels[(u, v)],
                    fontsize=6,
                    ha="center",
                    va="center",
                    bbox=dict(
                        boxstyle="round,pad=0.2",
                        facecolor="white",
                        alpha=0.8,
                        edgecolor="gray",
                    ),
                    rotation=0,  # You can adjust rotation based on line angle if needed
                )

    # Add labels for all nodes
    nx.draw_networkx_labels(G, pos, font_size=8, font_weight="bold", ax=ax)

    # Add capacity/power labels for generators and loads
    element_labels = {}
    for node in G.nodes():
        node_data = G.nodes[node]
        if node_data.get("node_type") in [
            "slack_generator",
            "pv_generator",
            "regca1_generator",
            "gencls_generator",
            "genrou_generator",
            "plbvfu1_generator",
        ]:
            capacity = node_data.get("capacity", 0)
            if capacity > 0:
                element_labels[node] = f"{capacity:.1f} MVA"
        elif node_data.get("node_type") == "load":
            power_p = node_data.get("power_p", 0)
            power_q = node_data.get("power_q", 0)
            if power_p != 0 or power_q != 0:
                element_labels[node] = f"P:{power_p:.1f}\nQ:{power_q:.1f}"

    if element_labels:
        # Position labels slightly offset from nodes
        label_pos = {
            node: (pos[node][0], pos[node][1] - 0.15) for node in element_labels
        }
        nx.draw_networkx_labels(
            G,
            label_pos,
            labels=element_labels,
            font_size=6,
            font_color="purple",
            font_weight="bold",
            ax=ax,
        )

    ax.set_title(
        "Power System Network Topology with Generator Types",
        fontsize=14,
        fontweight="bold",
    )
    ax.axis("off")

    # Create comprehensive legend
    from matplotlib.lines import Line2D

    legend_elements = [
        Line2D([0], [0], color="black", lw=2, label="Transmission Lines"),
        Line2D([0], [0], color="red", lw=2, linestyle="--", label="Transformers"),
        Line2D(
            [0],
            [0],
            color="darkgreen",
            lw=1.5,
            linestyle="--",
            label="Generator Connections",
        ),
        Line2D(
            [0], [0], color="blue", lw=1.5, linestyle="--", label="Load Connections"
        ),
        Line2D(
            [0],
            [0],
            marker="o",
            color="w",
            markerfacecolor="lightblue",
            markersize=10,
            label="Bus",
            linestyle="None",
        ),
        Line2D(
            [0],
            [0],
            marker="s",
            color="w",
            markerfacecolor="red",
            markersize=12,
            label="Slack Generator",
            linestyle="None",
        ),
        Line2D(
            [0],
            [0],
            marker="^",
            color="w",
            markerfacecolor="green",
            markersize=12,
            label="PV Generator",
            linestyle="None",
        ),
        Line2D(
            [0],
            [0],
            marker="D",
            color="w",
            markerfacecolor="orange",
            markersize=10,
            label="GENCLS Generator",
            linestyle="None",
        ),
        Line2D(
            [0],
            [0],
            marker="h",
            color="w",
            markerfacecolor="orange",
            markersize=10,
            label="regca1 Generator",
            linestyle="None",
        ),
        Line2D(
            [0],
            [0],
            marker="h",
            color="w",
            markerfacecolor="purple",
            markersize=10,
            label="GENROU Generator",
            linestyle="None",
        ),
        Line2D(
            [0],
            [0],
            marker="p",
            color="w",
            markerfacecolor="brown",
            markersize=10,
            label="PLBVFU1 Generator",
            linestyle="None",
        ),
        Line2D(
            [0],
            [0],
            marker="o",
            color="w",
            markerfacecolor="skyblue",
            markersize=10,
            label="Load",
            linestyle="None",
        ),
    ]

    # Add legend to the axes
    ax.legend(handles=legend_elements, loc="upper right", bbox_to_anchor=(1.15, 1))

    # Adjust layout if we created the figure
    if "fig" in locals():
        fig.tight_layout()

    if debug:
        print("\nPower System Elements Summary:")
        print(f"  Buses: {len(regular_buses)}")
        print(f"  Slack Generators: {len(slack_gen_nodes)}")
        print(f"  PV Generators: {len(pv_gen_nodes)}")
        print(f"  GENCLS Generators: {len(gencls_gen_nodes)}")
        print(f"  GENROU Generators: {len(genrou_gen_nodes)}")
        print(f"  PLBVFU1 Generators: {len(plbvfu1_gen_nodes)}")
        print(f"  Loads: {len(load_nodes_list)}")
        total_gens = (
            len(slack_gen_nodes)
            + len(pv_gen_nodes)
            + len(gencls_gen_nodes)
            + len(genrou_gen_nodes)
            + len(plbvfu1_gen_nodes)
        )
        print(f"  Total Generators: {total_gens}")
        print(
            f"  Total Elements: {len(regular_buses) + total_gens + len(load_nodes_list)}"
        )

    return G, pos, ax


def plot_plotly_network_topology(
    ss, width=1200, height=800, debug=False, show_line_names=False
):
    """Create an interactive network topology plot using Plotly with generator visualization.

    Parameters:
    -----------
    ss : andes.System
        The ANDES power system object
    width : int, optional
        Figure width in pixels. Default is 1200
    height : int, optional
        Figure height in pixels. Default is 800
    debug : bool, optional
        Whether to print debug information. Default is True
    show_line_names : bool, optional
        Whether to display line names on hover. Default is True

    Returns:
    --------
    plotly.graph_objects.Figure
        The interactive Plotly figure
    """
    G = create_graph_from_andes(ss)
    
    pos = nx.kamada_kawai_layout(G)
    
    fig = go.Figure()
    
    regular_buses = []
    slack_gen_nodes = []
    pv_gen_nodes = []
    gencls_gen_nodes = []
    regca1_gen_nodes = []
    genrou_gen_nodes = []
    plbvfu1_gen_nodes = []
    load_nodes_list = []

    for node in G.nodes():
        node_type = G.nodes[node].get("node_type", "bus")
        
        if node_type == "bus":
            regular_buses.append(node)
        elif node_type == "slack_generator":
            slack_gen_nodes.append(node)
        elif node_type == "pv_generator":
            pv_gen_nodes.append(node)
        elif node_type == "gencls_generator":
            gencls_gen_nodes.append(node)
        elif node_type == "regca1_generator":
            regca1_gen_nodes.append(node)
        elif node_type == "genrou_generator":
            genrou_gen_nodes.append(node)
        elif node_type == "plbvfu1_generator":
            plbvfu1_gen_nodes.append(node)
        elif node_type == "load":
            load_nodes_list.append(node)
    
    def create_node_trace(node_list, color, symbol, size, name, node_type_key):
        if not node_list:
            return None
            
        x_coords = [pos[node][0] for node in node_list]
        y_coords = [pos[node][1] for node in node_list]
        
        hover_text = []
        for node in node_list:
            node_data = G.nodes[node]
            text = f"<b>{node}</b><br>Type: {name}<br>"
            
            if node_type_key in ["slack_generator", "pv_generator", "gencls_generator", 
                                "regca1_generator", "genrou_generator", "plbvfu1_generator"]:
                capacity = node_data.get("capacity", 0)
                if capacity > 0:
                    text += f"Capacity: {capacity:.1f} MVA<br>"
                bus_conn = node_data.get("bus_connection", "")
                if bus_conn:
                    text += f"Connected to Bus: {bus_conn}"
            elif node_type_key == "load":
                power_p = node_data.get("power_p", 0)
                power_q = node_data.get("power_q", 0)
                text += f"P: {power_p:.1f} MW<br>Q: {power_q:.1f} MVAr<br>"
                bus_conn = node_data.get("bus_connection", "")
                if bus_conn:
                    text += f"Connected to Bus: {bus_conn}"
                    
            hover_text.append(text)
        
        return go.Scatter(
            x=x_coords,
            y=y_coords,
            mode='markers+text',
            marker=dict(
                size=size,
                color=color,
                symbol=symbol,
                line=dict(width=2, color='black')
            ),
            text=[str(node) for node in node_list],
            textposition="middle center",
            textfont=dict(size=8, color='black'),
            hovertext=hover_text,
            hoverinfo='text',
            name=name,
            legendgroup=name
        )
    

    regular_edges = [
        (u, v) for u, v, d in G.edges(data=True)
        if d.get("edge_type") == "line" and not d.get("transformer", False)
    ]

    if regular_edges:
        line_x = []
        line_y = []
        line_hover_text = []

        for u, v in regular_edges:
            line_x.extend([pos[u][0], pos[v][0], None])
            line_y.extend([pos[u][1], pos[v][1], None])

            edge_data = G.edges[u, v]
            line_name = edge_data.get("name", f"Line_{u}_{v}")
            impedance = edge_data.get("impedance", 0)
            hover_text = f"<b>{line_name}</b><br>From: {u} To: {v}<br>Impedance: {impedance:.4f}"
            # line_hover_text.extend([hover_text, hover_text, None])
            line_hover_text.append(hover_text)

        line_trace = go.Scatter(
            x=line_x,
            y=line_y,
            mode='lines',
            line=dict(width=2, color='black'),
            text=[str(edge) for edge in regular_edges],
            hovertext=line_hover_text,
            hoverinfo='text',
            name='Transmission Lines',
            legendgroup='lines'
        )
        fig.add_trace(line_trace)

    transformer_edges = [
        (u, v) for u, v, d in G.edges(data=True)
        if d.get("edge_type") == "line" and d.get("transformer", False)
    ]

    if transformer_edges:
        trans_x = []
        trans_y = []
        trans_hover_text = []
        
        for u, v in transformer_edges:
            trans_x.extend([pos[u][0], pos[v][0], None])
            trans_y.extend([pos[u][1], pos[v][1], None])
            
            edge_data = G.edges[u, v]
            line_name = edge_data.get("name", f"Transformer_{u}_{v}")
            impedance = edge_data.get("impedance", 0)
            hover_text = f"<b>{line_name}</b><br>From: {u} To: {v}<br>Impedance: {impedance:.4f}<br>Type: Transformer"
            trans_hover_text.extend([hover_text, hover_text, None])
        
        trans_trace = go.Scatter(
            x=trans_x,
            y=trans_y,
            mode='lines',
            line=dict(width=3, color='red', dash='dash'),
            hovertext=trans_hover_text,
            hoverinfo='text',
            name='Transformers',
            legendgroup='transformers'
        )
        fig.add_trace(trans_trace)
    
    # Generator connections
    generator_connection_edges = [
        (u, v) for u, v, d in G.edges(data=True)
        if d.get("edge_type") == "generator_connection"
    ]
    
    if generator_connection_edges:
        gen_conn_x = []
        gen_conn_y = []
        
        for u, v in generator_connection_edges:
            gen_conn_x.extend([pos[u][0], pos[v][0], None])
            gen_conn_y.extend([pos[u][1], pos[v][1], None])
        
        gen_conn_trace = go.Scatter(
            x=gen_conn_x,
            y=gen_conn_y,
            mode='lines',
            line=dict(width=1.5, color='darkgreen', dash='dash'),
            hoverinfo='skip',
            name='Generator Connections',
            legendgroup='gen_connections',
            showlegend=True
        )
        fig.add_trace(gen_conn_trace)
    
    # Load connections
    load_connection_edges = [
        (u, v) for u, v, d in G.edges(data=True)
        if d.get("edge_type") == "load_connection"
    ]
    
    if load_connection_edges:
        load_conn_x = []
        load_conn_y = []
        
        for u, v in load_connection_edges:
            load_conn_x.extend([pos[u][0], pos[v][0], None])
            load_conn_y.extend([pos[u][1], pos[v][1], None])
        
        load_conn_trace = go.Scatter(
            x=load_conn_x,
            y=load_conn_y,
            mode='lines',
            line=dict(width=1.5, color='blue', dash='dash'),
            hoverinfo='skip',
            name='Load Connections',
            legendgroup='load_connections',
            showlegend=True
        )
        fig.add_trace(load_conn_trace)
    
    if regular_buses:
        bus_trace = create_node_trace(
            regular_buses, 'lightblue', 'circle', 20, 'Bus', 'bus'
        )
        if bus_trace:
            fig.add_trace(bus_trace)
    
    if load_nodes_list:
        load_trace = create_node_trace(
            load_nodes_list, 'skyblue', 'circle', 25, 'Load', 'load'
        )
        if load_trace:
            fig.add_trace(load_trace)
    
    if slack_gen_nodes:
        slack_trace = create_node_trace(
            slack_gen_nodes, 'red', 'square', 30, 'Slack Generator', 'slack_generator'
        )
        if slack_trace:
            fig.add_trace(slack_trace)
    
    # PV generators
    if pv_gen_nodes:
        pv_trace = create_node_trace(
            pv_gen_nodes, 'green', 'triangle-up', 28, 'PV Generator', 'pv_generator'
        )
        if pv_trace:
            fig.add_trace(pv_trace)
    
    if gencls_gen_nodes:
        gencls_trace = create_node_trace(
            gencls_gen_nodes, 'orange', 'diamond', 26, 'GENCLS Generator', 'gencls_generator'
        )
        if gencls_trace:
            fig.add_trace(gencls_trace)
    
    if regca1_gen_nodes:
        regca1_trace = create_node_trace(
            regca1_gen_nodes, 'orange', 'circle', 26, 'REGCA1 Generator', 'regca1_generator'
        )
        if regca1_trace:
            fig.add_trace(regca1_trace)
    
    if genrou_gen_nodes:
        genrou_trace = create_node_trace(
            genrou_gen_nodes, 'purple', 'hexagon', 26, 'GENROU Generator', 'genrou_generator'
        )
        if genrou_trace:
            fig.add_trace(genrou_trace)

    if plbvfu1_gen_nodes:
        plbvfu1_trace = create_node_trace(
            plbvfu1_gen_nodes, 'brown', 'pentagon', 26, 'PLBVFU1 Generator', 'plbvfu1_generator'
        )
        if plbvfu1_trace:
            fig.add_trace(plbvfu1_trace)
    
    if show_line_names:
        line_edges = [
            (u, v) for u, v, d in G.edges(data=True)
            if d.get("edge_type") == "line"
        ]
        
        for u, v in line_edges:
            edge_data = G.edges[u, v]
            line_name = edge_data.get("name", f"Line_{u}_{v}")

            mid_x = (pos[u][0] + pos[v][0]) / 2
            mid_y = (pos[u][1] + pos[v][1]) / 2

            fig.add_annotation(
                x=mid_x,
                y=mid_y,
                text=line_name,
                showarrow=False,
                font=dict(size=8, color='black'),
                bgcolor='rgba(255, 255, 255, 0.8)',
                bordercolor='gray',
                borderwidth=1,
                borderpad=2
            )

    fig.update_layout(
        title={
            'text': 'Interactive Power System Network Topology',
            'x': 0.5,
            'xanchor': 'center',
            'font': {'size': 16, 'color': 'black'}
        },
        width=width,
        height=height,
        showlegend=True,
        legend=dict(
            x=1.02,
            y=1,
            traceorder='normal',
            orientation='v'
        ),
        xaxis=dict(
            showgrid=False,
            zeroline=False,
            showticklabels=False,
            scaleanchor='y',
            scaleratio=1
        ),
        yaxis=dict(
            showgrid=False,
            zeroline=False,
            showticklabels=False
        ),
        plot_bgcolor='white',
        margin=dict(l=20, r=150, t=50, b=20),
        hovermode='closest'
    )
    
    if debug:
        print("\nPower System Elements Summary:")
        print(f"  Buses: {len(regular_buses)}")
        print(f"  Slack Generators: {len(slack_gen_nodes)}")
        print(f"  PV Generators: {len(pv_gen_nodes)}")
        print(f"  GENCLS Generators: {len(gencls_gen_nodes)}")
        print(f"  REGCA1 Generators: {len(regca1_gen_nodes)}")
        print(f"  GENROU Generators: {len(genrou_gen_nodes)}")
        print(f"  PLBVFU1 Generators: {len(plbvfu1_gen_nodes)}")
        print(f"  Loads: {len(load_nodes_list)}")
        total_gens = (
            len(slack_gen_nodes)
            + len(pv_gen_nodes)
            + len(gencls_gen_nodes)
            + len(regca1_gen_nodes)
            + len(genrou_gen_nodes)
            + len(plbvfu1_gen_nodes)
        )
        print(f"  Total Generators: {total_gens}")
        print(
            f"  Total Elements: {len(regular_buses) + total_gens + len(load_nodes_list)}"
        )
    
    return fig
