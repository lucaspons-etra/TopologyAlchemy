#!/usr/bin/env python3
"""
Simple network plotting script for ANDES power system cases.
This script provides easy-to-use functions to visualize power system networks.
"""

import andes
import matplotlib.pyplot as plt
import numpy as np

def simple_network_plot(case_file=None):
    """
    Create a simple network plot from an ANDES case file.
    
    Parameters:
    -----------
    case_file : str, optional
        Path to the ANDES case file. If None, uses the current working directory Kundur case.
    """
    
    # Load the system
    if case_file is None:
        case_file = "/home/flopez/projects/eter/powersystem_analysis/libs/andes/andes/cases/kundur/kundur_full.xlsx"
    
    print(f"Loading system from: {case_file}")
    ss = andes.load(case_file, setup=True)
    
    # Extract network information
    bus_data = []
    for i in range(len(ss.Bus.idx.v)):
        bus_data.append({
            'idx': ss.Bus.idx.v[i],
            'name': ss.Bus.name.v[i] if hasattr(ss.Bus.name, 'v') else f"Bus_{ss.Bus.idx.v[i]}",
            'voltage': ss.Bus.Vn.v[i],
            'x': ss.Bus.xcoord.v[i] if hasattr(ss.Bus, 'xcoord') else i,
            'y': ss.Bus.ycoord.v[i] if hasattr(ss.Bus, 'ycoord') else 0
        })
    
    line_data = []
    for i in range(len(ss.Line.idx.v)):
        line_data.append({
            'idx': ss.Line.idx.v[i],
            'bus1': ss.Line.bus1.v[i],
            'bus2': ss.Line.bus2.v[i],
            'name': ss.Line.name.v[i] if hasattr(ss.Line.name, 'v') else f"Line_{i}"
        })
    
    # Create the plot
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Create a mapping from bus idx to position in the list
    bus_idx_to_pos = {bus['idx']: i for i, bus in enumerate(bus_data)}
    
    # If all coordinates are zero, create a circular layout
    # if all(bus['x'] == 0 and bus['y'] == 0 for bus in bus_data):
    #     n_buses = len(bus_data)
    #     for i, bus in enumerate(bus_data):
    #         angle = 2 * np.pi * i / n_buses
    #         bus['x'] = np.cos(angle) * 5
    #         bus['y'] = np.sin(angle) * 5
    
    # Plot lines first (so they appear behind buses)
    for line in line_data:
        bus1_pos = bus_idx_to_pos.get(line['bus1'])
        bus2_pos = bus_idx_to_pos.get(line['bus2'])
        
        if bus1_pos is not None and bus2_pos is not None:
            x1, y1 = bus_data[bus1_pos]['x'], bus_data[bus1_pos]['y']
            x2, y2 = bus_data[bus2_pos]['x'], bus_data[bus2_pos]['y']
            
            ax.plot([x1, x2], [y1, y2], 'k-', linewidth=1.5, alpha=0.7)
    
    # Plot buses
    bus_colors = []
    for bus in bus_data:
        # Color by voltage level
        if bus['voltage'] > 200:
            bus_colors.append('red')  # High voltage
        elif bus['voltage'] > 50:
            bus_colors.append('orange')  # Medium voltage
        else:
            bus_colors.append('blue')  # Low voltage
    
    x_coords = [bus['x'] for bus in bus_data]
    y_coords = [bus['y'] for bus in bus_data]
    
    _ = ax.scatter(x_coords, y_coords, c=bus_colors, s=200, 
                        edgecolors='black', linewidth=2, alpha=0.8, zorder=3)
    
    # Add bus labels
    for bus in bus_data:
        ax.annotate(f"{bus['idx']}", (bus['x'], bus['y']), 
                   xytext=(0, 0), textcoords='offset points',
                   ha='center', va='center', fontweight='bold', fontsize=10)
    
    # Customize the plot
    ax.set_title(f"Power System Network\nBuses: {len(bus_data)}, Lines: {len(line_data)}", 
                fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.set_aspect('equal')
    
    # Create legend for voltage levels
    legend_elements = [
        plt.scatter([], [], c='red', s=100, label='High Voltage (>200 kV)'),
        plt.scatter([], [], c='orange', s=100, label='Medium Voltage (50-200 kV)'),
        plt.scatter([], [], c='blue', s=100, label='Low Voltage (<50 kV)')
    ]
    ax.legend(handles=legend_elements, loc='upper right')
    
    plt.tight_layout()
    return fig, ax, ss

def plot_with_generation_and_load(ss):
    """
    Plot the network showing generation and load information.
    """
    fig, ax = plt.subplots(figsize=(14, 10))
    
    # Get bus information
    bus_positions = {}
    n_buses = len(ss.Bus.idx.v)
    
    # Create circular layout if no coordinates
    for i in range(n_buses):
        bus_idx = ss.Bus.idx.v[i]
        if hasattr(ss.Bus, 'xcoord') and ss.Bus.xcoord.v[i] != 0:
            x, y = ss.Bus.xcoord.v[i], ss.Bus.ycoord.v[i]
        else:
            angle = 2 * np.pi * i / n_buses
            x, y = np.cos(angle) * 5, np.sin(angle) * 5
        bus_positions[bus_idx] = (x, y)
    
    # Plot lines
    for i in range(len(ss.Line.idx.v)):
        bus1 = ss.Line.bus1.v[i]
        bus2 = ss.Line.bus2.v[i]
        if bus1 in bus_positions and bus2 in bus_positions:
            x1, y1 = bus_positions[bus1]
            x2, y2 = bus_positions[bus2]
            ax.plot([x1, x2], [y1, y2], 'gray', linewidth=1, alpha=0.6)
    
    # Identify generator and load buses
    gen_buses = set()
    load_buses = set()
    
    # Check different types of generators
    if hasattr(ss, 'PV') and hasattr(ss.PV, 'bus'):
        gen_buses.update(ss.PV.bus.v)
    if hasattr(ss, 'Slack') and hasattr(ss.Slack, 'bus'):
        gen_buses.update(ss.Slack.bus.v)
    if hasattr(ss, 'SynGen') and hasattr(ss.SynGen, 'bus'):
        gen_buses.update(ss.SynGen.bus.v)
    
    # Check for loads
    if hasattr(ss, 'PQ') and hasattr(ss.PQ, 'bus'):
        load_buses.update(ss.PQ.bus.v)
    
    # Plot buses with different symbols
    for bus_idx, (x, y) in bus_positions.items():
        if bus_idx in gen_buses:
            ax.scatter(x, y, c='red', s=300, marker='^', label='Generator' if bus_idx == list(gen_buses)[0] else "", 
                      edgecolors='black', linewidth=2)
        elif bus_idx in load_buses:
            ax.scatter(x, y, c='blue', s=300, marker='v', label='Load' if bus_idx == list(load_buses)[0] else "",
                      edgecolors='black', linewidth=2)
        else:
            ax.scatter(x, y, c='lightgray', s=200, marker='o', label='Bus' if bus_idx == list(bus_positions.keys())[0] else "",
                      edgecolors='black', linewidth=2)
        
        # Add bus number
        ax.annotate(f"{bus_idx}", (x, y), xytext=(0, 0), textcoords='offset points',
                   ha='center', va='center', fontweight='bold', fontsize=8)
    
    ax.set_title("Power System Network - Generators and Loads", fontsize=14, fontweight='bold')
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.set_aspect('equal')
    plt.tight_layout()
    
    return fig, ax

def main():
    """Main function to demonstrate network plotting."""
    try:
        # Plot basic network
        print("Creating basic network plot...")
        fig1, ax1, ss = simple_network_plot()
        plt.savefig('simple_network_plot.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        # Plot with generation and load information
        print("Creating generation/load plot...")
        fig2, ax2 = plot_with_generation_and_load(ss)
        plt.savefig('network_gen_load_plot.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        print("Network plots created successfully!")
        print("Files saved: simple_network_plot.png, network_gen_load_plot.png")
        
        # Print system information
        print("\nSystem Information:")
        print(f"Number of buses: {len(ss.Bus.idx.v)}")
        print(f"Number of lines: {len(ss.Line.idx.v)}")
        print(f"Voltage levels: {sorted(set(ss.Bus.Vn.v))} kV")
        
    except Exception as e:
        print(f"Error: {e}")
        print("Make sure ANDES is installed and the case file path is correct.")

# if __name__ == "__main__":
#     main()
