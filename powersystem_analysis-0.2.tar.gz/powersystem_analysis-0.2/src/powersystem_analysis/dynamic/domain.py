from pathlib import Path
from typing import Literal


Model = Literal["REGCA1", "Line", "PV", "Toggle", "GENCLS", "Bus"]
Idx = int | str


MODEL_DEFAULTS = {
    "PV": {
        "u": 1.0,
        "Sn": 0.05,
        "Vn": 0.242,
        "p0": 0.05,
        "q0": 0.0,
        "pmax": 0.05,
        "pmin": 0.0,
        "qmax": 0.02,
        "qmin": -0.02,
        "v0": 1.0,
        "vmax": 1.05,
        "vmin": 0.95,
        "ra": 0.02,
        "xs": 0.05,
    },
    "GENCLS": {
        "u": 1.0,
        "coi": None,
        "coi2": None,
        "Sn": 0.05,
        "Vn": 0.242,
        "fn": 60.0,
        "D": 20.0,
        "M": 50.0,
        "ra": 0.02,
        "xl": 0.05,
        "xd1": 0.2,
        "kp": 0.0,
        "kw": 0.0,
        "S10": 0.01,
        "S12": 0.02,
        "gammap": 1.0,
        "gammaq": 1.0,
    },
    "REGCA1": {
        "Sn": 8,
        "Tg": 0.1,
        "Rrpwr": 10.0,
        "Brkpt": 0.8,
        "Zerox": 0.5,
        "Lvplsw": 1.0,
        "Lvpl1": 1.0,
        "Volim": 1.2,
        "Lvpnt1": 1.0,
        "Iolim": -0.2,
        "Lvpnt0": 0.4,
        "Tfltr": 0.1,
        "Khv": 0.5,
        "Iqrmax": 1.0,
        "Iqrmin": -1.0,
        "Accel": 0.0,
        "gammap": 1.0,
        "gammaq": 1.0,
    },
    "Line": {
        "u": 1.0,
        "Sn": 50.0,
        "fn": 60.0,
        "Vn1": 0.242,
        "Vn2": 0.242,
        "b1": 0.0,
        "g1": 0.0,
        "b2": 0.0,
        "g2": 0.0,
        "trans": 0.0,
        "tap": 1.0,
        "phi": 0.0,
        "owner": None,
        "xcoord": None,
        "ycoord": None,
        "r": 0.02,
        "x": 0.08,
        "b": 0.001,
    },
    "Toggle": {"u": 1.0, "t": 2.0},
    "Bus": {"Vn": 0.242, "area": 1, "zone": 1, "owner": 1},
}


class TDSComputationError(Exception):
    def __init__(self, exc: Exception):
        super().__init__(f"✗ TDS Failed during computation; {str(exc)}")



class PFlowUnestableError(Exception):
    def __init__(self):
        super().__init__("✗ TDS Failed: Andes Power Flow did not converge")



class DynamicModelNotSavedError(Exception):
    def __init__(self, model_key: int):
        super().__init__(f"Model with key {model_key} not present in File System")


class FileDoesNotExists(Exception):
    def __init__(self, file_path: Path):
        super().__init__(f"File does not exist: {file_path}")