import random
import geopandas as gpd
from shapely.geometry import LineString

from .domain import LineDefinitionError, PandaPowerElementCreationError


def compute_line_length(
    coordinates: list[tuple[float, float]],
    *,
    crs: str = "EPSG:4326",
    to_crs: str = "EPSG:3857",
) -> float:
    """
    Computes the length of a line defined by a list of 2D coordinates.

    Length computation using geopandas module. crs should be non-degree
    coordinates. By default google projection is used to transorme the
    input projection into it so more accuracy is achieved.

    Args:
        coordinates (list[tuple[float, float]]): A list of tuples
            representing the (x, y) coordinates of the line.
        crs (str, optional): The coordinate reference system the
            coordinates are. Defaults to 'EPSG:3857'.
        to_crs (str, optional): The coordinate reference system to use.
            Defaults to 'EPSG:3857'.

    Returns:
        float: The length of the line in the crs units.
    """
    line = gpd.GeoSeries(data=[LineString(coordinates)], crs=crs)  # type: ignore
    line = line.to_crs(to_crs)

    return line.iloc[0].length  # type: ignore


def is_number(t: type) -> bool:
    return t in [int, float]


def get_line_length(line: dict, **kwargs) -> float:
    # 1.0 no converge impedancia cercana a 0.0
    # 10.0 sí converge
    # 100.0 sí converge
    # 1000.0 sí converge
    # 10000.0 sí converge
    # 100000.0 no converge -- converge escalando cargas a menos del 1%... que no tengo claro a qué se refiere
    default = random.random() * 1_000
    line_length = line.get("length", default)

    # This is because data import error in mongo, but happens so
    # we must manage it.
    if not is_number(type(line_length)):
        return default  # raise LineDefinitionLengthStringError()

    # This is almost only for debugging purposes
    if is_number(type(line_length)) and line_length <= 0.0:
        geometry = line.get("geometry", {})
        coordinates = geometry.get("coordinates", None)
        if coordinates is None:
            if kwargs.get("allowed_no_geometry_data"):
                coordinates = [(0.0, 0.0), (1.0, 1.0)]
            else:
                raise LineDefinitionError()
        line_length = compute_line_length(coordinates)

    return line_length


def interpolate_transformers_parameters(
    trafos_to_interpolate: list[dict], trafo_id: str, trafo_power: float
) -> tuple[float, float]:
    # s = trafo.get("sn_mva", trafo["sn_hv_mva"])
    ts: list[dict] = sorted(
        trafos_to_interpolate,
        key=lambda x: x["sn_mva"],
        reverse=True,
    )
    first_smaller = next((d for d in ts if d["sn_mva"] < trafo_power), None)
    ts = ts[::-1]
    last_bigger = next((d for d in ts if d["sn_mva"] > trafo_power), None)

    def linear_interpolate(x, x0, x1, y0, y1):
        """Interpolate y at x given two points (x0, y0) and (x1, y1)."""
        if x1 == x0:
            return (y0 + y1) / 2

        return y0 + (y1 - y0) * (x - x0) / (x1 - x0)

    if first_smaller is None and last_bigger is not None:
        return last_bigger["vk_percent"], last_bigger["vkr_percent"]
    elif first_smaller is not None and last_bigger is None:
        return first_smaller["vk_percent"], first_smaller["vkr_percent"]
    elif first_smaller is None or last_bigger is None:
        # trafo_id = trafo.get("_id", "unknown")
        raise PandaPowerElementCreationError(
            "trafo",
            f"Transformer {trafo_id} has no set up the sn_mva value which is mandatory.",
        )

    x0 = first_smaller["sn_mva"]
    x1 = last_bigger["sn_mva"]

    vkr_percent = linear_interpolate(
        trafo_power, x0, x1, first_smaller["vkr_percent"], last_bigger["vkr_percent"]
    )
    vk_percent = linear_interpolate(
        trafo_power, x0, x1, first_smaller["vk_percent"], last_bigger["vk_percent"]
    )

    return vk_percent, vkr_percent


def compute_capacitance(voltage_kv: float, line_type: None | str = None) -> float:
    """
    Processes per-km impedance and assigns default capacitance for pandapower lines.
    Line capacitance (line-to-earth) in nano Farad per km.

    Values asked to chatgpt-5.

    Args:
        r_ohm_per_km (float): Resistance per km (Ohm/km)
        x_ohm_per_km (float): Reactance per km (Ohm/km)
        voltage_kv (float): Nominal voltage of the line (kV)
        line_type (str): Either 'overhead' or 'cable'

    Returns:
        c_nf_per_km
    """
    if line_type is None or line_type == "cable":
        if voltage_kv >= 100:
            return 250
        elif voltage_kv >= 20:
            return 100
        else:
            return 50
    elif line_type == "overhead":
        if voltage_kv >= 100:
            return 10
        elif voltage_kv >= 20:
            return 8
        else:
            return 5
    else:
        return 0
