import os
from collections import namedtuple
from dataclasses import dataclass, asdict
from typing import Literal, Optional, Union
import numpy as np

N1Type = Literal["line", "transformer"]
conversion_factor = {"W": 1_000_000, "KW": 1_000, "MW": 1}
Bus = namedtuple("Bus", ["pp_id", "mongo_data"])

defaults = {
    "ext_grid": {"vm_gpu": 1.02},
    "bus": {},
    "line": {"type": "NA2XS2Y 1x120 RM/25 6/10 kV", "length": 10.0},
}


class MongoClientUnitializedError(Exception):
    def __init__(self):
        super().__init__("MongoClient is not initialized.")


class MongoClientCloseError(Exception):
    def __init__(self):
        super().__init__("MongoClient is managed from the outside, can be closed here.")


class NATSClientUnitializedError(Exception):
    def __init__(self):
        super().__init__("NATSClient is not initialized.")


class NATSClientClosedError(Exception):
    def __init__(self):
        super().__init__("NATSClient is already closed.")


class NATSClientNotConnectedError(Exception):
    def __init__(self):
        super().__init__("NATSClient is already closed.")


class NATSUnsusbsribedError(Exception):
    def __init__(self):
        super().__init__("You are not subscriped to any topic.")


class NATSAlreadySusbsribedError(Exception):
    def __init__(self, topic):
        super().__init__(f"You're alredy subscribed to topic {topic}.")


class PandaPowerWrongMongoFilterError(Exception):
    def __init__(self):
        super().__init__(
            "Invalid bus filtering data. You must look for either system/network for system or only network for subsystems."
        )


class PandaPowerWrongTopologyError(Exception):
    def __init__(self, error_msg: str):
        super().__init__(
            f"Wrong topology tried to load into PandaPower. Error: {error_msg}"
        )


class PandaPowerElementCreationError(Exception):
    def __init__(self, element_type: str, reason: str = ""):
        suffix = f" Reason: {reason}" if reason else ""
        super().__init__(f"Error creating {element_type} element.{suffix}")


class LineDefinitionError(Exception):
    def __init__(self):
        super().__init__(
            "Either length of geometry.coordinates must be defined to compute line losses."
        )


class LineDefinitionLengthStringError(Exception):
    def __init__(self):
        super().__init__("Length is defined as string, must be float.")


class EnvVarNotSetError(Exception):
    def __init__(self, env_var: str) -> None:
        super().__init__(f"Environment variable {env_var} is not set.")


class MeasurementError(Exception):
    def __init__(self):
        super().__init__(
            "Measurement error. If `bus`, side must be None, or not None otherwise."
        )


class ConvergenceError(Exception):
    def __init__(self, diagnosis: dict):
        self.message = diagnosis
        super().__init__(diagnosis)


class PandaPowerNoMeasurementRegisteredError(Exception):
    def __init__(self):
        super().__init__("No measurement registered so estimation cannot be computed.")


def get_env_var(key: str, *, default: Optional[str] = None) -> str:
    if key in os.environ and len(os.environ[key]) > 0:
        return os.environ[key]
    else:
        if default is not None:
            return default

        raise EnvVarNotSetError(key)


def get_opt_env_var(key: str) -> Optional[str]:
    return os.environ.get(key)


@dataclass
class NATSConfig:
    host: str
    port: int
    group: Optional[str]
    user: Optional[str]
    password: Optional[str]
    timeout: Optional[int]

    @property
    def url(self):
        if self.user is None or self.password is None:
            return f"nats://{self.host}:{self.port}"

        return f"nats://{self.user}:{self.password}@{self.host}:{self.port}"


@dataclass
class MongoConfig:
    host: str
    port: int
    user: str
    password: str
    auth_mechanism: str
    auth_source: Optional[str] = "admin"
    connection_timeout: Optional[int] = 10000
    server_selection_timeout: Optional[int] = 5000

    @property
    def url(self):
        return (
            f"mongodb://{self.user}:{self.password}@{self.host}:{self.port}"
            f"/?authSource={self.auth_source}&authMechanism={self.auth_mechanism}"
            f"&connectTimeoutMS={self.connection_timeout}&serverSelectionTimeoutMS={self.server_selection_timeout}"
        )


@dataclass
class AppConfig:
    nats_config: NATSConfig
    mongo_config: MongoConfig

    @classmethod
    def load_from_env(cls):
        return cls(
            nats_config=NATSConfig(
                host=get_env_var("NATS_HOST"),
                port=int(get_env_var("NATS_PORT")),
                group=get_opt_env_var("NATS_GROUP"),
                user=get_opt_env_var("NATS_USER"),
                password=get_opt_env_var("NATS_PASSWORD"),
                # TODO: Extract to function, with python3.12 generics
                # would be nicer.
                timeout=(
                    int(get_env_var("NATS_REQUEST_TIMEOUT"))
                    if "NATS_REQUEST_TIMEOUT" in os.environ
                    else None
                ),
            ),
            mongo_config=MongoConfig(
                host=get_env_var("MONGO_HOST"),
                port=int(get_env_var("MONGO_PORT")),
                user=get_env_var("MONGO_USER"),
                password=get_env_var("MONGO_PASSWORD"),
                auth_mechanism=get_env_var("MONGO_AUTH_MECHANISM"),
                auth_source=get_env_var("MONGO_AUTH_SOURCE", default="admin"),
                connection_timeout=get_env_var(
                    "MONGO_CONNECTION_TIMEOUT", default=10000
                ),
                server_selection_timeout=get_env_var(
                    "MONGO_SERVER_SELECTION_TIMEOUT", default=5000
                ),
            ),
        )


@dataclass
class Measurement:
    meas_type: Literal["v", "p", "q", "i", "va", "ia", "l"]
    element_type: Literal["bus", "line", "trafo", "trafo3w"]
    value: float
    std_dev: float
    element: np.int64
    side: Optional[Union[int, str]] = None

    @classmethod
    def from_data(
        cls,
        meas_type: Literal["v", "p", "q", "i", "va", "ia", "l"],
        element_type: Literal["bus", "line", "trafo", "trafo3w"],
        value: float,
        std_dev: float,
        element: np.int64,
        side: Optional[Union[str, int]] = None,
    ) -> "Measurement":
        if side is None and element_type != "bus":
            raise MeasurementError()

        return cls(
            meas_type=meas_type,
            element_type=element_type,
            value=value,
            std_dev=std_dev,
            element=element,
            side=side,
        )

    def to_dict(self):
        return asdict(self)
