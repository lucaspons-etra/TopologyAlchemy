"""TODO: We should continue working on making this class
more dependent on PowerNetwork and leave here almost only
anything related with MongoDB."""

import time
from typing import Callable, Dict, Literal, Optional
import requests

from pymongo import AsyncMongoClient

from .domain import (
    MongoClientCloseError,
    MongoConfig,
    PandaPowerElementCreationError,
    PandaPowerWrongMongoFilterError,
    PandaPowerWrongTopologyError,
    conversion_factor,
)
from .helpers import get_line_length, compute_capacitance
from .mongo_pipelines import buses_upl_aggregation
from .power_network import N1Type, PowerNetwork
import io

def log_time(step, start):
    end = time.perf_counter()
    print(f"[create_network] {step} took {end-start:.3f} seconds")


class EterPowerNetwork:

   
    """
    Power network model wrapper to be created from mongo database

    Hardly accopled to Mongo schema that creates Topology Alchemy."""

    def __init__(
        self,
        db="citric",
        *,
        mongo_config: None | MongoConfig = None,
        mongo_client: None | AsyncMongoClient = None,
        mongo_uri: None | str = None,
        citric_uri: None | str = None,
        citric_user_id: None | str = None,
        citric_auth_token: None | str = None,
        **kwargs,
    ):
        assert (
            mongo_client is not None
            or mongo_config is not None
            or mongo_uri is not None
            or citric_uri is not None
        ), "Either mongo_client or mongo_config or mongo_uri or citric_uri must be provided."
        self.power_network = PowerNetwork(**kwargs)
        self.citric_base_url = None
        self.citric_user_id = citric_user_id
        self.citric_auth_token = citric_auth_token
        if citric_uri is not None:
            self.citric_base_url = citric_uri.rstrip("/")
            self.db = None
        else:
            print("DEPRECATION WARNING: The Mongodb data repository for the topology will be deprecated in future releases.")
        
        if mongo_client is not None:
            self.__mongo_client = mongo_client
            self.__external_mongo_client = True
            self.db = self.__mongo_client[db]
        elif mongo_config is not None:
            self.__mongo_client = AsyncMongoClient(mongo_config.url)
            self.__external_mongo_client = False
            self.db = self.__mongo_client[db]
        elif mongo_uri is not None:
            self.__mongo_client = AsyncMongoClient(mongo_uri)
            self.__external_mongo_client = False
            self.db = self.__mongo_client[db]
        else:  # citric_uri is not None
            self.__mongo_client = None
            self.__external_mongo_client = False
            self.db = None

        

    @property
    def pp_net(self):
        return self.power_network.net

    @property
    def bus_names(self) -> list[str]:
        return self.power_network.bus_names

    def clear(self):
        """
        Clears the network creating a new underlying pandapower net
        """
        self.__net = pp.create_empty_network()
        
    async def create_network(
        self,
        *,
        bus_query: Dict,
        loads_data: Optional[Dict[str, Dict]] = None,
        usage_point_data: Optional[Dict[str, Dict]] = None,
        generators_data: Optional[Dict[str, Dict]] = None,
        power_unit: Literal["W", "KW", "MW"] = "W",
        **kwargs,
    ):
        """
        Powerpanda network creation using Mongo data.

        It performs all steps to create a pandapower network. Single
        command to run the whole process. Clears the network before
        to avoid duplication.

        Arguments:
            bus_query (dict): Mongo query to filter buses
            loads_data (dict): Dictionary with loads data, keys are load_id
            usage_point_data (dict): Dictionary with usage points data, keys are usage_point_id
            generators_data (dict): Dictionary with generators data, keys are generators_id
            power_unit (str): Power unit measures for loads_data use, W, KW or MW
            kwargs (dict): Additional arguments, usually for debug
        """
        lines_std_type: Optional[str] = kwargs.get("line_std_type")
        self.clear()

        if "system" in bus_query and "network" in bus_query:
            network_value = bus_query["network"]
            mongo_query = {
                "$or": [
                    {
                        "system": bus_query["system"],
                        "network": bus_query["network"],
                    },
                    {"_id": network_value},
                ]
            }
        elif "network" in bus_query:
            network_value = bus_query["network"]
            mongo_query = {"$or": [{"network": network_value}, {"_id": network_value}]}
        else:
            raise PandaPowerWrongMongoFilterError()

        try:
            await self.load_buses(query=mongo_query, power_unit=power_unit)
            await self.load_loads(loads_data if loads_data else {}, power_unit)
            await self.load_usage_points(
                usage_point_data if usage_point_data else {},
                power_unit,
            )
            await self.load_generators(
                generators_data if generators_data else {},
                power_unit,
            )
            await self.load_lines(power_unit, lines_std_type, **kwargs)
            await self.load_switches()
            await self.load_trafos(power_unit)
            await self.load_trafos3w(power_unit)
            await self.load_dangling_lines(query=mongo_query)
        except Exception as e:
            raise PandaPowerWrongTopologyError(str(e))

    async def load_buses(self, query: dict, power_unit: Literal["W", "KW", "MW"]):
        factor = conversion_factor[power_unit]

        buses_cursor = self.db["eter_buses"].find(query)
        buses_list = [
            {**bus, "vn_kv": bus["nominalVoltage"] / factor, "name": bus["_id"]}
            async for bus in buses_cursor
        ]
        self.power_network.load_buses(buses_list)

    async def load_loads(
        self, loads_data: dict[str, dict], power_unit: Literal["W", "KW", "MW"]
    ):
        def map_fn(load: dict) -> dict:
            try:
                factor = conversion_factor[power_unit]
                load_data = loads_data.get(load["_id"], {"p": 0.0, "q": 0.0})

                return {
                    **load,
                    "name": load["_id"],
                    "p_mw": load_data["p"] / factor,
                    "q_mvar": load_data["q"] / factor,
                    "bus_name": load["bus"],
                }
            except KeyError as e:
                raise PandaPowerElementCreationError("LOAD") from e

        loads = await self._get_element_connected_to_bus("eter_loads", map_fn)
        self.power_network.load_loads(loads)

    async def load_generators(
        self, generators_data: dict[str, dict], power_unit: Literal["W", "KW", "MW"]
    ):
        def map_fn(gen: dict) -> dict:
            factor = conversion_factor[power_unit]
            gen_data = generators_data.get(gen["_id"], {"p": 0.0, "q": 0.0})

            return {
                **gen,
                "name": gen["_id"],
                "p_mw": gen_data["p"] / factor,
                "q_mvar": gen_data.get("q", 0.0) / factor,  # PV does not need it
                "bus_name": gen["bus"],
                "vm_pu": gen.get("voltageSetpoint", 1.0),
                "controllable": bool(gen.get("controllable", True)),
                "pv": gen.get("pv", False),
            }

        gens = await self._get_element_connected_to_bus("eter_generators", map_fn)

        pq_gens = filter(lambda g: not g["pv"], gens)
        self.power_network.load_static_gens(list(pq_gens))

        pv_gens = filter(lambda g: g["pv"], gens)
        self.power_network.load_gens(list(pv_gens))

    async def load_dangling_lines(self, query: dict):
        def map_fn(ext_grid: dict) -> dict:
            return {
                **ext_grid,
                "name": ext_grid["_id"],
                "bus_name": ext_grid["bus"],
                "controllable": bool(ext_grid.get("controllable", True)),
            }

        ext_grids = await self._get_element_connected_to_bus(
            "eter_danglingLines", map_fn, query=query
        )
        self.power_network.load_ext_grid(ext_grids)

    async def load_usage_points(
        self, usage_points_data: Dict[str, Dict], power_unit: Literal["W", "KW", "MW"]
    ):
        factor = conversion_factor[power_unit]

        async def get_usage_points(ids: list[str]):
            return [
                {"bus": doc["_id"], **up["meter"], "_id": up["_id"]}
                async for doc in await self.db["eter_usagePointLocations"].aggregate(
                    buses_upl_aggregation(ids)
                )
                for up in doc["usagePoints"]
            ]

        def map_fn(up: dict) -> dict:
            up_data = usage_points_data.get(up["_id"], {"p": 0.0, "q": 0.0})
            return {
                **up,
                "name": up["_id"],
                "bus_name": up["bus"],
                "p_mw": up_data["p"] / factor,
                "q_mvar": up_data["q"] / factor,
            }

        ups = [map_fn(up) for up in await get_usage_points(self.bus_names)]
        self.power_network.load_loads(ups, field="usage_points")

    async def _get_element_connected_to_bus(
        self, collection: str, fn: Callable, *, query: Optional[dict] = None
    ) -> list[dict]:
        query = query if query is not None else {"bus": {"$in": self.bus_names}}

        return [fn(element) async for element in self.db[collection].find(query)]

    async def load_lines(self, power_unit, lines_std_type: None | str = None, **kwargs):
        factor = conversion_factor[power_unit]

        def map_fn(line: dict) -> dict:
            line_length = get_line_length(line, **kwargs) / 1_000
            r, x = float(line["r"]), float(line["x"])
            # c_nf_per_km = (
            #     1 / (2 * 3.14159265359 * self.power_network.frequency * x) / factor
            # )
            bus1 = self.power_network.buses[line["bus1"]]

            c_nf_per_km = compute_capacitance(
                bus1.mongo_data["nominalVoltage"] / factor, line.get("lineType", None)
            )

            return {
                **line,
                "name": line["_id"],
                "bus1_name": line["bus1"],
                "bus2_name": line["bus2"],
                "r_ohm_per_km": r,
                "x_ohm_per_km": x,
                "c_nf_per_km": c_nf_per_km,
                "length_km": line_length,
                "max_i_ka": line["currentLimit"] / factor,
            }

        lines = await self._get_elements_between_buses("eter_lines", map_fn)
        self.power_network.load_lines(lines, lines_std_type=lines_std_type)

    async def load_switches(self):
        def map_fn(switch: dict) -> dict:
            return {
                **switch,
                "name": switch["_id"],
                "bus1_name": switch["bus1"],
                "bus2_name": switch["bus2"],
                "closed": True,  # default state?
            }

        switches = await self._get_elements_between_buses("eter_switches", map_fn)
        self.power_network.load_switches(switches)

    async def load_trafos(self, power_unit: Literal["W", "KW", "MW"]):
        factor = conversion_factor[power_unit]

        def map_fn(trafo: dict) -> dict:
            return {
                **trafo,
                "name": trafo["substation"] + "/" + trafo["_id"],
                "bus1_name": trafo["bus1"],
                "bus2_name": trafo["bus2"],
                "sn_mva": trafo["ratedApparentPower"] / factor,
                "vn_hv_kv": trafo["ratedVoltage1"] / factor,
                "vn_lv_kv": trafo["ratedVoltage2"] / factor,
                "pfe_kw": 0.0,
                "i0_percent": 0.0,
                "shift_degree": 0,
            }

        trafos = await self._get_elements_between_buses("eter_transformers", map_fn)
        self.power_network.load_trafos(trafos)

    async def load_trafos3w(self, power_unit: Literal["W", "KW", "MW"]):
        factor = conversion_factor[power_unit]

        def map_fn(trafo: dict) -> dict:
            return {
                **trafo,
                "name": trafo["substation"] + "/" + trafo["_id"],
                "vn_hv_kv": trafo["ratedVoltage1"] / factor,
                "vn_mv_kv": trafo["ratedVoltage2"] / factor,
                "vn_lv_kv": trafo["ratedVoltage3"] / factor,
                "sn_hv_mva": trafo["ratedApparentPower1"] / factor,
                "sn_mv_mva": trafo["ratedApparentPower2"] / factor,
                "sn_lv_mva": trafo["ratedApparentPower3"] / factor,
                "pfe_kw": 0.0,
                "i0_percent": 0.0,
                "shift_degree": 0,
            }

        query = {
            "$and": [
                {"bus1": {"$in": self.bus_names}},
                {"bus2": {"$in": self.bus_names}},
                {"bus3": {"$in": self.bus_names}},
            ]
        }

        transformers_cursor = self.db["eter_transformers"].find(query)
        transformers = [map_fn(trafo) async for trafo in transformers_cursor]

        self.power_network.load_trafos3w(transformers)

    async def _get_elements_between_buses(
        self, collection: str, map_fn: Callable
    ) -> list[dict]:
        result = []
        async for element in self.db[collection].find(
            {
                "$and": [
                    {"bus1": {"$in": self.bus_names}},
                    {"bus2": {"$in": self.bus_names}},
                    {"bus3": {"$eq": None}},
                ]
            }
        ):
            mapped_element = map_fn(element)
            result.append(mapped_element)

        return result

    async def close(self):
        if self.__external_mongo_client:
            raise MongoClientCloseError()
        await self.__mongo_client.close()

    # ==========================================================
    # Methods delegated to internal PowerNetwork instance
    # ==========================================================
    def run(self):
        return self.power_network.run()

    def results_all(self, **kwargs):
        return self.power_network.results_all(**kwargs)

    def plot(self, *, plot_type="matplotlib", **kwargs):
        return self.power_network.plot(plot_type=plot_type, **kwargs)

    def n_minus_1_analysis(self, *, type: N1Type, maxs: dict, names: list[str]):
        return self.power_network.n_minus_1_analysis(
            elements=[(type, names)], maxs=maxs
        )

    def export(self, filename: str):
        self.power_network.export(filename)

    def export_to_json(self) -> dict:
        return self.power_network.export_to_json()

    def export_to_json_string(self, *, compact=True) -> str:
        return self.power_network.export_to_json_string(compact=compact)
