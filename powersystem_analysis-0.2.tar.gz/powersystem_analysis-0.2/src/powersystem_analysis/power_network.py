from pathlib import Path
from typing import Literal, final

import networkx as nx
import numpy as np
import pandapower as pp
import pandapower.plotting as plot
import pandapower.topology as top
import pandas as pd
from pandapower import toolbox
from pandapower.estimation import estimate
from pandapower.plotting.plotly import pf_res_plotly, simple_plotly, vlevel_plotly


from .domain import (
    Bus,
    ConvergenceError,
    Measurement,
    N1Type,
    PandaPowerElementCreationError,
    PandaPowerNoMeasurementRegisteredError,
)
from .helpers import interpolate_transformers_parameters
from .pp_elements import mappers


AllowedElements = Literal[
    "bus", "line", "ext_grid", "load", "sgen", "gen", "switch", "trafo", "dangling_line"
]


@final
class PowerNetwork:
    """
    PP network model wrapper. Created from dict elements representation
    from pandapower dataframes exported as dict:

    `net.bus.to_dict(orient="records")`

    All the load methods expect elements to have the same format, so the
    attributes names must match those used in pandapower. So is the class
    of function client the one that must ensure that the elements have
    the correct format, and serve as adapter between different data sources.
    """

    def __init__(self, **kwargs):
        self.init()
        self.frequency = 50

        for key, value in kwargs.items():
            match key:
                case "frequency":
                    self.frequency = value
                case "measurements":
                    self.__measurements = value
                case _:
                    if key not in self.__dict__.keys():
                        continue
                    setattr(self, key, value)

    def init(self):
        """
        Initialize the network creating a new underlying pandapower net.
        """
        self.net = pp.create_empty_network()
        self.buses = {}
        self.lines = {}
        self.switches = {}
        self.generators = {}
        self.trafos = {}
        self.trafos3w = {}
        self.ext_grids = {}
        self.loads = {}
        self.usage_points = {}
        self.__measurements = []
        self.__bus_names = None

    def clear(self):
        self.init()

    @property
    def pp_net(self):
        "To make compatible with current eter pp api."
        return self.net

    @property
    def n_measurements(self) -> int:
        return len(self.__measurements)

    @property
    def is_empty(self) -> bool:
        return (
            len(self.buses) == 0
            and len(self.lines) == 0
            and len(self.loads) == 0
            and len(self.generators) == 0
            and len(self.trafos) == 0
            and len(self.trafos3w) == 0
            and len(self.switches) == 0
            and len(self.ext_grids) == 0
            and self.n_measurements == 0
        ) and (
            self.net.bus.empty
            and self.net.line.empty
            and self.net.load.empty
            and self.net.gen.empty
            and self.net.trafo.empty
            and self.net.trafo3w.empty
            and self.net.switch.empty
            and self.net.ext_grid.empty
        )

    @property
    def bus_names(self) -> list[str]:
        if self.__bus_names is None:
            self.__bus_names = list(self.buses.keys())

        return self.__bus_names

    def load_buses(self, buses: list[dict]):
        def create_bus(net, bus: dict) -> Bus:
            max_vm_pu = bus.get("max_vm_pu", None)
            min_vm_pu = bus.get("min_vm_pu", None)
            extras = {}
            if max_vm_pu is not None and min_vm_pu is not None:
                extras = {
                    "max_vm_pu": max_vm_pu,
                    "min_vm_pu": min_vm_pu,
                }
            return Bus(
                pp.create_bus(
                    net,
                    vn_kv=bus["vn_kv"],
                    name=bus["name"],
                    type=bus.get("type", "b"),
                    zone=bus.get("zone", None),
                    # Those two params are needed for OPF, so maybe not present.
                    **extras,
                ),
                bus,
            )

        self.buses = {bus["name"]: create_bus(self.pp_net, bus) for bus in buses}

    def load_loads(self, loads: list[dict], *, field="loads"):
        def create_load(net: pp.pandapowerNet, load: dict):
            bus_name = load["bus_name"]
            bus_id = self.buses[bus_name].pp_id

            load_pp_id = pp.create_load(
                net,
                bus_id,
                bus_name=bus_name,
                name=load["name"],
                p_mw=load["p_mw"],
                q_mvar=load["q_mvar"],
            )

            if type(load_pp_id) is not np.int64:
                raise PandaPowerElementCreationError("LOAD")

            return int(load_pp_id), load

        setattr(
            self,
            field,
            {load["name"]: create_load(self.pp_net, load) for load in loads},
        )

    def change_loads(self, loads: list[dict], *, field="loads"):
        """
        Updates the load values in the network.

        This method modifies the active (p_mw) and reactive
        (q_mvar) power values of loads in both the internal network
        representation (`self.net.load`) and the object's load
        dictionary.

        It should not be exposed to EterPowerNetwork because it
        modifies loads like pandapower elements are defined.

        Args:
            loads (list[dict]): A list of dictionaries, each
                representing a load with keys "name", "p_mw",
                and "q_mvar".
            field (str, optional): The attribute name of the load
                dictionary in the object. Defaults to "loads".
        Notes:
            - The method matches loads by their "name" key.
            - Both the Pandas DataFrame (`self.net.load`) and the
                object's load dictionary are updated.
        """

        for load in loads:
            self.net.load.loc[
                load["name"] == self.net.load["name"], ["p_mw", "q_mvar"]
            ] = (load["p_mw"], load["q_mvar"])

        new_names: set[str] = {load["name"] for load in loads}
        network_loads = getattr(self, field)
        for key in network_loads:
            _, load = network_loads[key]
            if load["name"] in new_names:
                new_load = [lo for lo in loads if lo["name"] == load["name"]][0]
                load["p_mw"] = new_load["p_mw"]
                load["q_mvar"] = new_load["q_mvar"]

    def load_gens(self, gens: list[dict]):
        """PV generators"""

        def create_gen(net: pp.pandapowerNet, gen: dict):
            bus_name = gen["bus_name"]
            bus_id = self.buses[bus_name].pp_id

            in_service = gen["p_mw"] != 0.0
            gen_pp_id = pp.create_gen(
                net,
                bus_id,
                name=gen["name"],
                bus_name=bus_name,
                p_mw=gen["p_mw"],
                controllable=gen["controllable"],
                vm_pu=gen["vm_pu"],
                in_service=in_service,
            )

            if type(gen_pp_id) is not np.int64:
                raise PandaPowerElementCreationError("GENERATOR")

            return int(gen_pp_id), gen

        self.generators.update(
            {gen["name"]: create_gen(self.pp_net, gen) for gen in gens}
        )

    def load_static_gens(self, gens: list[dict]):
        """PQ generators"""

        def create_gen(net: pp.pandapowerNet, gen: dict):
            bus_name = gen["bus_name"]
            bus_id = self.buses[bus_name].pp_id

            gen_pp_id = pp.create_sgen(
                net,
                bus_id,
                name=gen["name"],
                bus_name=bus_name,
                p_mw=gen["p_mw"],
                q_mvar=gen["q_mvar"],
                controllable=gen["controllable"],
            )

            if type(gen_pp_id) is not np.int64:
                raise PandaPowerElementCreationError("GENERATOR")

            return int(gen_pp_id), gen

        self.generators.update(
            {gen["name"]: create_gen(self.pp_net, gen) for gen in gens}
        )

    def load_ext_grid(self, ext_grids: list[dict]):
        def create_ext_grid(net: pp.pandapowerNet, ext_grid: dict) -> tuple[int, dict]:
            bus = ext_grid["bus_name"]
            bus_id = self.buses[bus].pp_id
            dline_id = pp.create_ext_grid(
                net,
                bus=bus_id,
                **{k: v for k, v in ext_grid.items() if k != "bus"},
                # name=ext_grid["name"],
                # bus_name=ext_grid["bus_name"],
                # controllable=ext_grid.get("controllable", False),
            )

            # if type(dline_id) is not np.int64:
            #     raise PandaPowerElementCreationError("EXTERNAL GRID")

            return int(dline_id), ext_grid

        self.ext_grids = {
            eg["bus_name"]: create_ext_grid(self.pp_net, eg) for eg in ext_grids
        }

    def load_lines(self, lines: list[dict], **kwargs):
        time_counter = 0
        lines_std_type = kwargs.get("lines_std_type", None)

        def create_line_from_std_type(net, line: dict) -> tuple[int, dict]:
            assert lines_std_type is not None  # for mypy

            bus1, bus2 = line["bus1_name"], line["bus2_name"]
            from_bus_id = self.buses[bus1].pp_id
            to_bus_id = self.buses[bus2].pp_id
            line_net_id = pp.create_line(
                net,
                name=line["name"],
                bus1_name=line["bus1_name"],
                bus2_name=line["bus2_name"],
                from_bus=from_bus_id,
                to_bus=to_bus_id,
                length_km=line["length_km"],
                std_type=lines_std_type,
            )

            if type(line_net_id) is not np.int64:
                raise PandaPowerElementCreationError("LINE")

            return int(line_net_id), line

        def create_line_from_params(net, line: dict) -> tuple[int, dict]:
            nonlocal time_counter
            bus1, bus2 = line["bus1_name"], line["bus2_name"]
            from_bus_id = self.buses[bus1].pp_id
            to_bus_id = self.buses[bus2].pp_id
            max_loading_percent = line.get("max_loading_percent", None)

            extras = {}
            if max_loading_percent is not None:
                extras = {"max_loading_percent": max_loading_percent}
            line_net_id = pp.create_line_from_parameters(
                net,
                from_bus=from_bus_id,
                to_bus=to_bus_id,
                name=line["name"],
                bus1_name=line["bus1_name"],
                bus2_name=line["bus2_name"],
                length_km=line["length_km"],
                r_ohm_per_km=line["r_ohm_per_km"],
                x_ohm_per_km=line["x_ohm_per_km"],
                c_nf_per_km=line["c_nf_per_km"],
                max_i_ka=line["max_i_ka"],
                type=line["type"],
                **extras,
            )

            if type(line_net_id) is not np.int64:
                raise PandaPowerElementCreationError("LINE")

            return int(line_net_id), line

        fn = (
            create_line_from_params
            if lines_std_type is None
            else create_line_from_std_type
        )
        self.lines = {line["name"]: fn(self.pp_net, line) for line in lines}

    def load_switches(self, switches: list[dict]):
        def create_switch(net: pp.pandapowerNet, switch: dict) -> tuple[int, dict]:
            bus1 = switch["bus1_name"]
            bus2 = switch["bus2_name"]
            bus1_id = self.buses[bus1].pp_id
            bus2_id = self.buses[bus2].pp_id
            switch_id = pp.create_switch(  # type: ignore  # pandapower bug
                net,
                bus1_id,
                bus2_id,
                et="b",  # by default we model using always two buses
                type="CB",
                name=switch["name"],
                closed=switch["closed"],
                bus1_name=switch["bus1_name"],
                bus2_name=switch["bus2_name"],
            )

            if type(switch_id) is not np.int64:
                raise PandaPowerElementCreationError("SWITCH")

            return int(switch_id), switch

        self.switches = {
            switch["name"]: create_switch(self.pp_net, switch) for switch in switches
        }

    def load_trafos(self, trafos: list[dict]):
        def create_trafo(net: pp.pandapowerNet, trafo: dict) -> tuple[int, dict]:
            vk_percent, vkr_percent = interpolate_transformers_parameters(
                list(net.std_types["trafo"].values()),
                trafo["name"],
                trafo["sn_mva"],
            )
            bus1 = trafo["bus1_name"]
            bus2 = trafo["bus2_name"]
            hv_bus = self.buses[bus1].pp_id
            lv_bus = self.buses[bus2].pp_id
            trafo_id = pp.create_transformer_from_parameters(
                net,
                name=trafo["name"],
                hv_bus=hv_bus,
                lv_bus=lv_bus,
                bus1_name=bus1,
                bus2_name=bus2,
                sn_mva=trafo["sn_mva"],
                vn_hv_kv=trafo["vn_hv_kv"],
                vn_lv_kv=trafo["vn_lv_kv"],
                vk_percent=vk_percent,
                vkr_percent=vkr_percent,
                pfe_kw=trafo["pfe_kw"],
                i0_percent=trafo["i0_percent"],
                shift_degree=trafo["shift_degree"],
            )

            if type(trafo_id) is not np.int64:
                raise PandaPowerElementCreationError("TRANSFORMER")

            return int(trafo_id), trafo

        self.trafos = {
            trafo["name"]: create_trafo(self.pp_net, trafo) for trafo in trafos
        }

    def load_trafos3w(self, trafos: list[dict]):
        def create_trafo(net: pp.pandapowerNet, trafo: dict) -> tuple[int, dict]:
            trafos = list(net.std_types["trafo"].values())

            vk_hv_percent, vkr_hv_percent = interpolate_transformers_parameters(
                trafos,
                trafo["name"],
                trafo["sn_hv_mva"],
            )
            vk_mv_percent, vkr_mv_percent = interpolate_transformers_parameters(
                trafos,
                trafo["name"],
                trafo["sn_mv_mva"],
            )
            vk_lv_percent, vkr_lv_percent = interpolate_transformers_parameters(
                trafos,
                trafo["name"],
                trafo["sn_lv_mva"],
            )
            hv_bus, mv_bus, lv_bus = (
                trafo["bus1"],
                trafo["bus2"],
                trafo["bus3"],
            )
            trafo_id = pp.create_transformer3w_from_parameters(
                net,
                hv_bus=self.buses[hv_bus].pp_id,
                mv_bus=self.buses[mv_bus].pp_id,
                lv_bus=self.buses[lv_bus].pp_id,
                bus1_name=trafo["bus1"],
                bus2_name=trafo["bus2"],
                bus3_name=trafo["bus3"],
                vn_hv_kv=trafo["vn_hv_kv"],
                vn_mv_kv=trafo["vn_mv_kv"],
                vn_lv_kv=trafo["vn_lv_kv"],
                sn_hv_mva=trafo["sn_hv_mva"],
                sn_mv_mva=trafo["sn_mv_mva"],
                sn_lv_mva=trafo["sn_lv_mva"],
                vk_hv_percent=vk_hv_percent,
                vk_mv_percent=vk_mv_percent,
                vk_lv_percent=vk_lv_percent,
                vkr_hv_percent=vkr_hv_percent,
                vkr_mv_percent=vkr_mv_percent,
                vkr_lv_percent=vkr_lv_percent,
                pfe_kw=trafo["pfe_kw"],
                i0_percent=trafo["i0_percent"],
                shift_degree=trafo["shift_degree"],
            )

            if type(trafo_id) is not np.int64:
                raise PandaPowerElementCreationError("TRANSFORMER")

            return int(trafo_id), trafo

        self.trafos3w = {
            trafo["name"]: create_trafo(self.pp_net, trafo) for trafo in trafos
        }

    def run(self):
        try:
            pp.runpp(self.net)
        except pp.LoadflowNotConverged:
            raise ConvergenceError(self.diagnosis())

    # No podemos clonar en estos métodos que modifican porque no
    # podemos asegurar que los índices sean los mismos. Que en las
    # pruebas que he hecho siempre lo son, pero no hay garantía.
    def remove_subnet(self, buses: list[int]):
        for bus in buses:
            bus_data = self.pp_net.bus.loc[bus]
            del self.buses[bus_data["name"]]

        toolbox.drop_buses(self.pp_net, buses)
        toolbox.drop_inactive_elements(self.pp_net)

    def remove_bus_and_connect(
        self,
        buses_to_remove: list[int],
        *,
        from_bus: int,
        to_bus: int,
        new_line_name: str,
    ):
        line_feat_to = self.pp_net.line.loc[self.pp_net.line["to_bus"] == to_bus]

        for bus in buses_to_remove:
            bus_data = self.pp_net.bus.loc[bus]
            del self.buses[bus_data["name"]]

        toolbox.drop_buses(self.pp_net, buses_to_remove)

        line_feats = line_feat_to.to_dict(orient="records")[0]
        new_line_id = pp.create_line_from_parameters(
            self.pp_net,
            from_bus=from_bus,
            to_bus=to_bus,
            **{
                k: v
                for k, v in line_feats.items()
                if k
                not in [
                    "from_bus",
                    "to_bus",
                    "std_type",
                    "name",
                    "bus1_name",
                    "bus2_name",
                ]
            },
            bus1_name=self.pp_net.bus.loc[from_bus]["name"],
            bus2_name=self.pp_net.bus.loc[to_bus]["name"],
            name=new_line_name,
        )

        # TODO: borrar líneas
        self.lines[new_line_name] = (
            int(new_line_id),
            line_feats
            | {
                "name": new_line_name,
                "bus1_name": self.pp_net.bus.loc[from_bus]["name"],
                "bus2_name": self.pp_net.bus.loc[to_bus]["name"],
            },
        )

    # ========================================
    # Results Section
    # ========================================
    def _concat_results(
        self,
        element_type: AllowedElements,
        **kwargs,
    ):
        limit = kwargs.get("limit")

        df = pd.concat(
            [
                self.net[element_type],
                mappers[element_type](self.net[f"res_{element_type}"]),
            ],
            axis=1,
        )

        if limit and type(limit) is int:
            df = df[:limit]

        if kwargs.get("fill_na", False):
            df[pd.isna(df)] = 0.0

        return df.rename(columns={"name": "id"})

    def results(
        self,
        element_type: AllowedElements,
        **kwargs,
    ):
        as_dataframe = kwargs.get("as_dataframe", False)
        as_list = kwargs.get("as_list", True)

        _type = "ext_grid" if element_type == "dangling_line" else element_type
        tmp = self._concat_results(_type, **kwargs)

        if as_dataframe:
            return tmp

        if as_list:
            return tmp.to_dict(orient="records")

        # Returns a dict of dicts where the keys are the ids of the element.
        return tmp.set_index("id").T.to_dict()

    def results_all(self, **kwargs):
        return {
            "buses": self.results("bus", **kwargs),
            "lines": self.results("line", **kwargs),
            "dangling_lines": self.results("dangling_line", **kwargs),
            "loads": self.results("load", **kwargs),
            "generators": self.results("gen", **kwargs),
            "static_generators": self.results("sgen", **kwargs),
            "switches": self.results("switch", **kwargs),
            "transformers": self.results("trafo", **kwargs),
        }

    # ========================================
    # Estimation Section
    # ========================================
    def add_measurement(self, measurement: Measurement):
        """Measurements for state estimation."""
        measurement_id = pp.create_measurement(self.net, **measurement.to_dict())

        if type(measurement_id) is not np.int64:
            raise PandaPowerElementCreationError("MEASUREMENT")

        self.__measurements.append(measurement_id)

    def run_estimation(self, *, init: Literal["flat", "results", "slack"] = "flat"):
        if len(self.__measurements) == 0:
            raise PandaPowerNoMeasurementRegisteredError()

        estimate(self.net, init=init, algorithm="wls")

    # ========================================
    # Contingency Analysis Section
    # ========================================
    def n_minus_1_analysis(
        self, *, elements: list[tuple[N1Type, list[str]]], maxs: dict
    ):
        """I dont get the way to work with contingency analysis,
        so we create from scratch simple n-1 analysis turning on/off
        the elements.

        Returns a dict with the critical elements and the bus/line results
        when the critical element is turned off."""
        results = []
        for t, names in elements:
            tmp = self.__contingency_analysis(t, maxs, names)
            results.extend(tmp)

        return results

    def __contingency_analysis(
        self, type: N1Type, maxs: dict, names: list[str]
    ) -> tuple[list[int], list[tuple[int, "PowerNetwork"]], list]:
        critical = []
        results: list[tuple[int, "PowerNetwork"]] = []
        failed = []

        if type == "line":
            assert (
                "vmax" in maxs and "vmin" in maxs and "max_ll" in maxs
            ), "maxs must contain 'vmax', 'vmin' and 'max_ll' when type is 'line'"
            lines_to_turn_of = self.pp_net.line[self.pp_net.line["name"].isin(names)]

            for line_index, df in lines_to_turn_of.iterrows():
                cloned = self.clone()
                cloned_net = cloned.net
                cloned_net.line.loc[line_index, "in_service"] = False

                try:
                    pp.runpp(cloned_net)

                    if (
                        cloned_net.res_bus.vm_pu.max() > maxs["vmax"]
                        or cloned_net.res_bus.vm_pu.min() < maxs["vmin"]
                        or cloned_net.res_line.loading_percent.max() > maxs["max_ll"]
                    ):
                        critical.append(df["name"])

                    results.append((df["name"], cloned))

                except Exception as e:
                    failed.append((type, df["name"], str(e)))

        elif type == "transformer":
            assert (
                "vmax" in maxs and "vmin" in maxs and "max_ll" in maxs
            ), "maxs must contain 'vmax', 'vmin' and 'max_ll' when type is 'transformer'"
            trafos_to_turn_of = self.pp_net.transformer[
                self.pp_net.transformer["name"].isin(names)
            ]

            for trafo_index, df in trafos_to_turn_of.iterrows():
                cloned = self.clone()
                cloned_net = cloned.net
                cloned_net.trafo.loc[trafo_index, "in_service"] = False

                try:
                    pp.runpp(cloned_net)

                    if (
                        cloned_net.res_bus.vm_pu.max() > maxs["vmax"]
                        or cloned_net.res_bus.vm_pu.min() < maxs["vmin"]
                        or cloned_net.res_trafo.loading_percent.max() > maxs["max_ll"]
                    ):
                        critical.append(df["name"])

                    results.append((df["name"], cloned))

                except Exception as e:
                    failed.append((type, df["name"], str(e)))

        return critical, results, failed

    # ========================================
    # Helpers for development, debugging and inspection
    # ========================================
    def plot(self, *, plot_type="matplotlib", **kwargs):
        if plot_type == "matplotlib":
            return plot.simple_plot(self.net, show_plot=True, **kwargs)
        elif plot_type == "simple_plotly":
            return simple_plotly(self.net, **kwargs)
        elif plot_type == "voltage_level_plotly":
            return vlevel_plotly(self.net, **kwargs)
        elif plot_type == "powerflow_results_plotly":
            return pf_res_plotly(self.net, **kwargs)
        elif plot_type == "graph":
            multi_graph = top.create_nxgraph(self.net)
            return nx.draw(multi_graph)
        else:
            return plot.simple_plot(self.net, show_plot=True, **kwargs)

    def clone(self) -> "PowerNetwork":
        net = PowerNetwork()
        net.load_buses(self.pp_net.bus.to_dict(orient="records"))
        net.load_lines(self.pp_net.line.to_dict(orient="records"))
        net.load_loads(self.pp_net.load.to_dict(orient="records"))
        net.load_ext_grid(self.pp_net.ext_grid.to_dict(orient="records"))

        net.pp_net.bus.geo = self.pp_net.bus.geo
        net.pp_net.line.geo = self.pp_net.line.geo

        return net

    def diagnosis(self) -> dict:
        return pp.diagnostic(self.net)  # type: ignore

    # ========================================
    # Import/Export Section
    # ========================================
    def export_file(self, filename: str):
        ext = Path(filename).suffix[1:]
        self.export(filename, format=ext)  # type: ignore

    def export(
        self,
        filename: str,
        format: str | Literal["json", "excel", "sqlite", "pickle"] = "json",
    ) -> Path:
        match format:
            case "json":
                pp.to_json(self.net, filename)
            case "excel":
                pp.to_excel(self.net, filename)
            case "sqlite":
                pp.to_sqlite(self.net, filename)
            case "pickle":
                pp.to_pickle(self.net, filename)
            case _:
                raise ValueError(f"Format {format} not supported.")

        return Path(filename)

    def export_to_json(self, *, n_indent=2) -> dict:
        import json

        return json.loads(pp.to_json(self.net, indent=n_indent))

    def export_to_json_string(self, *, compact: bool, n_indent=2) -> str:
        import json

        tmp = self.export_to_json(n_indent=n_indent)
        separators = (",", ":") if compact else (", ", ": ")

        return json.dumps(tmp, separators=separators)

    @classmethod
    def from_pandapower_net(cls, pp_net: pp.pandapowerNet) -> "PowerNetwork":
        """Create a PowerNetwork instance from a pandapower network."""
        net = cls()

        net.load_buses(pp_net.bus.to_dict(orient="records"))
        net.load_gens(pp_net.gen.to_dict(orient="records"))
        net.load_lines(pp_net.line.to_dict(orient="records"))
        net.load_loads(pp_net.load.to_dict(orient="records"))
        net.load_ext_grid(pp_net.ext_grid.to_dict(orient="records"))

        net.pp_net.bus.geo = pp_net.bus.geo
        net.pp_net.line.geo = pp_net.line.geo

        return net

    @classmethod
    def from_pandapower_json(cls, json_content: str) -> "PowerNetwork":
        """Create a PowerNetwork instance from a pandapower json file."""
        return pp.from_json(json_content)
    
    @classmethod
    def from_pandapower_file(cls, filename: str) -> "PowerNetwork":
        """Create a PowerNetwork instance from a pandapower json file."""
        path = Path(filename)
        if not path.exists():
            raise FileNotFoundError(f"File {filename} does not exist.")
        if path.suffix != ".json":
            raise ValueError(f"File {filename} is not a json file.")

        pp_net = pp.from_json(filename)
        if type(pp_net) is not pp.pandapowerNet:
            raise ValueError(f"File {filename} is not a valid pandapower json file.")

        return cls.from_pandapower_net(pp_net)

    @classmethod
    def from_pandapower_json_string(cls, json_str: str) -> "PowerNetwork":
        """Create a PowerNetwork instance from a pandapower json file."""
        try:
            pp_net = pp.from_json_string(json_str)
            if type(pp_net) is not pp.pandapowerNet:
                raise ValueError("Json string is not a valid pandapower json file.")

            return cls.from_pandapower_net(pp_net)
        except Exception as e:
            raise ValueError("Json string is not a valid pandapower json file.") from e

    # TODO: To test and finish
    def _simplify_network(self, busbar_types: list) -> None | pp.pandapowerNet:
        """
        Simplify the network by removing zero-impedance branches.
        """

        pp_net_copy = pp.pandapowerNet(self.pp_net.copy())

        # Identify busbar lines
        busbar_lines_ids = [
            k for k, v in self.lines.items() if v[1]["cable"] in busbar_types
        ]
        busbar_lines = pp_net_copy.line[
            pp_net_copy.line.name.isin(busbar_lines_ids)
        ].index

        if len(busbar_lines) == 0:
            return

        print(f"{len(busbar_lines)} busbar lines identified for simplification")

        # Create subgraph of busbar lines
        G = top.create_nxgraph(pp_net_copy, include_lines=True, include_trafos=False)
        sub_edges = [
            (
                pp_net_copy.line.at[i, "from_bus"],
                pp_net_copy.line.at[i, "to_bus"],
                ("line", np.int64(i)),
            )
            for i in busbar_lines
        ]
        subgraph = G.edge_subgraph(sub_edges)

        # Iterate over connected components (busbar-connected node sets)
        groups = list(nx.connected_components(subgraph))
        print(f"{len(groups)} groups of busbar-connected buses found")

        def _is_connected(net, bus):
            """
            Verify if a bus is connected to any other network element (lines, loads, gen, etc.).
            """
            connected_elements = (
                (net.line.from_bus == bus).any()
                or (net.line.to_bus == bus).any()
                or ("load" in net and (net.load.bus == bus).any())
                or ("sgen" in net and (net.sgen.bus == bus).any())
                or ("gen" in net and (net.gen.bus == bus).any())
                or ("shunt" in net and (net.shunt.bus == bus).any())
                or ("storage" in net and (net.storage.bus == bus).any())
                or ("ext_grid" in net and (net.ext_grid.bus == bus).any())
            )
            return connected_elements

        remove_lines = []
        remove_buses = []
        for group in groups:
            buses = list(group)
            ref_bus = buses[0]
            other_buses = buses[1:]

            print(f"Buses {buses} will be simplified into bus {ref_bus}")

            # Replace references in line.from_bus and line.to_bus
            for i in pp_net_copy.line.index:
                if pp_net_copy.line.at[i, "from_bus"] in other_buses:
                    pp_net_copy.line.at[i, "from_bus"] = ref_bus
                if pp_net_copy.line.at[i, "to_bus"] in other_buses:
                    pp_net_copy.line.at[i, "to_bus"] = ref_bus

            # Replace references in other elements (load, gen, etc.)
            for table in ["load", "sgen", "gen", "shunt", "ext_grid", "storage"]:
                if hasattr(pp_net_copy, table) and not pp_net_copy[table].empty:
                    for i in pp_net_copy[table].index:
                        if pp_net_copy[table].at[i, "bus"] in other_buses:
                            pp_net_copy[table].at[i, "bus"] = ref_bus

            # Remove busbar lines that are now self-loops
            for i in busbar_lines:
                if i not in pp_net_copy.line.index:
                    continue
                fb = pp_net_copy.line.at[i, "from_bus"]
                tb = pp_net_copy.line.at[i, "to_bus"]
                if fb in group and tb in group:
                    remove_lines.append(i)

            # Remove buses connected to busbar lines that are now isolated
            for b in other_buses:
                if not _is_connected(pp_net_copy, b):
                    remove_buses.append(b)

        print(f"Removing a total of lines {len(remove_lines)}")
        print(f"Removing a total of buses {len(remove_buses)}")
        pp.drop_lines(pp_net_copy, remove_lines)
        pp.drop_buses(pp_net_copy, remove_buses)

        return pp_net_copy
